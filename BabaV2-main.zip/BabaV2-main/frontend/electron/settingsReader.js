const util = require('util');
const { exec } = require('child_process');
const execAsync = util.promisify(exec);

/**
 * Lit l'état d'un paramètre Windows spécifique
 * @param {string} id - ID du paramètre à lire
 * @returns {Promise<boolean | number | null>} État du paramètre
 */
async function readSetting(id) {
  switch (id) {
    // === POWER OPTIONS ===
    case 'fast-startup':
      return await readFastStartup();
    case 'hibernate-enabled':
      return await readHibernateEnabled();
    case 'usb-selective-suspend':
      return await readUsbSelectiveSuspend();
    
    // === GAMING OPTIONS ===
    case 'game-mode':
      return await readGameMode();
    case 'hardware-acceleration':
      return await readHardwareAcceleration();
    case 'game-dvr':
      return await readGameDVR();
    case 'fullscreen-optimization':
      return await readFullscreenOptimization();
    case 'gpu-timeout':
      return await readGpuTimeout();
    case 'mouse-acceleration':
      return await readMouseAcceleration();
    case 'priority-separation':
      return await readPrioritySeparation();
    case 'nagle-algorithm':
      return await readNagleAlgorithm();
    
    // === INTERFACE OPTIONS ===
    case 'dark-mode':
      return await readDarkMode();
    case 'transparency':
      return await readTransparency();
    case 'animations':
      return await readAnimations();
    case 'color-prevalence':
      return await readColorPrevalence();
    case 'classic-context':
      return await readClassicContextMenu();
    case 'legacy-alt-tab':
      return await readLegacyAltTab();
    case 'taskbar-left':
      return await readTaskbarAlignment();
    
    // === PRIVACY OPTIONS ===
    case 'telemetry':
      return await readTelemetry();
    case 'advertising-id':
      return await readAdvertisingId();
    case 'activity-history':
      return await readActivityHistory();
    case 'location-tracking':
      return await readLocationTracking();
    case 'cortana':
      return await readCortana();
    case 'diagnostic-data':
      return await readDiagnosticData();
    
    // === ADVANCED OPTIONS ===
    case 'defender':
      return await readWindowsDefender();
    case 'smartscreen':
      return await readSmartScreen();
    case 'uac':
      return await readUAC();
    case 'windows-update':
      return await readWindowsUpdate();
    case 'mitigations':
      return await readMitigations();
    
    default:
      console.log(`[settingsReader] No reader implemented for: ${id}`);
      return null;
  }
}

/**
 * Lit plusieurs paramètres en une seule fois
 * @param {string[]} ids - Liste des IDs à lire
 * @returns {Promise<Object>} Objet {id: value}
 */
async function readMultipleSettings(ids) {
  const results = {};
  await Promise.all(
    ids.map(async (id) => {
      results[id] = await readSetting(id);
    })
  );
  return results;
}

/**
 * Lit l'état du démarrage rapide (Fast Startup)
 * Clé registre : HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power\HiberbootEnabled
 */
async function readFastStartup() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Power" /v HiberbootEnabled 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      console.log('[settingsReader] Fast Startup key not found');
      return null;
    }

    // Parser la sortie : "    HiberbootEnabled    REG_DWORD    0x1"
    const match = stdout.match(/HiberbootEnabled\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      console.log(`[settingsReader] Fast Startup: ${value === 1 ? 'enabled' : 'disabled'}`);
      return value === 1; // 1 = enabled, 0 = disabled
    }

    return null;
  } catch (error) {
    console.error('[settingsReader] Error reading Fast Startup:', error.message);
    return null;
  }
}

/**
 * Lit l'état de l'hibernation
 * Commande : powercfg /a (liste les états de veille disponibles)
 */
async function readHibernateEnabled() {
  try {
    const { stdout } = await execAsync('powercfg /a', { encoding: 'utf8' });

    if (!stdout) {
      console.log('[settingsReader] Could not read hibernate status');
      return null;
    }

    // Chercher "Hibernate" ou "Hibernation" dans la sortie
    const hibernateAvailable = stdout.toLowerCase().includes('hibernate');
    console.log(`[settingsReader] Hibernate: ${hibernateAvailable ? 'available' : 'not available'}`);
    
    return hibernateAvailable;
  } catch (error) {
    console.error('[settingsReader] Error reading Hibernate:', error.message);
    return null;
  }
}

/**
 * Lit l'état du Game Mode Windows
 * Clé registre : HKCU\Software\Microsoft\GameBar\AutoGameModeEnabled
 */
async function readGameMode() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKCU\\Software\\Microsoft\\GameBar" /v AutoGameModeEnabled 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      console.log('[settingsReader] Game Mode key not found');
      return null;
    }

    const match = stdout.match(/AutoGameModeEnabled\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      console.log(`[settingsReader] Game Mode: ${value === 1 ? 'enabled' : 'disabled'}`);
      return value === 1;
    }

    return null;
  } catch (error) {
    console.error('[settingsReader] Error reading Game Mode:', error.message);
    return null;
  }
}

/**
 * Lit l'état du mode sombre
 * Clé registre : HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize\AppsUseLightTheme
 */
async function readDarkMode() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize" /v AppsUseLightTheme 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      console.log('[settingsReader] Dark Mode key not found');
      return null;
    }

    const match = stdout.match(/AppsUseLightTheme\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      // 0 = dark mode, 1 = light mode
      const isDarkMode = value === 0;
      console.log(`[settingsReader] Dark Mode: ${isDarkMode ? 'enabled' : 'disabled'}`);
      return isDarkMode;
    }

    return null;
  } catch (error) {
    console.error('[settingsReader] Error reading Dark Mode:', error.message);
    return null;
  }
}

/**
 * Lit l'état de la transparence
 * Clé registre : HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize\EnableTransparency
 */
async function readTransparency() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize" /v EnableTransparency 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      console.log('[settingsReader] Transparency key not found');
      return null;
    }

    const match = stdout.match(/EnableTransparency\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      console.log(`[settingsReader] Transparency: ${value === 1 ? 'enabled' : 'disabled'}`);
      return value === 1;
    }

    return null;
  } catch (error) {
    console.error('[settingsReader] Error reading Transparency:', error.message);
    return null;
  }
}

/**
 * Lit l'état des animations Windows
 * Clé registre : HKCU\Control Panel\Desktop\WindowMetrics\MinAnimate
 */
async function readAnimations() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKCU\\Control Panel\\Desktop\\WindowMetrics" /v MinAnimate 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      console.log('[settingsReader] Animations key not found');
      return null;
    }

    const match = stdout.match(/MinAnimate\s+REG_SZ\s+(.+)/i);
    if (match) {
      const value = match[1].trim();
      const isEnabled = value === '1';
      console.log(`[settingsReader] Animations: ${isEnabled ? 'enabled' : 'disabled'}`);
      return isEnabled;
    }

    return null;
  } catch (error) {
    console.error('[settingsReader] Error reading Animations:', error.message);
    return null;
  }
}

/**
 * Lit l'état de ColorPrevalence (couleur d'accentuation sur la barre des tâches)
 * Clé registre : HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize\ColorPrevalence
 */
async function readColorPrevalence() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize" /v ColorPrevalence 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      console.log('[settingsReader] ColorPrevalence key not found');
      return false;
    }

    const match = stdout.match(/ColorPrevalence\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      const isEnabled = value === 1;
      console.log(`[settingsReader] ColorPrevalence: ${isEnabled ? 'enabled' : 'disabled'}`);
      return isEnabled;
    }

    return false;
  } catch (error) {
    console.error('[settingsReader] Error reading ColorPrevalence:', error.message);
    return false;
  }
}

// ============================================================================
// GAMING OPTIONS READERS
// ============================================================================

/**
 * Lit l'état du Hardware-Accelerated GPU Scheduling (HAGS)
 * Clé registre : HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\HwSchMode
 */
async function readHardwareAcceleration() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers" /v HwSchMode 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      console.log('[settingsReader] HAGS key not found');
      return false;
    }

    const match = stdout.match(/HwSchMode\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      const isEnabled = value === 2;
      console.log(`[settingsReader] Hardware Acceleration: ${isEnabled ? 'enabled' : 'disabled'}`);
      return isEnabled;
    }

    return false;
  } catch (error) {
    console.error('[settingsReader] Error reading Hardware Acceleration:', error.message);
    return false;
  }
}

/**
 * Lit l'état du Game DVR (désactivé = notre toggle ON)
 * Clé registre : HKCU\System\GameConfigStore\GameDVR_Enabled
 */
async function readGameDVR() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKCU\\System\\GameConfigStore" /v GameDVR_Enabled 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      console.log('[settingsReader] Game DVR key not found');
      return false;
    }

    const match = stdout.match(/GameDVR_Enabled\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      // Our toggle ON = DVR disabled (0)
      const isOurToggleOn = value === 0;
      console.log(`[settingsReader] Game DVR: ${isOurToggleOn ? 'disabled (toggle ON)' : 'enabled (toggle OFF)'}`);
      return isOurToggleOn;
    }

    return false;
  } catch (error) {
    console.error('[settingsReader] Error reading Game DVR:', error.message);
    return false;
  }
}

/**
 * Lit l'état de l'optimisation plein écran (désactivée = notre toggle ON)
 * Clé registre : HKCU\System\GameConfigStore\GameDVR_FSEBehaviorMode
 */
async function readFullscreenOptimization() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKCU\\System\\GameConfigStore" /v GameDVR_FSEBehaviorMode 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      console.log('[settingsReader] FSO key not found');
      return false;
    }

    const match = stdout.match(/GameDVR_FSEBehaviorMode\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      // 2 = FSO disabled = our toggle ON
      const isOurToggleOn = value === 2;
      console.log(`[settingsReader] Fullscreen Optimization: ${isOurToggleOn ? 'disabled (toggle ON)' : 'enabled (toggle OFF)'}`);
      return isOurToggleOn;
    }

    return false;
  } catch (error) {
    console.error('[settingsReader] Error reading Fullscreen Optimization:', error.message);
    return false;
  }
}

/**
 * Lit l'état du GPU Timeout (TdrLevel)
 * Clé registre : HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\TdrLevel
 */
async function readGpuTimeout() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers" /v TdrLevel 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      console.log('[settingsReader] GPU Timeout key not found');
      return false;
    }

    const match = stdout.match(/TdrLevel\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      // 0 = timeout disabled = our toggle ON
      const isOurToggleOn = value === 0;
      console.log(`[settingsReader] GPU Timeout: ${isOurToggleOn ? 'disabled (toggle ON)' : 'enabled (toggle OFF)'}`);
      return isOurToggleOn;
    }

    return false;
  } catch (error) {
    console.error('[settingsReader] Error reading GPU Timeout:', error.message);
    return false;
  }
}

/**
 * Lit l'état de l'accélération de la souris (désactivée = notre toggle ON)
 * Clé registre : HKCU\Control Panel\Mouse\MouseSpeed
 */
async function readMouseAcceleration() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKCU\\Control Panel\\Mouse" /v MouseSpeed 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      console.log('[settingsReader] Mouse Acceleration key not found');
      return false;
    }

    const match = stdout.match(/MouseSpeed\s+REG_SZ\s+(.+)/i);
    if (match) {
      const value = match[1].trim();
      // "0" = acceleration disabled = our toggle ON
      const isOurToggleOn = value === '0';
      console.log(`[settingsReader] Mouse Acceleration: ${isOurToggleOn ? 'disabled (toggle ON)' : 'enabled (toggle OFF)'}`);
      return isOurToggleOn;
    }

    return false;
  } catch (error) {
    console.error('[settingsReader] Error reading Mouse Acceleration:', error.message);
    return false;
  }
}

/**
 * Lit l'état de la séparation de priorité
 * Clé registre : HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl\Win32PrioritySeparation
 */
async function readPrioritySeparation() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKLM\\SYSTEM\\CurrentControlSet\\Control\\PriorityControl" /v Win32PrioritySeparation 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      console.log('[settingsReader] Priority Separation key not found');
      return false;
    }

    const match = stdout.match(/Win32PrioritySeparation\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      // 38 (0x26) = gaming optimized = our toggle ON
      const isOurToggleOn = value === 38;
      console.log(`[settingsReader] Priority Separation: ${isOurToggleOn ? 'optimized (toggle ON)' : 'default (toggle OFF)'}`);
      return isOurToggleOn;
    }

    return false;
  } catch (error) {
    console.error('[settingsReader] Error reading Priority Separation:', error.message);
    return false;
  }
}

/**
 * Lit l'état de l'algorithme de Nagle (désactivé = notre toggle ON)
 * Vérifie TcpNoDelay sur les interfaces réseau
 */
async function readNagleAlgorithm() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKLM\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces" /s /v TcpNoDelay 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      console.log('[settingsReader] Nagle key not found');
      return false;
    }

    // Check if any interface has TcpNoDelay = 1
    const match = stdout.match(/TcpNoDelay\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      // 1 = Nagle disabled = our toggle ON
      const isOurToggleOn = value === 1;
      console.log(`[settingsReader] Nagle Algorithm: ${isOurToggleOn ? 'disabled (toggle ON)' : 'enabled (toggle OFF)'}`);
      return isOurToggleOn;
    }

    return false;
  } catch (error) {
    console.error('[settingsReader] Error reading Nagle Algorithm:', error.message);
    return false;
  }
}

/**
 * Lit l'état de la suspension sélective USB
 */
async function readUsbSelectiveSuspend() {
  try {
    const { stdout } = await execAsync(
      'powercfg /query scheme_current 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 2>&1',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      console.log('[settingsReader] USB Selective Suspend query failed');
      return true; // Default enabled
    }

    // Check for "Current AC Power Setting Index: 0x00000001" (enabled)
    const isEnabled = stdout.includes('0x00000001');
    console.log(`[settingsReader] USB Selective Suspend: ${isEnabled ? 'enabled' : 'disabled'}`);
    return isEnabled;
  } catch (error) {
    console.error('[settingsReader] Error reading USB Selective Suspend:', error.message);
    return true; // Default enabled
  }
}

// ============================================================================
// INTERFACE OPTIONS READERS (Extended)
// ============================================================================

/**
 * Lit l'état du menu contextuel classique (Windows 10 style)
 * Clé registre : HKCU\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32
 */
async function readClassicContextMenu() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKCU\\Software\\Classes\\CLSID\\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\\InprocServer32" /ve 2>nul',
      { encoding: 'utf8' }
    );

    // If the key exists with empty default value, classic context menu is enabled
    const isEnabled = stdout && stdout.includes('REG_SZ');
    console.log(`[settingsReader] Classic Context Menu: ${isEnabled ? 'enabled' : 'disabled'}`);
    return isEnabled;
  } catch (error) {
    // Key doesn't exist = classic menu not enabled
    console.log('[settingsReader] Classic Context Menu: disabled (key not found)');
    return false;
  }
}

/**
 * Lit l'état du Alt-Tab classique
 * Clé registre : HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\AltTabSettings
 */
async function readLegacyAltTab() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer" /v AltTabSettings 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      return false;
    }

    const match = stdout.match(/AltTabSettings\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      // 1 = legacy Alt-Tab enabled
      const isEnabled = value === 1;
      console.log(`[settingsReader] Legacy Alt-Tab: ${isEnabled ? 'enabled' : 'disabled'}`);
      return isEnabled;
    }

    return false;
  } catch (error) {
    console.error('[settingsReader] Error reading Legacy Alt-Tab:', error.message);
    return false;
  }
}

/**
 * Lit l'alignement de la barre des tâches
 * Clé registre : HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\TaskbarAl
 */
async function readTaskbarAlignment() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced" /v TaskbarAl 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      return false;
    }

    const match = stdout.match(/TaskbarAl\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      // 0 = left aligned, 1 = centered
      const isLeftAligned = value === 0;
      console.log(`[settingsReader] Taskbar Alignment: ${isLeftAligned ? 'left' : 'center'}`);
      return isLeftAligned;
    }

    return false;
  } catch (error) {
    console.error('[settingsReader] Error reading Taskbar Alignment:', error.message);
    return false;
  }
}

// ============================================================================
// PRIVACY OPTIONS READERS
// ============================================================================

/**
 * Lit l'état de la télémétrie Windows (désactivée = notre toggle ON)
 * Clé registre : HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection\AllowTelemetry
 */
async function readTelemetry() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection" /v AllowTelemetry 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      // Key doesn't exist = telemetry probably enabled (default)
      return false;
    }

    const match = stdout.match(/AllowTelemetry\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      // 0 = telemetry disabled = our toggle ON
      const isOurToggleOn = value === 0;
      console.log(`[settingsReader] Telemetry: ${isOurToggleOn ? 'disabled (toggle ON)' : 'enabled (toggle OFF)'}`);
      return isOurToggleOn;
    }

    return false;
  } catch (error) {
    console.error('[settingsReader] Error reading Telemetry:', error.message);
    return false;
  }
}

/**
 * Lit l'état de l'ID publicitaire (désactivé = notre toggle ON)
 * Clé registre : HKCU\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo\Enabled
 */
async function readAdvertisingId() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo" /v Enabled 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      return false;
    }

    const match = stdout.match(/Enabled\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      // 0 = advertising ID disabled = our toggle ON
      const isOurToggleOn = value === 0;
      console.log(`[settingsReader] Advertising ID: ${isOurToggleOn ? 'disabled (toggle ON)' : 'enabled (toggle OFF)'}`);
      return isOurToggleOn;
    }

    return false;
  } catch (error) {
    console.error('[settingsReader] Error reading Advertising ID:', error.message);
    return false;
  }
}

/**
 * Lit l'état de l'historique des activités (désactivé = notre toggle ON)
 * Clé registre : HKLM\SOFTWARE\Policies\Microsoft\Windows\System\EnableActivityFeed
 */
async function readActivityHistory() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\System" /v EnableActivityFeed 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      // Key doesn't exist = activity history probably enabled
      return false;
    }

    const match = stdout.match(/EnableActivityFeed\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      // 0 = activity history disabled = our toggle ON
      const isOurToggleOn = value === 0;
      console.log(`[settingsReader] Activity History: ${isOurToggleOn ? 'disabled (toggle ON)' : 'enabled (toggle OFF)'}`);
      return isOurToggleOn;
    }

    return false;
  } catch (error) {
    console.error('[settingsReader] Error reading Activity History:', error.message);
    return false;
  }
}

/**
 * Lit l'état du suivi de localisation (désactivé = notre toggle ON)
 * Clé registre : HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location\Value
 */
async function readLocationTracking() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\CapabilityAccessManager\\ConsentStore\\location" /v Value 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      return false;
    }

    const match = stdout.match(/Value\s+REG_SZ\s+(.+)/i);
    if (match) {
      const value = match[1].trim();
      // "Deny" = location tracking disabled = our toggle ON
      const isOurToggleOn = value.toLowerCase() === 'deny';
      console.log(`[settingsReader] Location Tracking: ${isOurToggleOn ? 'disabled (toggle ON)' : 'enabled (toggle OFF)'}`);
      return isOurToggleOn;
    }

    return false;
  } catch (error) {
    console.error('[settingsReader] Error reading Location Tracking:', error.message);
    return false;
  }
}

/**
 * Lit l'état de Cortana (désactivé = notre toggle ON)
 * Clé registre : HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search\AllowCortana
 */
async function readCortana() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search" /v AllowCortana 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      // Key doesn't exist = Cortana probably enabled
      return false;
    }

    const match = stdout.match(/AllowCortana\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      // 0 = Cortana disabled = our toggle ON
      const isOurToggleOn = value === 0;
      console.log(`[settingsReader] Cortana: ${isOurToggleOn ? 'disabled (toggle ON)' : 'enabled (toggle OFF)'}`);
      return isOurToggleOn;
    }

    return false;
  } catch (error) {
    console.error('[settingsReader] Error reading Cortana:', error.message);
    return false;
  }
}

/**
 * Lit l'état des données de diagnostic (minimum = notre toggle ON)
 * Clé registre : HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection\AllowTelemetry
 */
async function readDiagnosticData() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\DataCollection" /v AllowTelemetry 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      return false;
    }

    const match = stdout.match(/AllowTelemetry\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      // 0 or 1 = minimum diagnostic data = our toggle ON
      const isOurToggleOn = value <= 1;
      console.log(`[settingsReader] Diagnostic Data: ${isOurToggleOn ? 'minimum (toggle ON)' : 'full (toggle OFF)'}`);
      return isOurToggleOn;
    }

    return false;
  } catch (error) {
    console.error('[settingsReader] Error reading Diagnostic Data:', error.message);
    return false;
  }
}

// ============================================================================
// ADVANCED OPTIONS READERS
// ============================================================================

/**
 * Lit l'état de Windows Defender (activé = notre toggle ON)
 * Clé registre : HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\DisableAntiSpyware
 */
async function readWindowsDefender() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows Defender" /v DisableAntiSpyware 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      // Key doesn't exist = Defender is enabled
      console.log('[settingsReader] Windows Defender: enabled (key not found)');
      return true;
    }

    const match = stdout.match(/DisableAntiSpyware\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      // 0 = Defender enabled = our toggle ON
      const isEnabled = value === 0;
      console.log(`[settingsReader] Windows Defender: ${isEnabled ? 'enabled' : 'disabled'}`);
      return isEnabled;
    }

    return true;
  } catch (error) {
    console.error('[settingsReader] Error reading Windows Defender:', error.message);
    return true;
  }
}

/**
 * Lit l'état du SmartScreen (activé = notre toggle ON)
 * Clé registre : HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\SmartScreenEnabled
 */
async function readSmartScreen() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer" /v SmartScreenEnabled 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      // Default is enabled
      return true;
    }

    const match = stdout.match(/SmartScreenEnabled\s+REG_SZ\s+(.+)/i);
    if (match) {
      const value = match[1].trim().toLowerCase();
      // "on" or "warn" = enabled = our toggle ON
      const isEnabled = value === 'on' || value === 'warn';
      console.log(`[settingsReader] SmartScreen: ${isEnabled ? 'enabled' : 'disabled'}`);
      return isEnabled;
    }

    return true;
  } catch (error) {
    console.error('[settingsReader] Error reading SmartScreen:', error.message);
    return true;
  }
}

/**
 * Lit l'état de l'UAC (activé = notre toggle ON)
 * Clé registre : HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\EnableLUA
 */
async function readUAC() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" /v EnableLUA 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      return true;
    }

    const match = stdout.match(/EnableLUA\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      // 1 = UAC enabled = our toggle ON
      const isEnabled = value === 1;
      console.log(`[settingsReader] UAC: ${isEnabled ? 'enabled' : 'disabled'}`);
      return isEnabled;
    }

    return true;
  } catch (error) {
    console.error('[settingsReader] Error reading UAC:', error.message);
    return true;
  }
}

/**
 * Lit l'état de Windows Update (activé = notre toggle ON)
 * Clé registre : HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU\NoAutoUpdate
 */
async function readWindowsUpdate() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU" /v NoAutoUpdate 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      // Key doesn't exist = auto update enabled
      console.log('[settingsReader] Windows Update: enabled (key not found)');
      return true;
    }

    const match = stdout.match(/NoAutoUpdate\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      // 0 = auto update enabled = our toggle ON
      const isEnabled = value === 0;
      console.log(`[settingsReader] Windows Update: ${isEnabled ? 'enabled' : 'disabled'}`);
      return isEnabled;
    }

    return true;
  } catch (error) {
    console.error('[settingsReader] Error reading Windows Update:', error.message);
    return true;
  }
}

/**
 * Lit l'état des mitigations Spectre/Meltdown (activé = notre toggle ON)
 * Clé registre : HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\FeatureSettingsOverride
 */
async function readMitigations() {
  try {
    const { stdout } = await execAsync(
      'reg query "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management" /v FeatureSettingsOverride 2>nul',
      { encoding: 'utf8' }
    );

    if (!stdout) {
      // Key doesn't exist = mitigations are enabled (default)
      console.log('[settingsReader] Mitigations: enabled (key not found)');
      return true;
    }

    const match = stdout.match(/FeatureSettingsOverride\s+REG_DWORD\s+0x([0-9a-fA-F]+)/i);
    if (match) {
      const value = parseInt(match[1], 16);
      // 3 = mitigations disabled, 0 = enabled
      const isEnabled = value !== 3;
      console.log(`[settingsReader] Mitigations: ${isEnabled ? 'enabled' : 'disabled'}`);
      return isEnabled;
    }

    return true;
  } catch (error) {
    console.error('[settingsReader] Error reading Mitigations:', error.message);
    return true;
  }
}

module.exports = { readSetting, readMultipleSettings };
