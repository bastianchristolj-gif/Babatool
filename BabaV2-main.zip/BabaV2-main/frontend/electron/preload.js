// Preload script - expose secure APIs to renderer
const { contextBridge, ipcRenderer } = require('electron');

// Expose platform info and APIs to the renderer process
contextBridge.exposeInMainWorld('electronAPI', {
  // ============================================================================
  // API PROXY - Requêtes vers le backend local
  // ============================================================================
  apiRequest: (method, endpoint, data) => ipcRenderer.invoke('api-request', { method, endpoint, data }),
  
  // Test de connexion backend
  testBackendConnection: async () => {
    try {
      const result = await ipcRenderer.invoke('api-request', { 
        method: 'GET', 
        endpoint: '/api/', 
        data: null 
      });
      return result;
    } catch (error) {
      return { success: false, error: error.message };
    }
  },
  
  // ============================================================================
  // INFO SYSTÈME
  // ============================================================================
  platform: process.platform,
  isElectron: true,
  getVersion: () => process.versions.electron,
  getAppVersion: () => ipcRenderer.invoke('get-app-version'),
  getSystemInfo: () => ipcRenderer.invoke('get-system-info'),
  checkAdmin: () => ipcRenderer.invoke('check-admin'),
  restartAsAdmin: () => ipcRenderer.invoke('restart-as-admin'),
  
  // ============================================================================
  // CONTRÔLES FENÊTRE
  // ============================================================================
  minimize: () => ipcRenderer.send('window-minimize'),
  maximize: () => ipcRenderer.send('window-maximize'),
  close: () => ipcRenderer.send('window-close'),
  minimizeWindow: () => ipcRenderer.send('window-minimize'),
  maximizeWindow: () => ipcRenderer.send('window-maximize'),
  closeWindow: () => ipcRenderer.send('window-close'),
  
  // ============================================================================
  // EXÉCUTION POWERSHELL / CMD
  // ============================================================================
  
  // Exécuter des commandes PowerShell
  // @param {Array} commands - Liste de commandes [{command: string, script: string, requireAdmin: boolean}]
  // @returns {Promise<Array<{command: string, success: boolean, output: string, error: string}>>}
  executePowerShell: (commands) => ipcRenderer.invoke('execute-powershell', commands),
  
  // Installer et lancer le setup NVIDIA via PowerShell
  // @returns {Promise<{success: boolean, message: string, error: string, output: string}>}
  installNvidiaSetup: () => ipcRenderer.invoke('install-nvidia-setup'),
  
  // Exécuter le script NVIDIA avec paramètre du jeu (-nvidia ou -callofduty)
  // @param {string} gameParam - Paramètre du jeu ('-nvidia' ou '-callofduty')
  // @returns {Promise<{success: boolean, message: string, error: string, output: string}>}
  runNvidiaScript: (gameParam) => ipcRenderer.invoke('run-nvidia-script', gameParam),
  
  // Exécuter le script NVIDIA Profile Inspector (NPI.ps1)
  // @returns {Promise<{success: boolean, message: string, error: string, output: string}>}
  runNPIScript: () => ipcRenderer.invoke('run-npi-script'),
  
  // Exécuter une commande CMD
  // @param {string} command - Commande à exécuter
  // @returns {Promise<{success: boolean, output: string, error: string}>}
  executeCmd: (command) => ipcRenderer.invoke('execute-cmd', command),
  
  // Ouvrir un lien externe
  openExternal: (url) => ipcRenderer.invoke('open-external', url),
  
  // ============================================================================
  // APPLICATIONS INSTALLÉES & AUTORUNS
  // ============================================================================
  
  // Récupérer les applications installées (non-système)
  getInstalledApps: () => ipcRenderer.invoke('get-installed-apps'),
  
  // Récupérer les programmes au démarrage
  getAutoruns: () => ipcRenderer.invoke('get-autoruns'),
  
  // Désinstaller une application
  uninstallApp: (uninstallString) => ipcRenderer.invoke('uninstall-app', { uninstallString }),
  
  // Désinstaller une application UWP (bloatware)
  uninstallUwpApp: (packageName) => ipcRenderer.invoke('uninstall-uwp-app', { packageName }),
  
  // Activer/Désactiver un autorun
  toggleAutorun: (name, location, enabled, command) => 
    ipcRenderer.invoke('toggle-autorun', { name, location, enabled, command }),
  
  // Nettoyer le système (Clean All)
  cleanSystem: (category) => ipcRenderer.invoke('clean-system', category),
  
  // Écouter la progression du nettoyage
  onCleanProgress: (callback) => {
    ipcRenderer.on('clean-progress', (event, data) => callback(data));
  },
  
  // Retirer l'écouteur de progression
  removeCleanProgressListener: () => {
    ipcRenderer.removeAllListeners('clean-progress');
  },
  
  // ============================================================================
  // MISE À JOUR AUTOMATIQUE
  // ============================================================================
  
  // Télécharger une mise à jour
  downloadUpdate: (url, version) => ipcRenderer.invoke('download-update', { url, version }),
  
  // Écouter la progression du téléchargement
  onDownloadProgress: (callback) => {
    ipcRenderer.on('download-progress', (event, data) => callback(data));
  },
  
  // Supprimer le listener de progression
  removeDownloadProgressListener: () => {
    ipcRenderer.removeAllListeners('download-progress');
  },
  
  // Lancer l'installateur en mode silencieux
  runSilentInstaller: (filePath) => ipcRenderer.invoke('run-silent-installer', { filePath }),
  
  // ============================================================================
  // CONFIGURATION FORTNITE & OBS
  // ============================================================================
  
  // Appliquer la configuration Fortnite (copie le fichier GameUserSettings.ini)
  // @param {string} configContent - Contenu du fichier de configuration
  // @returns {Promise<{success: boolean, message: string, filePath: string, error: string}>}
  applyFortniteConfig: (configContent) => ipcRenderer.invoke('apply-fortnite-config', { configContent }),
  
  // Lire la configuration Fortnite actuelle depuis le jeu
  // @returns {Promise<{success: boolean, content: string, error: string}>}
  readFortniteConfig: () => ipcRenderer.invoke('read-fortnite-config'),
  
  // Identifier les paramètres Fortnite actuels (temps réel)
  // @returns {Promise<{success: boolean, settings: Object, error: string}>}
  identifyFortniteSettings: () => ipcRenderer.invoke('identify-fortnite-settings'),
  
  // Appliquer le profil OBS
  // @param {string} gpuType - Type de GPU ('NVIDIA' ou 'AMD')
  // @returns {Promise<{success: boolean, message: string, filesCreated: string[], profilePath: string, error: string}>}
  applyObsProfile: (gpuType) => ipcRenderer.invoke('apply-obs-profile', { gpuType }),
  
  // Appliquer la configuration Fortnite via PowerShell
  // @param {Object} params - Paramètres Fortnite
  // @returns {Promise<{success: boolean, message: string, error: string, output: string}>}
  applyFortniteConfigPS: (params) => ipcRenderer.invoke('apply-fortnite-config-ps', { params }),
  
  // Vérifier si Fortnite est installé
  // @returns {Promise<{success: boolean, installed: boolean}>}
  checkFortniteInstalled: () => ipcRenderer.invoke('check-fortnite-installed'),
  
  // Vérifier si OBS est installé
  // @returns {Promise<{success: boolean, installed: boolean}>}
  checkObsInstalled: () => ipcRenderer.invoke('check-obs-installed'),
  
  // ============================================================================
  // DÉTECTION CARTE MÈRE & INSTALLATION PILOTES
  // ============================================================================
  
  // Détecter automatiquement la carte mère
  // @returns {Promise<{success: boolean, motherboard: {manufacturer, brandId, model, serial}, cpu: {name, manufacturer, isIntel, isAMD}}>}
  detectMotherboard: () => ipcRenderer.invoke('detect-motherboard'),
  
  // Lancer le setup custom NVIDIA
  // @returns {Promise<{success: boolean, message: string, filePath: string}>}
  launchNvidiaSetup: () => ipcRenderer.invoke('install-nvcleaninstall'),
  
  // Installer les pilotes de carte mère
  // @param {Object} driverUrls - URLs des pilotes à installer {chipset: url, audio: url, lan: url, wifi: url}
  // @returns {Promise<{success: boolean, results: Array}>}
  installMotherboardDrivers: (driverUrls) => 
    ipcRenderer.invoke('install-motherboard-drivers', { driverUrls }),
  
  // Écouter la progression de l'installation des pilotes
  onDriverInstallProgress: (callback) => {
    ipcRenderer.on('driver-install-progress', (event, data) => callback(data));
  },
  
  // Supprimer le listener de progression
  removeDriverInstallProgressListener: () => {
    ipcRenderer.removeAllListeners('driver-install-progress');
  },
  
  // ============================================================================
  // LECTURE D'ÉTAT WINDOWS (pour synchronisation des toggles)
  // ============================================================================
  
  // Lire une valeur du registre Windows
  // @param {string} keyPath - Chemin de la clé (ex: HKLM\\SOFTWARE\\...)
  // @param {string} valueName - Nom de la valeur à lire
  // @returns {Promise<{success: boolean, value: any, error?: string}>}
  readRegistry: (keyPath, valueName) => ipcRenderer.invoke('read-registry', keyPath, valueName),
  
  // Lire le statut d'un service Windows
  // @param {string} serviceName - Nom du service
  // @returns {Promise<{success: boolean, status: string, error?: string}>}
  readServiceStatus: (serviceName) => ipcRenderer.invoke('read-service-status', serviceName),
  
  // Lire une configuration d'alimentation (powercfg)
  // @param {string} checkType - Type de vérification: 'activePlan' ou 'hibernateAvailable'
  // @returns {Promise<{success: boolean, value: any, error?: string}>}
  readPowercfg: (checkType) => ipcRenderer.invoke('read-powercfg', checkType),
  
  // Lire les états de plusieurs paramètres en une seule fois (batch)
  // @param {Array} requests - Tableau de {id, type, ...params}
  // @returns {Promise<Object>} - Objet {id: {success, value}}
  readMultipleStates: (requests) => ipcRenderer.invoke('read-multiple-states', requests),
  
  // ============================================================================
  // SURVEILLANCE EN TEMPS RÉEL DU GAME MODE
  // ============================================================================
  
  // Démarrer la surveillance du Game Mode
  // @returns {Promise<{success: boolean, message: string}>}
  startGameModeWatcher: () => ipcRenderer.invoke('start-game-mode-watcher'),
  
  // Arrêter la surveillance du Game Mode
  // @returns {Promise<{success: boolean, message: string}>}
  stopGameModeWatcher: () => ipcRenderer.invoke('stop-game-mode-watcher'),
  
  // Lire l'état actuel du Game Mode
  // @returns {Promise<{success: boolean, enabled: boolean, value: number}>}
  readGameModeState: () => ipcRenderer.invoke('read-game-mode-state'),
  
  // Écouter les changements du Game Mode en temps réel
  // @param {Function} callback - Fonction appelée quand le Game Mode change
  onGameModeChanged: (callback) => {
    ipcRenderer.on('game-mode-changed', (event, data) => callback(data));
  },
  
  // Retirer l'écouteur de changements du Game Mode
  removeGameModeListener: () => {
    ipcRenderer.removeAllListeners('game-mode-changed');
  },
  
  // ============================================================================
  // SETTINGS READER - Lecture générique des paramètres Windows
  // ============================================================================
  
  // Lire l'état d'un paramètre Windows
  // @param {string} id - ID du paramètre (ex: 'fast-startup', 'hibernate-enabled')
  // @returns {Promise<boolean | number | null>} État du paramètre
  readSetting: (id) => ipcRenderer.invoke('settings:read', id),
  
  // Lire plusieurs paramètres Windows en une seule fois
  // @param {string[]} ids - Liste des IDs des paramètres à lire
  // @returns {Promise<Object>} Objet {id: value}
  readMultipleSettings: (ids) => ipcRenderer.invoke('settings:read-multiple', ids),
  
  // ============================================================================
  // OOSU10 & SCRIPT EXECUTION
  // ============================================================================
  
  // Exécuter le script OOSU10 pour appliquer le profil de confidentialité
  // @returns {Promise<{success: boolean, message: string, output?: string}>}
  executeOOSU10: () => ipcRenderer.invoke('execute-oosu10'),
  
  // Exécuter un fichier .bat
  // @param {string} batFileName - Nom du fichier .bat à exécuter
  // @returns {Promise<{success: boolean, message: string, output?: string}>}
  executeBat: (batFileName) => ipcRenderer.invoke('execute-bat', batFileName),
  
  // Exécuter un script PowerShell personnalisé (.ps1)
  // @param {string} psFileName - Nom du fichier .ps1 à exécuter
  // @returns {Promise<{success: boolean, message: string, output?: string}>}
  executePS1Script: (psFileName) => ipcRenderer.invoke('execute-ps1-script', psFileName),
  
  // ============================================================================
  // WALLPAPERS MANAGEMENT
  // ============================================================================
  
  // Récupérer la liste des fonds d'écran depuis Desktop/wallpapers
  // @returns {Promise<{success: boolean, message: string, wallpapers: Array}>}
  getWallpapers: () => ipcRenderer.invoke('get-wallpapers'),
  
  // Appliquer un fond d'écran
  // @param {string} wallpaperPath - Chemin complet du fond d'écran
  // @returns {Promise<{success: boolean, message: string}>}
  setWallpaper: (wallpaperPath) => ipcRenderer.invoke('set-wallpaper', wallpaperPath),
  
  // Importer des fonds d'écran (ouvre une boîte de dialogue)
  // @returns {Promise<{success: boolean, message: string, imported: Array}>}
  importWallpaper: () => ipcRenderer.invoke('import-wallpaper'),
  
  // Supprimer un fond d'écran
  // @param {string} wallpaperPath - Chemin complet du fond d'écran à supprimer
  // @returns {Promise<{success: boolean, message: string}>}
  deleteWallpaper: (wallpaperPath) => ipcRenderer.invoke('delete-wallpaper', wallpaperPath),
  
  // ============================================================================
  // CHOCOLATEY - Installation d'applications
  // ============================================================================
  
  // Installer Chocolatey
  // @returns {Promise<{success: boolean, message: string, error?: string}>}
  installChocolatey: () => ipcRenderer.invoke('install-chocolatey'),
  
  // Mettre à jour toutes les applications via Chocolatey
  // @returns {Promise<{success: boolean, message: string, error?: string}>}
  chocoUpgradeAll: () => ipcRenderer.invoke('choco-upgrade-all'),
  
  // Installer une application via Chocolatey
  // @param {string} appKey - Clé de l'application (ex: 'chrome', 'vscode')
  // @returns {Promise<{success: boolean, message: string, error?: string}>}
  chocoInstallApp: (appKey) => ipcRenderer.invoke('choco-install-app', appKey)
});

// Log pour debug
console.log('Preload script loaded - electronAPI exposed with Apps & Autoruns support');
