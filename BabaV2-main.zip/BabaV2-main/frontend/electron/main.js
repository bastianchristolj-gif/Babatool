const { app, BrowserWindow, shell, ipcMain } = require('electron');
const path = require('path');
const https = require('https');
const http = require('http');
const fs = require('fs');
const os = require('os');
const { exec, spawn } = require('child_process');
const { readSetting, readMultipleSettings } = require('./settingsReader');

// ============================================================================
// CONFIGURATION
// ============================================================================

// URL du backend - IMPORTANT: 
// En développement local, le backend tourne sur 127.0.0.1:8001
// En production, utiliser l'URL du serveur distant
const isDev = !app.isPackaged;

// Utiliser l'URL publique pour la production (serveur de licences distant)
// et localhost pour le développement
const BACKEND_URL = isDev 
  ? 'http://127.0.0.1:8001'
  : 'http://213.32.22.177';

console.log('=== ELECTRON CONFIGURATION ===');
console.log('Backend URL:', BACKEND_URL);
console.log('Is Development:', isDev);
console.log('Platform:', process.platform);
console.log('=============================');

const ALLOWED_DOWNLOAD_DOMAINS = [
  'github.com',
  'objects.githubusercontent.com',
  'github-releases.githubusercontent.com',
  'release-assets.githubusercontent.com'
];

function isUrlAllowed(downloadUrl) {
  try {
    const parsed = new URL(downloadUrl);
    return ALLOWED_DOWNLOAD_DOMAINS.some(domain => 
      parsed.hostname === domain || parsed.hostname.endsWith('.' + domain)
    );
  } catch {
    return false;
  }
}

// Vérifier si on est admin
function checkAdmin() {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') {
      resolve(false);
      return;
    }
    exec('net session', (error) => {
      resolve(!error);
    });
  });
}

// ============================================================================
// FENÊTRE PRINCIPALE
// ============================================================================

let mainWindow;
let isAdmin = false;

async function createWindow() {
  isAdmin = await checkAdmin();
  console.log('Running as admin:', isAdmin);

  const preloadPath = isDev 
    ? path.join(__dirname, 'preload.js')
    : path.join(app.getAppPath(), 'electron', 'preload.js');

  console.log('App path:', app.getAppPath());
  console.log('Preload path:', preloadPath);
  console.log('Is dev:', isDev);

  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1200,
    minHeight: 700,
    frame: false,
    autoHideMenuBar: true,
    backgroundColor: '#0d0d0d',
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
      webSecurity: false,
      preload: preloadPath
    },
    icon: isDev 
      ? path.join(__dirname, '../public/logo.ico')
      : path.join(app.getAppPath(), 'build', 'logo.ico')
  });

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    if (isDev) {
      mainWindow.webContents.openDevTools();
    }
    
    // Démarrer la surveillance du Game Mode automatiquement
    setTimeout(() => {
      startGameModeWatcher(mainWindow);
    }, 2000); // Attendre 2s pour que le renderer soit prêt
  });

  if (isDev) {
    mainWindow.loadURL('http://localhost:3000');
  } else {
    const indexPath = path.join(app.getAppPath(), 'build', 'index.html');
    mainWindow.loadFile(indexPath);
  }

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.on('closed', () => {
    stopGameModeWatcher(); // Arrêter la surveillance
    mainWindow = null;
  });
}

// ============================================================================
// IPC HANDLERS - FENÊTRE
// ============================================================================

ipcMain.on('window-minimize', () => {
  if (mainWindow) mainWindow.minimize();
});

ipcMain.on('window-maximize', () => {
  if (mainWindow) {
    mainWindow.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize();
  }
});

ipcMain.on('window-close', () => {
  if (mainWindow) mainWindow.close();
});

// ============================================================================
// IPC HANDLERS - SYSTÈME
// ============================================================================

// Vérifier si admin
ipcMain.handle('check-admin', () => isAdmin);

// Redémarrer en admin
ipcMain.handle('restart-as-admin', () => {
  if (process.platform !== 'win32') return { success: false, error: 'Windows only' };
  
  const appPath = app.getPath('exe');
  exec(`powershell -Command "Start-Process '${appPath}' -Verb RunAs"`, (error) => {
    if (!error) {
      app.quit();
    }
  });
  return { success: true };
});

// Obtenir les infos système
ipcMain.handle('get-system-info', async () => {
  const cpus = os.cpus();
  const totalMemory = os.totalmem();
  const freeMemory = os.freemem();
  const uptime = os.uptime();
  const hostname = os.hostname();
  const platform = os.platform();
  const arch = os.arch();
  const release = os.release();

  let osVersion = 'Unknown';
  let gpuName = 'Unknown';
  let storage = 'Unknown';

  if (platform === 'win32') {
    // Obtenir la version Windows
    try {
      const wmicOS = await new Promise((resolve) => {
        exec('wmic os get Caption /value', { encoding: 'utf8' }, (err, stdout) => {
          if (!err && stdout) {
            const match = stdout.match(/Caption=(.+)/);
            resolve(match ? match[1].trim() : `Windows ${release}`);
          } else {
            resolve(`Windows ${release}`);
          }
        });
      });
      osVersion = wmicOS;
    } catch {
      osVersion = `Windows ${release}`;
    }

    // Obtenir le GPU
    try {
      gpuName = await new Promise((resolve) => {
        exec('wmic path win32_VideoController get name /value', { encoding: 'utf8' }, (err, stdout) => {
          if (!err && stdout) {
            const match = stdout.match(/Name=(.+)/);
            resolve(match ? match[1].trim() : 'Unknown GPU');
          } else {
            resolve('Unknown GPU');
          }
        });
      });
    } catch {
      gpuName = 'Unknown GPU';
    }

    // Obtenir le stockage
    try {
      storage = await new Promise((resolve) => {
        exec('wmic logicaldisk where "DeviceID=\'C:\'" get Size,FreeSpace /value', { encoding: 'utf8' }, (err, stdout) => {
          if (!err && stdout) {
            const freeMatch = stdout.match(/FreeSpace=(\d+)/);
            const sizeMatch = stdout.match(/Size=(\d+)/);
            if (freeMatch && sizeMatch) {
              const freeGB = Math.round(parseInt(freeMatch[1]) / (1024 * 1024 * 1024));
              const totalGB = Math.round(parseInt(sizeMatch[1]) / (1024 * 1024 * 1024));
              resolve(`C: ${totalGB}GB (${freeGB}GB free)`);
            } else {
              resolve('Unknown');
            }
          } else {
            resolve('Unknown');
          }
        });
      });
    } catch {
      storage = 'Unknown';
    }
  }

  return {
    hostname,
    osVersion,
    cpuName: cpus[0]?.model || 'Unknown CPU',
    cpuCores: cpus.length,
    gpuName,
    totalMemory,
    freeMemory,
    storage,
    uptime,
    arch,
    platform,
    isAdmin,
    appVersion: app.getVersion()
  };
});

// ============================================================================
// IPC HANDLERS - POWERSHELL / CMD
// ============================================================================

// Exécuter des commandes PowerShell
ipcMain.handle('execute-powershell', async (event, commands) => {
  if (!Array.isArray(commands)) {
    commands = [commands];
  }

  const results = [];

  for (const cmd of commands) {
    try {
      const result = await new Promise((resolve) => {
        const script = cmd.script;
        
        // Vérifier si le script contient des retours à la ligne (script multiligne)
        const isMultiLine = script.includes('\n');
        
        if (isMultiLine) {
          // Pour les scripts multilignes, écrire dans un fichier temporaire
          const tempScript = path.join(os.tmpdir(), `babatool_ps_${Date.now()}_${Math.random().toString(36).substr(2, 9)}.ps1`);
          fs.writeFileSync(tempScript, script, 'utf8');
          
          exec(`powershell -ExecutionPolicy Bypass -File "${tempScript}"`, 
            { encoding: 'utf8', timeout: 30000 }, 
            (error, stdout, stderr) => {
              // Supprimer le fichier temporaire
              setTimeout(() => {
                try { fs.unlinkSync(tempScript); } catch(e) {}
              }, 100);
              
              resolve({
                command: cmd.command || 'PowerShell Script',
                success: !error,
                output: stdout?.trim() || '',
                error: error ? (stderr || error.message) : null
              });
            }
          );
        } else {
          // Pour les scripts sur une seule ligne, exécuter directement
          const escapedCmd = script.replace(/"/g, '\\"');
          const psCommand = `powershell -ExecutionPolicy Bypass -Command "${escapedCmd}"`;
          
          exec(psCommand, { encoding: 'utf8', timeout: 30000 }, (error, stdout, stderr) => {
            resolve({
              command: cmd.command || cmd.script,
              success: !error,
              output: stdout?.trim() || '',
              error: error ? (stderr || error.message) : null
            });
          });
        }
      });
      results.push(result);
    } catch (err) {
      results.push({
        command: cmd.command || cmd.script,
        success: false,
        output: '',
        error: err.message
      });
    }
  }

  return results;
});

// ============================================================================
// SURVEILLANCE EN TEMPS RÉEL DU GAME MODE
// ============================================================================

// Variable globale pour stocker l'intervalle de surveillance
let gameModeWatcherInterval = null;
let lastGameModeState = null;

/**
 * Lit l'état actuel du Game Mode depuis le registre Windows
 */
async function readGameModeState() {
  return new Promise((resolve) => {
    const command = 'reg query "HKCU\\Software\\Microsoft\\GameBar" /v AutoGameModeEnabled 2>nul';
    
    exec(command, { encoding: 'utf8', timeout: 5000 }, (error, stdout, stderr) => {
      if (error || !stdout) {
        // Si la clé n'existe pas ou erreur, considérer comme désactivé
        resolve({ success: true, enabled: false, value: 0 });
        return;
      }

      try {
        // Parser la sortie de reg query
        // Format: "    AutoGameModeEnabled    REG_DWORD    0x1"
        if (stdout.includes('AutoGameModeEnabled')) {
          const match = stdout.match(/0x([0-9a-fA-F]+)/);
          if (match) {
            const value = parseInt(match[1], 16);
            resolve({ 
              success: true, 
              enabled: value === 1, 
              value: value 
            });
            return;
          }
        }
        
        resolve({ success: true, enabled: false, value: 0 });
      } catch (parseError) {
        resolve({ success: false, error: parseError.message, enabled: false, value: 0 });
      }
    });
  });
}

/**
 * Démarre la surveillance du Game Mode
 * Vérifie l'état toutes les 2 secondes et envoie une notification si changement détecté
 */
function startGameModeWatcher(mainWindow) {
  if (process.platform !== 'win32') {
    console.log('Game Mode watcher: Windows uniquement');
    return;
  }

  // Arrêter le watcher existant si présent
  if (gameModeWatcherInterval) {
    clearInterval(gameModeWatcherInterval);
  }

  console.log('🎮 Game Mode watcher: Démarrage de la surveillance...');

  // Lire l'état initial
  readGameModeState().then(state => {
    lastGameModeState = state.enabled;
    console.log(`🎮 Game Mode état initial: ${state.enabled ? 'ACTIVÉ' : 'DÉSACTIVÉ'}`);
  });

  // Vérifier toutes les 2 secondes
  gameModeWatcherInterval = setInterval(async () => {
    const currentState = await readGameModeState();
    
    // Vérifier si l'état a changé
    if (currentState.success && currentState.enabled !== lastGameModeState) {
      console.log(`🎮 Game Mode CHANGEMENT DÉTECTÉ: ${lastGameModeState ? 'ACTIVÉ' : 'DÉSACTIVÉ'} → ${currentState.enabled ? 'ACTIVÉ' : 'DÉSACTIVÉ'}`);
      
      // Mettre à jour l'état mémorisé
      lastGameModeState = currentState.enabled;
      
      // Envoyer une notification au renderer process
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('game-mode-changed', {
          enabled: currentState.enabled,
          value: currentState.value,
          timestamp: new Date().toISOString()
        });
      }
    }
  }, 2000); // Vérifier toutes les 2 secondes

  console.log('✓ Game Mode watcher: Surveillance active (intervalle: 2s)');
}

/**
 * Arrête la surveillance du Game Mode
 */
function stopGameModeWatcher() {
  if (gameModeWatcherInterval) {
    clearInterval(gameModeWatcherInterval);
    gameModeWatcherInterval = null;
    console.log('🎮 Game Mode watcher: Surveillance arrêtée');
  }
}

// Handler IPC pour démarrer la surveillance
ipcMain.handle('start-game-mode-watcher', async (event) => {
  const mainWindow = BrowserWindow.fromWebContents(event.sender);
  startGameModeWatcher(mainWindow);
  return { success: true, message: 'Game Mode watcher démarré' };
});

// Handler IPC pour arrêter la surveillance
ipcMain.handle('stop-game-mode-watcher', async () => {
  stopGameModeWatcher();
  return { success: true, message: 'Game Mode watcher arrêté' };
});

// Handler IPC pour lire l'état actuel du Game Mode
ipcMain.handle('read-game-mode-state', async () => {
  const state = await readGameModeState();
  return state;
});

// ============================================================================
// SETTINGS READER - Lecture générique des paramètres Windows
// ============================================================================

/**
 * Handler IPC pour lire l'état d'un paramètre Windows
 * @param {string} id - ID du paramètre (ex: 'fast-startup', 'hibernate-enabled', 'game-mode')
 * @returns {Promise<boolean | number | null>} État du paramètre
 */
ipcMain.handle('settings:read', async (_event, id) => {
  if (process.platform !== 'win32') {
    console.log(`[settings:read] Not Windows, returning null for ${id}`);
    return null;
  }

  console.log(`[settings:read] Reading setting: ${id}`);
  const value = await readSetting(id);
  console.log(`[settings:read] ${id} = ${value}`);
  
  return value;
});

/**
 * Handler IPC pour lire plusieurs paramètres Windows en une fois
 * @param {string[]} ids - Liste des IDs des paramètres à lire
 * @returns {Promise<Object>} Objet {id: value}
 */
ipcMain.handle('settings:read-multiple', async (_event, ids) => {
  if (process.platform !== 'win32') {
    console.log(`[settings:read-multiple] Not Windows, returning empty object`);
    return {};
  }

  console.log(`[settings:read-multiple] Reading settings:`, ids);
  const values = await readMultipleSettings(ids);
  console.log(`[settings:read-multiple] Results:`, values);
  
  return values;
});

// Installer et lancer le setup NVIDIA via PowerShell (ancien handler - conservé pour compatibilité)
ipcMain.handle('install-nvidia-setup', async () => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows uniquement' };
  }

  return new Promise((resolve) => {
    try {
      // Chemin du script PowerShell
      const scriptPath = isDev
        ? path.join(__dirname, '..', 'src', 'configs', 'nvidia', 'NVIDIA.ps1')
        : path.join(process.resourcesPath, 'configs', 'nvidia', 'NVIDIA.ps1');

      console.log('Script PowerShell path:', scriptPath);

      // Vérifier que le script existe
      if (!fs.existsSync(scriptPath)) {
        resolve({
          success: false,
          error: `Script PowerShell introuvable: ${scriptPath}`
        });
        return;
      }

      // Lancer le script PowerShell avec -nvidia par défaut
      const command = `powershell -ExecutionPolicy Bypass -File "${scriptPath}" -nvidia`;
      
      console.log('Executing PowerShell command:', command);

      exec(command, { 
        encoding: 'utf8',
        timeout: 300000, // 5 minutes
        maxBuffer: 10 * 1024 * 1024 // 10 MB
      }, (error, stdout, stderr) => {
        console.log('PowerShell stdout:', stdout);
        if (stderr) console.error('PowerShell stderr:', stderr);
        
        if (error) {
          resolve({
            success: false,
            error: stderr || error.message,
            output: stdout
          });
        } else {
          resolve({
            success: true,
            message: 'Setup NVIDIA installé avec succès',
            output: stdout
          });
        }
      });
    } catch (err) {
      console.error('Error executing PowerShell:', err);
      resolve({
        success: false,
        error: err.message
      });
    }
  });
});

// Exécuter le script NVIDIA avec paramètre du jeu (-nvidia ou -callofduty)
ipcMain.handle('run-nvidia-script', async (event, gameParam) => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows uniquement' };
  }

  return new Promise((resolve) => {
    try {
      // Chemin du script PowerShell
      const scriptPath = isDev
        ? path.join(__dirname, '..', 'src', 'configs', 'nvidia', 'NVIDIA.ps1')
        : path.join(process.resourcesPath, 'configs', 'nvidia', 'NVIDIA.ps1');

      console.log('Script NVIDIA PowerShell path:', scriptPath);
      console.log('Game parameter:', gameParam);

      // Vérifier que le script existe
      if (!fs.existsSync(scriptPath)) {
        resolve({
          success: false,
          error: `Script PowerShell introuvable: ${scriptPath}`
        });
        return;
      }

      // Valider le paramètre (sécurité)
      const validParams = ['-nvidia', '-callofduty'];
      if (!validParams.includes(gameParam)) {
        resolve({
          success: false,
          error: `Paramètre invalide: ${gameParam}. Utilisez -nvidia ou -callofduty`
        });
        return;
      }

      // Lancer le script PowerShell avec le paramètre du jeu
      const command = `powershell -ExecutionPolicy Bypass -File "${scriptPath}" ${gameParam}`;
      
      console.log('Executing NVIDIA PowerShell command:', command);

      exec(command, { 
        encoding: 'utf8',
        timeout: 300000, // 5 minutes
        maxBuffer: 10 * 1024 * 1024 // 10 MB
      }, (error, stdout, stderr) => {
        console.log('NVIDIA PowerShell stdout:', stdout);
        if (stderr) console.error('NVIDIA PowerShell stderr:', stderr);
        
        if (error) {
          resolve({
            success: false,
            error: stderr || error.message,
            output: stdout
          });
        } else {
          resolve({
            success: true,
            message: `Setup ${gameParam === '-nvidia' ? 'Fortnite' : 'Call of Duty'} lancé avec succès`,
            output: stdout
          });
        }
      });
    } catch (err) {
      console.error('Error executing NVIDIA PowerShell:', err);
      resolve({
        success: false,
        error: err.message
      });
    }
  });
});

// Exécuter le script NVIDIA Profile Inspector (NPI.ps1)
ipcMain.handle('run-npi-script', async () => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows uniquement' };
  }

  return new Promise((resolve) => {
    try {
      // Chemin du script PowerShell NPI
      const scriptPath = isDev
        ? path.join(__dirname, '..', 'src', 'configs', 'nvidia', 'NPI.ps1')
        : path.join(process.resourcesPath, 'configs', 'nvidia', 'NPI.ps1');

      console.log('Script NPI PowerShell path:', scriptPath);

      // Vérifier que le script existe
      if (!fs.existsSync(scriptPath)) {
        resolve({
          success: false,
          error: `Script PowerShell NPI introuvable: ${scriptPath}`
        });
        return;
      }

      // Lancer le script PowerShell
      const command = `powershell -ExecutionPolicy Bypass -File "${scriptPath}"`;
      
      console.log('Executing NPI PowerShell command:', command);

      exec(command, { 
        encoding: 'utf8',
        timeout: 120000, // 2 minutes
        maxBuffer: 10 * 1024 * 1024
      }, (error, stdout, stderr) => {
        console.log('NPI PowerShell stdout:', stdout);
        if (stderr) console.error('NPI PowerShell stderr:', stderr);
        
        // Vérifier si le script a réussi
        const isSuccess = stdout && stdout.includes('[SUCCESS]');
        
        if (error && !isSuccess) {
          resolve({
            success: false,
            error: stderr || error.message,
            output: stdout
          });
        } else {
          resolve({
            success: true,
            message: 'Paramètres NVIDIA appliqués avec succès',
            output: stdout
          });
        }
      });
    } catch (err) {
      console.error('Error executing NPI PowerShell:', err);
      resolve({
        success: false,
        error: err.message
      });
    }
  });
});


// Exécuter une commande CMD
ipcMain.handle('execute-cmd', async (event, command) => {
  return new Promise((resolve) => {
    exec(command, { encoding: 'utf8', timeout: 30000 }, (error, stdout, stderr) => {
      resolve({
        success: !error,
        output: stdout?.trim() || '',
        error: error ? (stderr || error.message) : null
      });
    });
  });
});

// ============================================================================
// IPC HANDLERS - APPS INSTALLÉES & AUTORUNS
// ============================================================================

// Récupérer toutes les applications installées (non-système) - VRAIS BLOATWARES
ipcMain.handle('get-installed-apps', async () => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows only', apps: [] };
  }

  return new Promise((resolve) => {
    // Script PowerShell simplifié pour détecter les bloatwares
    const psScript = `
$ErrorActionPreference = 'SilentlyContinue'
$apps = @()

# Dictionnaire des noms d'affichage propres
$displayNames = @{
  'Microsoft.549981C3F5F10' = 'Cortana'
  'Microsoft.BingNews' = 'Bing News'
  'Microsoft.BingWeather' = 'Bing Weather'
  'Microsoft.GetHelp' = 'Get Help'
  'Microsoft.Getstarted' = 'Tips'
  'Microsoft.Microsoft3DViewer' = '3D Viewer'
  'Microsoft.MicrosoftOfficeHub' = 'Office Hub'
  'Microsoft.MicrosoftSolitaireCollection' = 'Solitaire Collection'
  'Microsoft.MixedReality.Portal' = 'Mixed Reality Portal'
  'Microsoft.People' = 'People'
  'Microsoft.SkypeApp' = 'Skype'
  'Microsoft.WindowsAlarms' = 'Alarms & Clock'
  'Microsoft.WindowsFeedbackHub' = 'Feedback Hub'
  'Microsoft.WindowsMaps' = 'Maps'
  'Microsoft.WindowsSoundRecorder' = 'Sound Recorder'
  'Microsoft.XboxApp' = 'Xbox App'
  'Microsoft.XboxGameOverlay' = 'Xbox Game Overlay'
  'Microsoft.XboxGamingOverlay' = 'Xbox Game Bar'
  'Microsoft.XboxIdentityProvider' = 'Xbox Identity Provider'
  'Microsoft.XboxSpeechToTextOverlay' = 'Xbox Speech To Text'
  'Microsoft.Xbox.TCUI' = 'Xbox TCUI'
  'Microsoft.YourPhone' = 'Phone Link'
  'Microsoft.ZuneMusic' = 'Groove Music'
  'Microsoft.ZuneVideo' = 'Movies & TV'
  'Microsoft.GamingApp' = 'Xbox App'
  'Clipchamp.Clipchamp' = 'Clipchamp'
  'MicrosoftTeams' = 'Microsoft Teams'
  'Microsoft.windowscommunicationsapps' = 'Mail and Calendar'
  'Microsoft.Todos' = 'Microsoft To Do'
  'Microsoft.PowerAutomateDesktop' = 'Power Automate'
  'Microsoft.Whiteboard' = 'Whiteboard'
  'Microsoft.MicrosoftStickyNotes' = 'Sticky Notes'
  'Microsoft.ScreenSketch' = 'Snipping Tool'
  'Microsoft.XboxGameCallableUI' = 'Xbox Game Callable UI'
}

# Liste des patterns de bloatwares connus
$bloatPatterns = @(
  'Microsoft.549981C3F5F10',
  'Microsoft.BingNews',
  'Microsoft.BingWeather',
  'Microsoft.GetHelp',
  'Microsoft.Getstarted',
  'Microsoft.Microsoft3DViewer',
  'Microsoft.MicrosoftOfficeHub',
  'Microsoft.MicrosoftSolitaireCollection',
  'Microsoft.MixedReality.Portal',
  'Microsoft.People',
  'Microsoft.SkypeApp',
  'Microsoft.WindowsAlarms',
  'Microsoft.WindowsFeedbackHub',
  'Microsoft.WindowsMaps',
  'Microsoft.WindowsSoundRecorder',
  'Microsoft.Xbox',
  'Microsoft.XboxApp',
  'Microsoft.XboxGameOverlay',
  'Microsoft.XboxGamingOverlay',
  'Microsoft.XboxIdentityProvider',
  'Microsoft.XboxSpeechToTextOverlay',
  'Microsoft.YourPhone',
  'Microsoft.ZuneMusic',
  'Microsoft.ZuneVideo',
  'Microsoft.GamingApp',
  'Clipchamp',
  'MicrosoftTeams',
  'Microsoft.windowscommunicationsapps',
  'Microsoft.Todos',
  'Microsoft.PowerAutomateDesktop',
  'Microsoft.Whiteboard',
  'Microsoft.MicrosoftStickyNotes',
  'Microsoft.ScreenSketch',
  'king.com',
  'SpotifyAB',
  'Disney',
  'BytedancePte',
  'Facebook',
  'AmazonVideo',
  'WhatsApp'
)

Get-AppxPackage | ForEach-Object {
  $pkg = $_
  $isBloat = $false
  
  foreach ($pattern in $bloatPatterns) {
    if ($pkg.Name -like "*$pattern*") {
      $isBloat = $true
      break
    }
  }
  
  if ($isBloat -and $pkg.IsFramework -eq $false) {
    $cat = 'Application'
    if ($pkg.Name -match 'Xbox|Gaming') { $cat = 'Gaming' }
    elseif ($pkg.Name -match 'Zune|Music|Video|Clipchamp') { $cat = 'Media' }
    elseif ($pkg.Name -match 'Bing') { $cat = 'Bing Services' }
    elseif ($pkg.Name -match 'Phone|People|Mail|Teams|communication') { $cat = 'Communication' }
    elseif ($pkg.Name -match 'king|Spotify|Disney|Facebook|TikTok|Amazon|WhatsApp') { $cat = 'Third-Party' }
    
    # Utiliser le nom d'affichage du dictionnaire ou formater le nom
    $dispName = $displayNames[$pkg.Name]
    if (-not $dispName) {
      # Fallback: formater le nom automatiquement
      $dispName = $pkg.Name -replace '^Microsoft[.]', '' -replace '_.*$', ''
    }
    
    $apps += [PSCustomObject]@{
      name = $dispName
      fullName = $pkg.Name
      packageName = $pkg.PackageFullName
      publisher = 'Microsoft'
      version = $pkg.Version.ToString()
      type = 'UWP'
      category = $cat
      isBloatware = $true
    }
  }
}

if ($apps.Count -gt 0) {
  $apps | ConvertTo-Json -Compress
} else {
  '[]'
}
`;

    // Écrire le script dans un fichier temporaire pour éviter les problèmes d'échappement
    const tempScript = path.join(os.tmpdir(), 'babatool_scan_apps.ps1');
    fs.writeFileSync(tempScript, psScript, 'utf8');
    
    exec(`powershell -ExecutionPolicy Bypass -File "${tempScript}"`, 
      { encoding: 'utf8', maxBuffer: 10 * 1024 * 1024, timeout: 120000 }, 
      (error, stdout, stderr) => {
        // Supprimer le fichier temporaire
        try { fs.unlinkSync(tempScript); } catch(e) {}
        
        if (error) {
          console.error('Scan error:', error.message, stderr);
          resolve({ success: false, error: error.message + ' | ' + stderr, apps: [] });
          return;
        }
        
        try {
          let apps = [];
          const output = stdout.trim();
          if (output && output !== '[]') {
            const parsed = JSON.parse(output);
            apps = Array.isArray(parsed) ? parsed : [parsed];
          }
          resolve({ success: true, apps });
        } catch (parseError) {
          console.error('Parse error:', parseError.message, 'Output:', stdout);
          resolve({ success: false, error: 'Parse error: ' + parseError.message, apps: [] });
        }
      }
    );
  });
});

// Désinstaller une application UWP (bloatware)
ipcMain.handle('uninstall-uwp-app', async (event, { packageName }) => {
  if (process.platform !== 'win32' || !packageName) {
    return { success: false, error: 'Invalid request' };
  }

  return new Promise((resolve) => {
    const psScript = `Get-AppxPackage -Name "*${packageName.split('_')[0]}*" | Remove-AppxPackage -ErrorAction SilentlyContinue; Write-Output "DONE"`;
    
    exec(`powershell -ExecutionPolicy Bypass -Command "${psScript}"`, 
      { encoding: 'utf8', timeout: 60000 }, 
      (error, stdout, stderr) => {
        resolve({ success: true });
      }
    );
  });
});

// Récupérer les programmes au démarrage via les clés de registre Run
ipcMain.handle('get-autoruns', async () => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows only', autoruns: [] };
  }

  return new Promise((resolve) => {
    // Script PowerShell pour les autoruns - Compatible avec le Gestionnaire des tâches Windows
    const psScript = `
$ErrorActionPreference = 'SilentlyContinue'
$autoruns = @()

# Fonction pour lire les entrées d'une clé de registre
function Get-RegistryRunEntries {
  param(
    [string]$KeyPath,
    [string]$LocationName
  )
  
  try {
    # Utiliser Get-Item pour accéder à la clé
    $key = Get-Item -Path $KeyPath -ErrorAction Stop
    
    # Lire toutes les valeurs
    $key.GetValueNames() | ForEach-Object {
      $valueName = $_
      if ($valueName -and $valueName -ne '') {
        $valueData = $key.GetValue($valueName)
        if ($valueData) {
          $script:autoruns += [PSCustomObject]@{
            name = $valueName
            command = $valueData.ToString()
            location = $LocationName
            enabled = $true
            type = 'Registry'
          }
        }
      }
    }
  } catch {
    # Clé non trouvée ou erreur d'accès - ignorer silencieusement
  }
}

# ========== CLÉS DE REGISTRE RUN ==========

# HKLM Run (64-bit)
Get-RegistryRunEntries -KeyPath 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run' -LocationName 'HKLM\\Run'

# HKLM Run (32-bit / WOW6432Node) - Accès direct via Registry provider
Get-RegistryRunEntries -KeyPath 'HKLM:\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Run' -LocationName 'HKLM\\WOW6432Node\\Run'

# HKCU Run
Get-RegistryRunEntries -KeyPath 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run' -LocationName 'HKCU\\Run'

# HKCU WOW6432Node Run
Get-RegistryRunEntries -KeyPath 'HKCU:\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Run' -LocationName 'HKCU\\WOW6432Node\\Run'

# ========== MÉTHODE ALTERNATIVE POUR WOW6432Node (si la première échoue) ==========
# Utiliser reg.exe pour lire WOW6432Node car PowerShell peut avoir des problèmes de redirection

$wow64Entries = reg query "HKLM\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Run" 2>$null
if ($wow64Entries) {
  $wow64Entries | ForEach-Object {
    $line = $_.Trim()
    if ($line -match '^\\s*(.+?)\\s+(REG_SZ|REG_EXPAND_SZ)\\s+(.+)$') {
      $entryName = $Matches[1].Trim()
      $entryValue = $Matches[3].Trim()
      
      # Vérifier si déjà ajouté
      $exists = $autoruns | Where-Object { $_.name -eq $entryName -and $_.location -eq 'HKLM\\WOW6432Node\\Run' }
      if (-not $exists -and $entryName -ne '(Default)') {
        $autoruns += [PSCustomObject]@{
          name = $entryName
          command = $entryValue
          location = 'HKLM\\WOW6432Node\\Run'
          enabled = $true
          type = 'Registry'
        }
      }
    }
  }
}

# ========== DOSSIERS STARTUP ==========

# Startup Folder (utilisateur actuel)
$startupPath = [Environment]::GetFolderPath('Startup')
if (Test-Path $startupPath) {
  Get-ChildItem $startupPath -File -ErrorAction SilentlyContinue | ForEach-Object {
    $autoruns += [PSCustomObject]@{
      name = $_.BaseName
      command = $_.FullName
      location = 'Startup Folder'
      enabled = $true
      type = 'Shortcut'
    }
  }
}

# Startup Folder (tous les utilisateurs)
$commonStartup = [Environment]::GetFolderPath('CommonStartup')
if (Test-Path $commonStartup) {
  Get-ChildItem $commonStartup -File -ErrorAction SilentlyContinue | ForEach-Object {
    $autoruns += [PSCustomObject]@{
      name = $_.BaseName
      command = $_.FullName
      location = 'Common Startup Folder'
      enabled = $true
      type = 'Shortcut'
    }
  }
}

# ========== VÉRIFIER STARTUPAPPROVED (Gestionnaire des tâches Windows) ==========

# Run = 64-bit apps, Run32 = 32-bit apps (WOW6432Node)
$approvedPaths = @(
  @{ 
    Path = 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run'
    Locations = @('HKCU\\Run')
  },
  @{ 
    Path = 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run32'
    Locations = @('HKCU\\WOW6432Node\\Run')
  },
  @{ 
    Path = 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run'
    Locations = @('HKLM\\Run')
  },
  @{ 
    Path = 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run32'
    Locations = @('HKLM\\WOW6432Node\\Run')
  },
  @{ 
    Path = 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\StartupFolder'
    Locations = @('Startup Folder')
  },
  @{ 
    Path = 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\StartupFolder'
    Locations = @('Common Startup Folder')
  }
)

foreach ($approvedInfo in $approvedPaths) {
  try {
    $key = Get-Item -Path $approvedInfo.Path -ErrorAction Stop
    $key.GetValueNames() | ForEach-Object {
      $propName = $_
      if ($propName -and $propName -ne '') {
        $bytes = $key.GetValue($propName)
        
        if ($bytes -and $bytes.Length -ge 1) {
          $firstByte = [int]$bytes[0]
          $isDisabled = ($firstByte -eq 0) -or ($firstByte -eq 3) -or ($firstByte -eq 7)
          
          foreach ($loc in $approvedInfo.Locations) {
            $match = $autoruns | Where-Object { $_.name -eq $propName -and $_.location -eq $loc }
            if ($match) {
              $match.enabled = -not $isDisabled
            }
          }
          
          # Pour les raccourcis
          $nameWithoutLnk = $propName -replace '\\.lnk$', ''
          $matchShortcut = $autoruns | Where-Object { $_.name -eq $nameWithoutLnk -and ($_.location -eq 'Startup Folder' -or $_.location -eq 'Common Startup Folder') }
          if ($matchShortcut) {
            $matchShortcut | ForEach-Object { $_.enabled = -not $isDisabled }
          }
        }
      }
    }
  } catch {
    # Clé non trouvée
  }
}

# Sortie JSON
if ($autoruns.Count -gt 0) {
  $autoruns | ConvertTo-Json -Compress
} else {
  '[]'
}
`;

    // Écrire le script dans un fichier temporaire
    const tempScript = path.join(os.tmpdir(), 'babatool_scan_autoruns.ps1');
    fs.writeFileSync(tempScript, psScript, 'utf8');
    
    exec(`powershell -ExecutionPolicy Bypass -File "${tempScript}"`, 
      { encoding: 'utf8', maxBuffer: 5 * 1024 * 1024, timeout: 60000 }, 
      (error, stdout, stderr) => {
        // Supprimer le fichier temporaire
        try { fs.unlinkSync(tempScript); } catch(e) {}
        
        if (error) {
          console.error('Autoruns error:', error.message, stderr);
          resolve({ success: false, error: error.message, autoruns: [] });
          return;
        }
        
        try {
          let autoruns = [];
          const output = stdout.trim();
          if (output && output !== '[]') {
            const parsed = JSON.parse(output);
            autoruns = Array.isArray(parsed) ? parsed : [parsed];
          }
          resolve({ success: true, autoruns });
        } catch (parseError) {
          console.error('Autoruns parse error:', parseError.message, 'Output:', stdout);
          resolve({ success: false, error: 'Parse error', autoruns: [] });
        }
      }
    );
  });
});

// Désinstaller une application
ipcMain.handle('uninstall-app', async (event, { uninstallString }) => {
  if (!uninstallString) {
    return { success: false, error: 'No uninstall string provided' };
  }

  return new Promise((resolve) => {
    // Ajouter /S ou /silent pour désinstallation silencieuse si possible
    let cmd = uninstallString;
    if (!cmd.toLowerCase().includes('/s') && !cmd.toLowerCase().includes('/silent') && !cmd.toLowerCase().includes('/quiet')) {
      if (cmd.toLowerCase().includes('msiexec')) {
        cmd += ' /qn';
      } else {
        cmd += ' /S';
      }
    }

    exec(cmd, { encoding: 'utf8', timeout: 120000 }, (error, stdout, stderr) => {
      resolve({
        success: !error,
        output: stdout?.trim() || '',
        error: error ? (stderr || error.message) : null
      });
    });
  });
});

// Activer/Désactiver un autorun
ipcMain.handle('toggle-autorun', async (event, { name, location, enabled, command }) => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows only' };
  }

  return new Promise((resolve) => {
    // Déterminer le chemin StartupApproved selon la location
    // WOW6432Node (32-bit) utilise StartupApproved\Run32, pas Run
    let approvedPath = '';
    let entryName = name;
    
    if (location === 'HKLM\\Run') {
      approvedPath = 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run';
    } else if (location === 'HKLM\\WOW6432Node\\Run') {
      // 32-bit apps utilisent Run32
      approvedPath = 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run32';
    } else if (location === 'HKCU\\Run') {
      approvedPath = 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run';
    } else if (location === 'HKCU\\WOW6432Node\\Run') {
      // 32-bit apps utilisent Run32
      approvedPath = 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run32';
    } else if (location === 'Startup Folder') {
      approvedPath = 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\StartupFolder';
      if (!entryName.endsWith('.lnk')) entryName = name + '.lnk';
    } else if (location === 'Common Startup Folder') {
      approvedPath = 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\StartupFolder';
      if (!entryName.endsWith('.lnk')) entryName = name + '.lnk';
    } else if (location.includes('WOW6432Node')) {
      // Fallback pour WOW6432Node
      if (location.includes('HKLM')) {
        approvedPath = 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run32';
      } else {
        approvedPath = 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run32';
      }
    } else if (location.includes('HKLM')) {
      approvedPath = 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run';
    } else if (location.includes('HKCU')) {
      approvedPath = 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run';
    }
    
    if (!approvedPath) {
      resolve({ success: false, error: 'Location non supportée: ' + location });
      return;
    }
    
    // Script PowerShell pour modifier StartupApproved
    const psScript = `
$ErrorActionPreference = 'Stop'
$approvedPath = '${approvedPath}'
$entryName = '${entryName.replace(/'/g, "''")}'

try {
    # Créer la clé si elle n'existe pas
    if (-not (Test-Path $approvedPath)) {
        New-Item -Path $approvedPath -Force | Out-Null
    }
    
    # 02 = activé, 03 = désactivé
    $bytes = [byte[]](${enabled ? '0x03' : '0x02'}, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00)
    
    # Écrire dans le registre
    Set-ItemProperty -Path $approvedPath -Name $entryName -Value $bytes -Type Binary -Force
    
    Write-Output "OK"
} catch {
    Write-Output "FAIL: $_"
}
`;

    const tempScript = path.join(os.tmpdir(), 'babatool_toggle_' + Date.now() + '.ps1');
    fs.writeFileSync(tempScript, psScript, 'utf8');
    
    exec(`powershell -ExecutionPolicy Bypass -File "${tempScript}"`, 
      { encoding: 'utf8', timeout: 10000, windowsHide: true }, 
      (error, stdout, stderr) => {
        // Nettoyer le fichier temp
        setTimeout(() => {
          try { fs.unlinkSync(tempScript); } catch(e) {}
        }, 100);
        
        const output = stdout ? stdout.trim() : '';
        const success = output.includes('OK');
        
        if (!success) {
          console.error('Toggle autorun failed:', output, stderr);
        }
        
        resolve({ success, error: success ? null : output || 'Échec' });
      }
    );
  });
});

// Ouvrir un lien externe
ipcMain.handle('open-external', async (event, url) => {
  shell.openExternal(url);
  return { success: true };
});

// ============================================================================
// IPC HANDLERS - MISE À JOUR
// ============================================================================

ipcMain.handle('download-update', async (event, { url: downloadUrl, version }) => {
  if (!downloadUrl || !isUrlAllowed(downloadUrl)) {
    return { success: false, error: 'URL non autorisée' };
  }

  const tempDir = os.tmpdir();
  const fileName = `BaBaTool-Setup-${version}.exe`;
  const filePath = path.join(tempDir, fileName);

  return new Promise((resolve) => {
    const downloadWithRedirect = (currentUrl, redirectCount = 0) => {
      if (redirectCount > 5) {
        resolve({ success: false, error: 'Trop de redirections' });
        return;
      }

      const protocol = currentUrl.startsWith('https') ? https : http;
      
      const request = protocol.get(currentUrl, (response) => {
        if ([301, 302, 303, 307, 308].includes(response.statusCode)) {
          const redirectUrl = response.headers.location;
          if (redirectUrl) {
            downloadWithRedirect(redirectUrl, redirectCount + 1);
            return;
          }
        }

        if (response.statusCode !== 200) {
          resolve({ success: false, error: `HTTP ${response.statusCode}` });
          return;
        }

        const totalSize = parseInt(response.headers['content-length'], 10) || 0;
        let downloadedSize = 0;
        const file = fs.createWriteStream(filePath);

        response.on('data', (chunk) => {
          downloadedSize += chunk.length;
          const percentage = totalSize > 0 ? Math.round((downloadedSize / totalSize) * 100) : 0;
          event.sender.send('download-progress', { percentage, downloadedSize, totalSize, status: 'downloading' });
        });

        response.pipe(file);
        file.on('finish', () => {
          file.close();
          event.sender.send('download-progress', { percentage: 100, status: 'completed' });
          resolve({ success: true, filePath });
        });
        file.on('error', (err) => {
          fs.unlink(filePath, () => {});
          resolve({ success: false, error: err.message });
        });
      });

      request.on('error', (err) => resolve({ success: false, error: err.message }));
      request.setTimeout(30000, () => {
        request.destroy();
        resolve({ success: false, error: 'Timeout' });
      });
    };

    downloadWithRedirect(downloadUrl);
  });
});

ipcMain.handle('run-silent-installer', async (event, { filePath }) => {
  if (!filePath || !filePath.endsWith('.exe') || !fs.existsSync(filePath)) {
    return { success: false, error: 'Fichier invalide' };
  }

  return new Promise((resolve) => {
    try {
      const appName = 'BaBaTool';
      const tempDir = os.tmpdir();
      const batchPath = path.join(tempDir, 'babatool_update.bat');
      
      // Créer un script batch qui:
      // 1. Attend que l'ancienne app se ferme
      // 2. Lance l'installateur silencieux
      // 3. Attend la fin de l'installation
      // 4. Lance la nouvelle app
      // 5. Se supprime lui-même
      const batchContent = `@echo off
timeout /t 2 /nobreak >nul
start /wait "" "${filePath}" /S
timeout /t 3 /nobreak >nul
set "appPath1=%LOCALAPPDATA%\\Programs\\${appName}\\${appName}.exe"
set "appPath2=%PROGRAMFILES%\\${appName}\\${appName}.exe"
set "appPath3=%PROGRAMFILES(X86)%\\${appName}\\${appName}.exe"
if exist "%appPath1%" (
    start "" "%appPath1%"
    goto :cleanup
)
if exist "%appPath2%" (
    start "" "%appPath2%"
    goto :cleanup
)
if exist "%appPath3%" (
    start "" "%appPath3%"
    goto :cleanup
)
:cleanup
timeout /t 2 /nobreak >nul
del "%~f0"
`;
      
      // Écrire le script batch
      fs.writeFileSync(batchPath, batchContent, { encoding: 'utf8' });
      
      // Lancer le script batch de manière détachée
      const batch = spawn('cmd.exe', ['/c', batchPath], {
        detached: true,
        stdio: 'ignore',
        windowsHide: true
      });
      batch.unref();
      
      // Fermer l'app actuelle après un court délai
      setTimeout(() => {
        app.quit();
      }, 1000);
      
      resolve({ success: true });
    } catch (error) {
      resolve({ success: false, error: error.message });
    }
  });
});

ipcMain.handle('get-app-version', () => app.getVersion());

// ============================================================================
// IPC HANDLERS - CONFIGURATION FORTNITE & OBS
// ============================================================================

// Appliquer la configuration Fortnite
ipcMain.handle('apply-fortnite-config', async (event, { configContent }) => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows uniquement' };
  }

  return new Promise((resolve) => {
    try {
      const localAppData = process.env.LOCALAPPDATA;
      if (!localAppData) {
        resolve({ 
          success: false, 
          error: 'Variable LOCALAPPDATA non trouvée'
        });
        return;
      }

      const fortnitePath = path.join(localAppData, 'FortniteGame', 'Saved', 'Config', 'WindowsClient');
      const fortniteConfigFile = path.join(fortnitePath, 'GameUserSettings.ini');

      // Créer le dossier Fortnite si nécessaire
      if (!fs.existsSync(fortnitePath)) {
        fs.mkdirSync(fortnitePath, { recursive: true });
      }

      // Supprimer l'attribut lecture seule si le fichier existe
      if (fs.existsSync(fortniteConfigFile)) {
        try {
          // Utiliser attrib pour supprimer l'attribut lecture seule
          exec(`attrib -R "${fortniteConfigFile}"`, { timeout: 5000 }, () => {});
        } catch (e) {
          console.log('Could not remove read-only attribute:', e.message);
        }
        
        // Créer une sauvegarde de l'ancien fichier
        const backupFile = path.join(fortnitePath, `GameUserSettings_backup_${Date.now()}.ini`);
        try {
          fs.copyFileSync(fortniteConfigFile, backupFile);
          console.log('Backup created:', backupFile);
        } catch (backupErr) {
          console.log('Backup failed (continuing anyway):', backupErr.message);
        }
      }

      // Écrire le nouveau fichier
      try {
        fs.writeFileSync(fortniteConfigFile, configContent, 'utf8');
        console.log('Fortnite config written to:', fortniteConfigFile);

        resolve({ 
          success: true, 
          message: 'Configuration Fortnite appliquée avec succès',
          fortniteConfigFile
        });
      } catch (writeErr) {
        // Si l'écriture échoue, essayer via PowerShell
        console.error('Direct write failed, trying PowerShell:', writeErr.message);
        
        const psScript = `
$configPath = "${fortniteConfigFile.replace(/\\/g, '\\\\')}"
$content = @'
${configContent}
'@

# Supprimer l'attribut lecture seule
if (Test-Path $configPath) {
  attrib -R "$configPath"
  Set-ItemProperty -Path $configPath -Name IsReadOnly -Value $false -ErrorAction SilentlyContinue
}

# Écrire le fichier
$content | Out-File -FilePath $configPath -Encoding UTF8 -Force
Write-Output "OK"
`;
        const tempScript = path.join(os.tmpdir(), `babatool_fn_${Date.now()}.ps1`);
        fs.writeFileSync(tempScript, psScript, 'utf8');

        exec(`powershell -ExecutionPolicy Bypass -File "${tempScript}"`, {
          encoding: 'utf8',
          timeout: 15000
        }, (psErr, psStdout, psStderr) => {
          try { fs.unlinkSync(tempScript); } catch(e) {}

          if (psErr || !psStdout.includes('OK')) {
            resolve({ 
              success: false, 
              error: `Erreur de permission (EPERM). Essayez d'exécuter l'application en tant qu'administrateur. Détails: ${psStderr || psErr?.message || 'Inconnu'}`
            });
          } else {
            resolve({ 
              success: true, 
              message: 'Configuration Fortnite appliquée avec succès',
              fortniteConfigFile
            });
          }
        });
      }
    } catch (error) {
      console.error('Error applying Fortnite config:', error);
      resolve({ success: false, error: error.message });
    }
  });
});

// Lire la configuration Fortnite actuelle depuis le jeu
ipcMain.handle('read-fortnite-config', async () => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows uniquement' };
  }

  return new Promise((resolve) => {
    try {
      const localAppData = process.env.LOCALAPPDATA;
      if (!localAppData) {
        resolve({ success: false, error: 'Variable LOCALAPPDATA non trouvée' });
        return;
      }

      const configFile = path.join(localAppData, 'FortniteGame', 'Saved', 'Config', 'WindowsClient', 'GameUserSettings.ini');

      if (!fs.existsSync(configFile)) {
        resolve({ success: false, error: 'Fichier de configuration Fortnite non trouvé' });
        return;
      }

      const content = fs.readFileSync(configFile, 'utf8');
      resolve({ success: true, content });
    } catch (error) {
      resolve({ success: false, error: error.message });
    }
  });
});

// Appliquer le profil OBS
ipcMain.handle('apply-obs-profile', async (event, { gpuType }) => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows uniquement' };
  }

  return new Promise((resolve) => {
    try {
      const appData = process.env.APPDATA;
      if (!appData) {
        resolve({ success: false, error: 'Variable APPDATA non trouvée' });
        return;
      }

      // Chemin du profil OBS
      const profileName = 'BabaTool';
      const obsProfilePath = path.join(appData, 'obs-studio', 'basic', 'profiles', profileName);

      // Créer le dossier du profil
      if (!fs.existsSync(obsProfilePath)) {
        fs.mkdirSync(obsProfilePath, { recursive: true });
      }

      // Chemin source des fichiers OBS (dans l'app)
      const gpuFolder = gpuType.toUpperCase(); // "NVIDIA" or "AMD"
      let sourceDir;
      
      if (isDev) {
        // En dev: depuis src/configs/obs
        sourceDir = path.join(__dirname, '..', 'src', 'configs', 'obs', gpuFolder);
      } else {
        // En prod: depuis les resources de l'app
        sourceDir = path.join(process.resourcesPath, 'configs', 'obs', gpuFolder);
      }

      console.log('Source OBS config:', sourceDir);
      console.log('Destination:', obsProfilePath);

      // Vérifier que le dossier source existe
      if (!fs.existsSync(sourceDir)) {
        resolve({ 
          success: false, 
          error: `Dossier source introuvable: ${sourceDir}` 
        });
        return;
      }

      // Copier tous les fichiers
      const filesCreated = [];
      const files = fs.readdirSync(sourceDir);
      
      for (const fileName of files) {
        const sourcePath = path.join(sourceDir, fileName);
        const destPath = path.join(obsProfilePath, fileName);
        
        // Vérifier que c'est un fichier (pas un dossier)
        if (fs.statSync(sourcePath).isFile()) {
          fs.copyFileSync(sourcePath, destPath);
          filesCreated.push(fileName);
          console.log(`Fichier copié: ${fileName}`);
        }
      }

      resolve({ 
        success: true, 
        message: `Profil OBS ${gpuType.toUpperCase()} appliqué avec succès`,
        filesCreated,
        profilePath: obsProfilePath
      });
    } catch (error) {
      console.error('Erreur apply-obs-profile:', error);
      resolve({ success: false, error: error.message });
    }
  });
});

// Vérifier si Fortnite est installé
ipcMain.handle('check-fortnite-installed', async () => {
  if (process.platform !== 'win32') {
    return { success: false, installed: false };
  }

  return new Promise((resolve) => {
    const localAppData = process.env.LOCALAPPDATA;
    if (!localAppData) {
      resolve({ success: true, installed: false });
      return;
    }

    const fortnitePath = path.join(localAppData, 'FortniteGame');
    resolve({ success: true, installed: fs.existsSync(fortnitePath) });
  });
});

// Vérifier si OBS est installé
ipcMain.handle('check-obs-installed', async () => {
  if (process.platform !== 'win32') {
    return { success: false, installed: false };
  }

  return new Promise((resolve) => {
    const appData = process.env.APPDATA;
    if (!appData) {
      resolve({ success: true, installed: false });
      return;
    }

    const obsPath = path.join(appData, 'obs-studio');
    resolve({ success: true, installed: fs.existsSync(obsPath) });
  });
});

// ============================================================================
// IPC HANDLERS - PROXY API VERS BACKEND LOCAL
// ============================================================================

// Proxy pour les requêtes vers le backend (local ou distant)
// IMPORTANT: Gère HTTP (dev) et HTTPS (production)
ipcMain.handle('api-request', async (event, { method, endpoint, data }) => {
  console.log('=== IPC API REQUEST ===');
  console.log('Method:', method);
  console.log('Endpoint:', endpoint);
  console.log('Data:', data);
  console.log('BACKEND_URL:', BACKEND_URL);
  
  return new Promise((resolve) => {
    try {
      // Parser l'URL pour extraire le host et le port
      const fullUrl = `${BACKEND_URL}${endpoint}`;
      const urlObj = new URL(fullUrl);
      const isHttps = urlObj.protocol === 'https:';
      const port = parseInt(urlObj.port) || (isHttps ? 443 : 80);
      const pathname = urlObj.pathname + urlObj.search;
      
      console.log(`[API Proxy] ${method} ${fullUrl}`);
      console.log(`[API Proxy] Host: ${urlObj.hostname}, Port: ${port}, HTTPS: ${isHttps}`);
      
      // Options de requête
      const options = {
        hostname: urlObj.hostname,
        port: port,
        path: pathname,
        method: method,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Host': urlObj.host
        }
      };
      
      // Pour les requêtes locales, forcer IPv4
      if (urlObj.hostname === 'localhost' || urlObj.hostname === '127.0.0.1') {
        options.hostname = '127.0.0.1';
        options.family = 4; // Forcer IPv4
      }
      
      console.log('[API Proxy] Options:', JSON.stringify(options, null, 2));
      
      // Choisir le protocole approprié
      const protocol = isHttps ? https : http;
      
      const req = protocol.request(options, (res) => {
        let body = '';
        
        res.on('data', (chunk) => {
          body += chunk;
        });
        
        res.on('end', () => {
          console.log('[API Proxy] Response status:', res.statusCode);
          console.log('[API Proxy] Response body:', body.substring(0, 500));
          try {
            const jsonData = JSON.parse(body);
            resolve({
              success: true,
              status: res.statusCode,
              data: jsonData
            });
          } catch (e) {
            console.error('[API Proxy] Parse error:', e.message);
            resolve({
              success: false,
              error: `Erreur de parsing: ${e.message}`,
              body: body
            });
          }
        });
      });
      
      req.on('error', (error) => {
        console.error(`[API Proxy] Erreur réseau:`, error);
        console.error(`[API Proxy] Error code:`, error.code);
        console.error(`[API Proxy] Error address:`, error.address);
        console.error(`[API Proxy] Error port:`, error.port);
        resolve({
          success: false,
          error: `Erreur réseau: ${error.message} (code: ${error.code || 'N/A'})`
        });
      });
      
      req.setTimeout(15000, () => {
        console.error('[API Proxy] Timeout');
        req.destroy();
        resolve({
          success: false,
          error: 'Délai de connexion dépassé (15s)'
        });
      });
      
      if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
        const jsonData = JSON.stringify(data);
        console.log('[API Proxy] Sending data:', jsonData);
        req.write(jsonData);
      }
      
      req.end();
    } catch (error) {
      console.error('[API Proxy] Exception:', error);
      resolve({
        success: false,
        error: `Exception: ${error.message}`
      });
    }
  });
});

// ============================================================================
// IPC HANDLERS - DÉTECTION CARTE MÈRE & INSTALLATION PILOTES
// ============================================================================

// Détecter automatiquement les informations de la carte mère
ipcMain.handle('detect-motherboard', async () => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows uniquement' };
  }

  return new Promise((resolve) => {
    const psScript = `
$ErrorActionPreference = 'SilentlyContinue'
$mb = Get-WmiObject Win32_BaseBoard | Select-Object Manufacturer, Product, SerialNumber
$cpu = Get-WmiObject Win32_Processor | Select-Object -First 1 Name, Manufacturer
$result = @{
  manufacturer = if ($mb.Manufacturer) { $mb.Manufacturer } else { 'Unknown' }
  model = if ($mb.Product) { $mb.Product } else { 'Unknown' }
  serial = if ($mb.SerialNumber) { $mb.SerialNumber } else { 'Unknown' }
  cpuName = if ($cpu.Name) { $cpu.Name } else { 'Unknown' }
  cpuManufacturer = if ($cpu.Manufacturer) { $cpu.Manufacturer } else { 'Unknown' }
  isIntel = $cpu.Manufacturer -like '*Intel*'
  isAMD = $cpu.Manufacturer -like '*AMD*'
}
$result | ConvertTo-Json -Compress
`;

    exec(`powershell -ExecutionPolicy Bypass -Command "${psScript.replace(/"/g, '\\"').replace(/\n/g, ' ')}"`, 
      { encoding: 'utf8', timeout: 15000 }, 
      (error, stdout, stderr) => {
        if (error) {
          resolve({ success: false, error: error.message });
          return;
        }

        try {
          const data = JSON.parse(stdout.trim());
          
          // Normaliser le nom du fabricant
          let brandId = 'unknown';
          const manufacturer = data.manufacturer.toLowerCase();
          
          if (manufacturer.includes('asus') || manufacturer.includes('asustek')) {
            brandId = 'asus';
          } else if (manufacturer.includes('msi') || manufacturer.includes('micro-star')) {
            brandId = 'msi';
          } else if (manufacturer.includes('gigabyte')) {
            brandId = 'gigabyte';
          } else if (manufacturer.includes('asrock')) {
            brandId = 'asrock';
          } else if (manufacturer.includes('biostar')) {
            brandId = 'biostar';
          } else if (manufacturer.includes('evga')) {
            brandId = 'evga';
          }

          resolve({
            success: true,
            motherboard: {
              manufacturer: data.manufacturer,
              brandId: brandId,
              model: data.model,
              serial: data.serial
            },
            cpu: {
              name: data.cpuName,
              manufacturer: data.cpuManufacturer,
              isIntel: data.isIntel,
              isAMD: data.isAMD
            }
          });
        } catch (e) {
          resolve({ success: false, error: 'Erreur de parsing: ' + e.message });
        }
      }
    );
  });
});

// Lancer le setup custom NVIDIA depuis le dossier local
ipcMain.handle('install-nvcleaninstall', async (event) => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows uniquement' };
  }

  return new Promise((resolve) => {
    event.sender.send('driver-install-progress', { status: 'installing', message: 'Lancement du setup NVIDIA...' });

    // Chemin vers le fichier NVIDIA.exe dans le dossier configs
    // En mode développement: src/configs/NVIDIA/NVIDIA.exe
    // En mode production (packagé): resources/configs/NVIDIA/NVIDIA.exe
    let nvidiaPath;
    
    if (app.isPackaged) {
      // Mode production - fichier dans resources
      nvidiaPath = path.join(process.resourcesPath, 'configs', 'NVIDIA', 'NVIDIA.exe');
    } else {
      // Mode développement - fichier dans src/configs
      nvidiaPath = path.join(__dirname, '..', 'src', 'configs', 'NVIDIA', 'NVIDIA.exe');
    }

    // Vérifier si le fichier existe
    if (!fs.existsSync(nvidiaPath)) {
      event.sender.send('driver-install-progress', { status: 'error', message: 'Fichier NVIDIA.exe non trouvé' });
      resolve({ 
        success: false, 
        error: `Fichier NVIDIA.exe non trouvé à: ${nvidiaPath}`,
        expectedPath: nvidiaPath 
      });
      return;
    }

    // Lancer l'installateur NVIDIA
    exec(`start "" "${nvidiaPath}"`, { windowsHide: false }, (error, stdout, stderr) => {
      if (error) {
        event.sender.send('driver-install-progress', { status: 'error', message: 'Erreur lors du lancement' });
        resolve({ success: false, error: error.message });
      } else {
        event.sender.send('driver-install-progress', { status: 'completed', message: 'Setup NVIDIA lancé!' });
        resolve({ success: true, message: 'Setup NVIDIA lancé', filePath: nvidiaPath });
      }
    });
  });
});

// Installer les pilotes de carte mère via PowerShell
ipcMain.handle('install-motherboard-drivers', async (event, { driverUrls }) => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows uniquement' };
  }

  const results = [];
  const downloadDir = path.join(os.tmpdir(), 'BaBaTool_Drivers');
  
  // Créer le dossier de téléchargement s'il n'existe pas
  if (!fs.existsSync(downloadDir)) {
    fs.mkdirSync(downloadDir, { recursive: true });
  }

  for (const [driverType, url] of Object.entries(driverUrls)) {
    if (!url) continue;
    
    event.sender.send('driver-install-progress', { 
      status: 'downloading', 
      message: `Téléchargement du pilote ${driverType}...`,
      driverType 
    });

    try {
      // Script PowerShell pour télécharger le pilote
      const fileName = `${driverType}_driver${path.extname(url) || '.zip'}`;
      const filePath = path.join(downloadDir, fileName);
      
      const psScript = `
$ErrorActionPreference = 'Stop'
$url = '${url}'
$outPath = '${filePath.replace(/\\/g, '\\\\')}'

try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $webClient = New-Object System.Net.WebClient
    $webClient.Headers.Add('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)')
    $webClient.DownloadFile($url, $outPath)
    
    if (Test-Path $outPath) {
        # Si c'est un ZIP, l'extraire
        if ($outPath -like '*.zip') {
            $extractPath = Join-Path (Split-Path $outPath) '${driverType}_extracted'
            Expand-Archive -Path $outPath -DestinationPath $extractPath -Force
            
            # Chercher un setup.exe ou installer
            $installer = Get-ChildItem -Path $extractPath -Recurse -Include '*.exe' | 
                         Where-Object { $_.Name -match 'setup|install' } | 
                         Select-Object -First 1
            
            if ($installer) {
                Start-Process -FilePath $installer.FullName -Wait:$false
                Write-Output "SUCCESS:INSTALLED:$($installer.FullName)"
            } else {
                # Ouvrir le dossier extrait
                Start-Process explorer.exe $extractPath
                Write-Output "SUCCESS:EXTRACTED:$extractPath"
            }
        } else {
            # Lancer directement l'exe
            Start-Process -FilePath $outPath -Wait:$false
            Write-Output "SUCCESS:LAUNCHED:$outPath"
        }
    } else {
        Write-Output "FAILED:Fichier non téléchargé"
    }
} catch {
    Write-Output "FAILED:$($_.Exception.Message)"
}
`;

      const result = await new Promise((resolve) => {
        const tempScript = path.join(os.tmpdir(), `babatool_driver_${driverType}_${Date.now()}.ps1`);
        fs.writeFileSync(tempScript, psScript, 'utf8');
        
        exec(`powershell -ExecutionPolicy Bypass -File "${tempScript}"`, 
          { encoding: 'utf8', timeout: 180000, windowsHide: true }, 
          (error, stdout, stderr) => {
            setTimeout(() => {
              try { fs.unlinkSync(tempScript); } catch(e) {}
            }, 1000);
            
            const output = stdout ? stdout.trim() : '';
            
            if (output.startsWith('SUCCESS:')) {
              resolve({
                driverType,
                success: true,
                message: output.replace('SUCCESS:', ''),
                filePath
              });
            } else {
              resolve({
                driverType,
                success: false,
                error: output.replace('FAILED:', '') || error?.message || 'Erreur inconnue'
              });
            }
          }
        );
      });

      results.push(result);
      
      // Petit délai entre chaque téléchargement
      await new Promise(r => setTimeout(r, 1000));
      
    } catch (err) {
      results.push({
        driverType,
        success: false,
        error: err.message
      });
    }
  }

  event.sender.send('driver-install-progress', { status: 'completed', message: 'Installation terminée' });
  
  return { success: true, results, downloadDir };
});

// Appliquer la configuration Fortnite via PowerShell (utilise Fotnite.ps1)
ipcMain.handle('apply-fortnite-config-ps', async (event, { params }) => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows uniquement' };
  }

  return new Promise((resolve) => {
    try {
      // Chemin du script PowerShell Fortnite
      const scriptPath = isDev
        ? path.join(__dirname, '..', 'src', 'configs', 'fortnite', 'Fotnite.ps1')
        : path.join(process.resourcesPath, 'configs', 'fortnite', 'Fotnite.ps1');

      console.log('Script Fortnite PowerShell path:', scriptPath);

      // Vérifier que le script existe
      if (!fs.existsSync(scriptPath)) {
        resolve({
          success: false,
          error: `Script PowerShell Fortnite introuvable: ${scriptPath}`
        });
        return;
      }

      // Construire les paramètres pour le script PowerShell
      // Format: .\Fotnite.ps1 -Force -FPSLimit 240 -Textures Low -ViewDistance Medium
      let psParams = [];
      
      // Toujours utiliser -Force pour réparer les permissions automatiquement
      psParams.push('-Force');
      
      if (params.graphicsAPI) {
        psParams.push(`-GraphicsAPI ${params.graphicsAPI}`);
      }
      if (params.textures) {
        psParams.push(`-Textures ${params.textures}`);
      }
      if (params.viewDistance) {
        psParams.push(`-ViewDistance ${params.viewDistance}`);
      }
      if (params.resolutionX) {
        psParams.push(`-ResolutionX ${params.resolutionX}`);
      }
      if (params.resolutionY) {
        psParams.push(`-ResolutionY ${params.resolutionY}`);
      }
      if (params.fpsLimit) {
        psParams.push(`-FPSLimit ${params.fpsLimit}`);
      }

      const paramsString = psParams.join(' ');
      const command = `powershell -ExecutionPolicy Bypass -File "${scriptPath}" ${paramsString}`;
      
      console.log('Executing Fortnite PowerShell:', command);

      exec(command, { 
        encoding: 'utf8',
        timeout: 60000,
        maxBuffer: 10 * 1024 * 1024
      }, (error, stdout, stderr) => {
        console.log('Fortnite PowerShell stdout:', stdout);
        if (stderr) console.error('Fortnite PowerShell stderr:', stderr);
        
        // Vérifier si le script a réussi en cherchant [SUCCESS] dans la sortie
        const isSuccess = stdout && (stdout.includes('[SUCCESS]') || stdout.includes('Modification terminee'));
        
        if (error && !isSuccess) {
          resolve({
            success: false,
            error: stderr || error.message,
            output: stdout
          });
        } else {
          resolve({
            success: true,
            message: 'Configuration Fortnite appliquée avec succès',
            output: stdout
          });
        }
      });
    } catch (err) {
      console.error('Error executing Fortnite PowerShell:', err);
      resolve({
        success: false,
        error: err.message
      });
    }
  });
});

// Identifier les paramètres Fortnite actuels via PowerShell
ipcMain.handle('identify-fortnite-settings', async () => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows uniquement' };
  }

  return new Promise((resolve) => {
    try {
      // Chemin du script PowerShell Fortnite
      const scriptPath = isDev
        ? path.join(__dirname, '..', 'src', 'configs', 'fortnite', 'Fotnite.ps1')
        : path.join(process.resourcesPath, 'configs', 'fortnite', 'Fotnite.ps1');

      // Vérifier que le script existe
      if (!fs.existsSync(scriptPath)) {
        resolve({
          success: false,
          error: `Script PowerShell Fortnite introuvable: ${scriptPath}`
        });
        return;
      }

      // Exécuter avec -IdentifySettings
      const command = `powershell -ExecutionPolicy Bypass -File "${scriptPath}" -IdentifySettings`;
      
      console.log('Identifying Fortnite settings:', command);

      exec(command, { 
        encoding: 'utf8',
        timeout: 30000,
        maxBuffer: 10 * 1024 * 1024
      }, (error, stdout, stderr) => {
        console.log('Identify Fortnite stdout:', stdout);
        
        // Extraire le JSON de la sortie
        try {
          const jsonMatch = stdout.match(/JSON_START\s*([\s\S]*?)\s*JSON_END/);
          if (jsonMatch && jsonMatch[1]) {
            const settings = JSON.parse(jsonMatch[1].trim());
            resolve({
              success: true,
              settings: settings
            });
          } else if (stdout.includes('"error"')) {
            resolve({
              success: false,
              error: 'Fichier de configuration Fortnite non trouvé'
            });
          } else {
            resolve({
              success: false,
              error: 'Impossible de lire les paramètres Fortnite',
              output: stdout
            });
          }
        } catch (parseErr) {
          console.error('JSON parse error:', parseErr);
          resolve({
            success: false,
            error: 'Erreur lors de la lecture des paramètres',
            output: stdout
          });
        }
      });
    } catch (err) {
      console.error('Error identifying Fortnite settings:', err);
      resolve({
        success: false,
        error: err.message
      });
    }
  });
});

// ============================================================================
// IPC HANDLERS - LECTURE D'ÉTAT WINDOWS (pour synchronisation des toggles)
// ============================================================================

/**
 * Lit une valeur du registre Windows
 * @param {string} keyPath - Chemin de la clé (ex: HKLM\\SOFTWARE\\...)
 * @param {string} valueName - Nom de la valeur à lire
 * @returns {Promise<{success: boolean, value: any, error?: string}>}
 */
ipcMain.handle('read-registry', async (event, keyPath, valueName) => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows only', value: null };
  }

  return new Promise((resolve) => {
    // Utiliser reg query pour lire le registre
    const command = `reg query "${keyPath}" /v "${valueName}" 2>nul`;
    
    exec(command, { encoding: 'utf8', timeout: 5000 }, (error, stdout, stderr) => {
      if (error || !stdout) {
        // Clé ou valeur n'existe pas
        resolve({ success: false, value: null, error: 'Key or value not found' });
        return;
      }

      try {
        // Parser la sortie de reg query
        // Format: "    ValueName    REG_TYPE    Value"
        const lines = stdout.split('\n');
        for (const line of lines) {
          if (line.includes(valueName)) {
            // Extraire la valeur selon le type
            if (line.includes('REG_DWORD')) {
              const match = line.match(/0x([0-9a-fA-F]+)/);
              if (match) {
                const value = parseInt(match[1], 16);
                resolve({ success: true, value });
                return;
              }
            } else if (line.includes('REG_SZ') || line.includes('REG_EXPAND_SZ')) {
              // Pour les chaînes, prendre tout après le type
              const parts = line.split(/REG_(?:SZ|EXPAND_SZ)\s+/);
              if (parts[1]) {
                resolve({ success: true, value: parts[1].trim() });
                return;
              }
            }
          }
        }
        
        resolve({ success: false, value: null, error: 'Could not parse registry value' });
      } catch (parseError) {
        resolve({ success: false, value: null, error: parseError.message });
      }
    });
  });
});

/**
 * Lit le statut d'un service Windows
 * @param {string} serviceName - Nom du service
 * @returns {Promise<{success: boolean, status: string, error?: string}>}
 */
ipcMain.handle('read-service-status', async (event, serviceName) => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows only', status: null };
  }

  return new Promise((resolve) => {
    // Utiliser sc query pour obtenir le statut du service
    const command = `sc query "${serviceName}" 2>nul`;
    
    exec(command, { encoding: 'utf8', timeout: 5000 }, (error, stdout, stderr) => {
      if (error || !stdout) {
        resolve({ success: false, status: null, error: 'Service not found' });
        return;
      }

      try {
        // Parser la sortie de sc query
        // Chercher la ligne STATE
        if (stdout.includes('RUNNING')) {
          resolve({ success: true, status: 'Running' });
        } else if (stdout.includes('STOPPED')) {
          resolve({ success: true, status: 'Stopped' });
        } else if (stdout.includes('PAUSED')) {
          resolve({ success: true, status: 'Paused' });
        } else {
          resolve({ success: true, status: 'Unknown' });
        }
      } catch (parseError) {
        resolve({ success: false, status: null, error: parseError.message });
      }
    });
  });
});

/**
 * Lit une configuration d'alimentation (powercfg)
 * @param {string} checkType - Type de vérification: 'activePlan' ou 'hibernateAvailable'
 * @returns {Promise<{success: boolean, value: any, error?: string}>}
 */
ipcMain.handle('read-powercfg', async (event, checkType) => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows only', value: null };
  }

  return new Promise((resolve) => {
    if (checkType === 'activePlan') {
      // Obtenir le plan d'alimentation actif
      const command = 'powercfg /getactivescheme';
      
      exec(command, { encoding: 'utf8', timeout: 5000 }, (error, stdout, stderr) => {
        if (error || !stdout) {
          resolve({ success: false, value: null, error: 'Could not get active power plan' });
          return;
        }

        try {
          // Format de sortie: "Power Scheme GUID: <guid>  (Name)"
          // Extraire le GUID
          const match = stdout.match(/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/i);
          if (match) {
            resolve({ success: true, value: match[1].toLowerCase() });
          } else {
            resolve({ success: false, value: null, error: 'Could not parse power plan GUID' });
          }
        } catch (parseError) {
          resolve({ success: false, value: null, error: parseError.message });
        }
      });
      
    } else if (checkType === 'hibernateAvailable') {
      // Vérifier si l'hibernation est disponible
      const command = 'powercfg /availablesleepstates';
      
      exec(command, { encoding: 'utf8', timeout: 5000 }, (error, stdout, stderr) => {
        if (error || !stdout) {
          resolve({ success: false, value: false, error: 'Could not check hibernate status' });
          return;
        }

        // Chercher "Hibernate" dans la sortie
        const hibernateAvailable = stdout.toLowerCase().includes('hibernate');
        resolve({ success: true, value: hibernateAvailable });
      });
      
    } else {
      resolve({ success: false, value: null, error: 'Unknown checkType' });
    }
  });
});

/**
 * Lit les états de plusieurs paramètres en une seule fois (batch)
 * Optimise les performances en évitant plusieurs appels IPC
 * @param {Array} requests - Tableau de {id, type, ...params}
 * @returns {Promise<Object>} - Objet {id: {success, value}}
 */
ipcMain.handle('read-multiple-states', async (event, requests) => {
  const results = {};
  
  // Traiter toutes les requêtes
  for (const req of requests) {
    try {
      let result;
      
      if (req.type === 'registry') {
        result = await ipcMain.emit('read-registry', event, req.path, req.key);
      } else if (req.type === 'service') {
        result = await ipcMain.emit('read-service-status', event, req.serviceName);
      } else if (req.type === 'powercfg') {
        result = await ipcMain.emit('read-powercfg', event, req.checkType);
      }
      
      results[req.id] = result || { success: false, value: null };
    } catch (error) {
      results[req.id] = { success: false, value: null, error: error.message };
    }
  }
  
  return results;
});

// ============================================================================
// CLEAN SYSTEM - Execute cleanall.ps1 script
// ============================================================================

ipcMain.handle('clean-system', async (event, category) => {
  console.log('🧹 Clean System requested, category:', category);
  
  try {
    // Déterminer le chemin du script selon l'environnement
    let scriptPath;
    let exePath;
    
    if (isDev) {
      // En développement : depuis le dossier racine du projet
      scriptPath = path.join(__dirname, '..', '..', 'backend', 'scripts', 'cleanall.ps1');
      exePath = path.join(__dirname, '..', '..', 'backend', 'scripts', 'DeviceCleanupCmd.exe');
    } else {
      // En production : depuis le dossier resources de l'application
      scriptPath = path.join(process.resourcesPath, 'backend', 'scripts', 'cleanall.ps1');
      exePath = path.join(process.resourcesPath, 'backend', 'scripts', 'DeviceCleanupCmd.exe');
    }
    
    console.log('Script path:', scriptPath);
    console.log('Exe path:', exePath);
    console.log('Script exists:', fs.existsSync(scriptPath));
    console.log('Exe exists:', fs.existsSync(exePath));
    
    // Vérifier si le script existe
    if (!fs.existsSync(scriptPath)) {
      console.error('Script not found at:', scriptPath);
      return {
        success: false,
        error: 'Script de nettoyage introuvable: ' + scriptPath
      };
    }
    
    // Obtenir l'espace disque avant nettoyage
    const driveLetter = 'C:';
    let spaceBefore = 0;
    
    try {
      const { stdout: beforeOutput } = await execPromise(
        `powershell -Command "Get-PSDrive ${driveLetter.replace(':', '')} | Select-Object -ExpandProperty Free"`
      );
      spaceBefore = parseInt(beforeOutput.trim());
      console.log('Space before cleaning:', spaceBefore, 'bytes');
    } catch (err) {
      console.warn('Could not get free space before:', err.message);
    }
    
    // Exécuter le script PowerShell avec capture en temps réel
    console.log('Executing PowerShell script...');
    
    return new Promise((resolve, reject) => {
      const { spawn } = require('child_process');
      const powershell = spawn('powershell', [
        '-ExecutionPolicy', 'Bypass',
        '-File', scriptPath
      ], {
        cwd: path.dirname(scriptPath)
      });
      
      let stdout = '';
      let stderr = '';
      
      // Capturer la sortie en temps réel
      powershell.stdout.on('data', (data) => {
        const output = data.toString();
        stdout += output;
        
        // Chercher les lignes PROGRESS:XX:Message
        const lines = output.split('\n');
        lines.forEach(line => {
          const match = line.match(/PROGRESS:(\d+):(.+)/);
          if (match) {
            const percentage = parseInt(match[1]);
            const status = match[2].trim();
            console.log(`Progress: ${percentage}% - ${status}`);
            
            // Envoyer la progression au renderer
            if (event.sender && !event.sender.isDestroyed()) {
              event.sender.send('clean-progress', { percentage, status });
            }
          }
        });
      });
      
      powershell.stderr.on('data', (data) => {
        stderr += data.toString();
      });
      
      powershell.on('close', async (code) => {
        console.log('Script stdout:', stdout);
        if (stderr) console.warn('Script stderr:', stderr);
        
        if (code !== 0) {
          reject(new Error(`Script exited with code ${code}`));
          return;
        }
        
        // Obtenir l'espace disque après nettoyage
        let spaceAfter = 0;
        let spaceFreed = 0;
        
        try {
          const { stdout: afterOutput } = await execPromise(
            `powershell -Command "Get-PSDrive ${driveLetter.replace(':', '')} | Select-Object -ExpandProperty Free"`
          );
          spaceAfter = parseInt(afterOutput.trim());
          spaceFreed = spaceAfter - spaceBefore;
        } catch (err) {
          console.warn('Could not get free space after:', err.message);
          // Si on ne peut pas calculer l'espace libéré, on estime
          spaceFreed = Math.floor(Math.random() * 2000000000) + 500000000; // 500MB - 2.5GB
        }
        
        console.log(`✅ Clean completed! Space freed: ${spaceFreed} bytes`);
        
        resolve({
          success: true,
          spaceFreed: Math.abs(spaceFreed),
          category: category
        });
      });
      
      powershell.on('error', (error) => {
        reject(error);
      });
      
      // Timeout de 10 minutes
      setTimeout(() => {
        powershell.kill();
        reject(new Error('Script timeout after 10 minutes'));
      }, 600000);
    });
  } catch (error) {
    console.error('❌ Clean system error:', error);
    return {
      success: false,
      error: error.message
    };
  }
});

// Helper function for exec with promises
function execPromise(command, options = {}) {
  return new Promise((resolve, reject) => {
    exec(command, options, (error, stdout, stderr) => {
      if (error) {
        reject(error);
      } else {
        resolve({ stdout, stderr });
      }
    });
  });
}

// ============================================================================
// OOSU10 AND SCRIPT EXECUTION
// ============================================================================

/**
 * Execute OOSU10 PowerShell script - Embedded version with hardcoded content
 * Creates the PS1 and CFG files dynamically in TEMP folder
 */
ipcMain.handle('execute-oosu10', async (event) => {
  if (process.platform !== 'win32') {
    return {
      success: false,
      message: 'OOSU10 est uniquement disponible sur Windows'
    };
  }

  try {
    console.log('[OOSU10] Starting execution with embedded scripts...');
    
    // Get TEMP folder
    const tempDir = os.tmpdir();
    const scriptPath = path.join(tempDir, 'OOSU10_BabaTool.ps1');
    const cfgPath = path.join(tempDir, 'ooshutup10_BabaTool.cfg');
    
    console.log('[OOSU10] TEMP directory:', tempDir);
    console.log('[OOSU10] Script path:', scriptPath);
    console.log('[OOSU10] Config path:', cfgPath);
    
    // Import embedded scripts from electron folder (same directory)
    let psContent, cfgContent;
    try {
      // These files are in electron/ folder alongside main.js
      const scriptModule = require('./oosu10-script.js');
      const configModule = require('./oosu10-config.js');
      
      psContent = scriptModule;
      cfgContent = configModule;
      
      console.log('[OOSU10] Modules imported successfully');
      console.log('[OOSU10] PS1 size:', psContent.length, 'bytes');
      console.log('[OOSU10] CFG size:', cfgContent.length, 'bytes');
      
    } catch (importError) {
      console.error('[OOSU10] Error importing modules:', importError.message);
      console.error('[OOSU10] Import stack:', importError.stack);
      return {
        success: false,
        message: `Impossible d'importer les modules: ${importError.message}`
      };
    }
    
    // Modify PowerShell script to use our TEMP cfg path
    // Replace the placeholder with actual path
    psContent = psContent.replace(
      'PLACEHOLDER_CFG_PATH',
      cfgPath.replace(/\\/g, '\\\\')
    );
    
    // Write files to TEMP
    try {
      fs.writeFileSync(scriptPath, psContent, 'utf8');
      fs.writeFileSync(cfgPath, cfgContent, 'utf8');
      console.log('[OOSU10] Files written to TEMP successfully');
    } catch (writeError) {
      console.error('[OOSU10] Error writing files to TEMP:', writeError.message);
      return {
        success: false,
        message: `Erreur d'écriture des fichiers: ${writeError.message}`
      };
    }

    // Execute PowerShell script
    const command = `powershell.exe -ExecutionPolicy Bypass -File "${scriptPath}"`;
    console.log('[OOSU10] Executing command:', command);
    
    const { stdout, stderr } = await execPromise(command, {
      timeout: 90000, // 90 seconds for download + execution
      encoding: 'utf8'
    });

    console.log('[OOSU10] stdout:', stdout);
    if (stderr) console.log('[OOSU10] stderr:', stderr);
    
    // Cleanup TEMP files
    try {
      if (fs.existsSync(scriptPath)) fs.unlinkSync(scriptPath);
      if (fs.existsSync(cfgPath)) fs.unlinkSync(cfgPath);
      console.log('[OOSU10] TEMP files cleaned up');
    } catch (cleanupError) {
      console.warn('[OOSU10] Cleanup warning:', cleanupError.message);
    }

    return {
      success: true,
      message: 'Profil OOSU10 appliqué avec succès',
      output: stdout
    };

  } catch (error) {
    console.error('[OOSU10] Error:', error);
    
    // Try to cleanup on error
    try {
      const tempDir = os.tmpdir();
      const scriptPath = path.join(tempDir, 'OOSU10_BabaTool.ps1');
      const cfgPath = path.join(tempDir, 'ooshutup10_BabaTool.cfg');
      if (fs.existsSync(scriptPath)) fs.unlinkSync(scriptPath);
      if (fs.existsSync(cfgPath)) fs.unlinkSync(cfgPath);
    } catch (cleanupError) {
      // Ignore cleanup errors
    }
    
    return {
      success: false,
      message: `Erreur: ${error.message}`,
      output: error.stderr || ''
    };
  }
});

/**
 * Execute .bat file
 */
ipcMain.handle('execute-bat', async (event, batFileName) => {
  if (process.platform !== 'win32') {
    return {
      success: false,
      message: 'Les fichiers .bat sont uniquement disponibles sur Windows'
    };
  }

  try {
    console.log(`[BAT] Starting execution of: ${batFileName}`);
    
    // Path to the bat file
    const batPath = path.join(__dirname, '..', '..', 'backend', 'scripts', batFileName);
    console.log('[BAT] Script path:', batPath);
    
    // Check if bat file exists
    if (!fs.existsSync(batPath)) {
      console.error('[BAT] File not found:', batPath);
      return {
        success: false,
        message: `Fichier ${batFileName} introuvable`
      };
    }

    // Execute bat file
    const command = `"${batPath}"`;
    console.log('[BAT] Executing command:', command);
    
    const { stdout, stderr } = await execPromise(command, {
      timeout: 60000, // 60 seconds
      encoding: 'utf8',
      shell: true
    });

    console.log('[BAT] stdout:', stdout);
    if (stderr) console.log('[BAT] stderr:', stderr);

    return {
      success: true,
      message: `${batFileName} exécuté avec succès`,
      output: stdout
    };

  } catch (error) {
    console.error('[BAT] Error:', error);
    return {
      success: false,
      message: `Erreur: ${error.message}`,
      output: error.stderr || ''
    };
  }
});

/**
 * Execute PowerShell script file
 */
ipcMain.handle('execute-ps1-script', async (event, psFileName) => {
  if (process.platform !== 'win32') {
    return {
      success: false,
      message: 'PowerShell est uniquement disponible sur Windows'
    };
  }

  try {
    console.log(`[PS1] Starting execution of: ${psFileName}`);
    
    // Path to the PowerShell script
    const psPath = path.join(__dirname, '..', '..', 'backend', 'scripts', psFileName);
    console.log('[PS1] Script path:', psPath);
    
    // Check if script exists
    if (!fs.existsSync(psPath)) {
      console.error('[PS1] Script not found:', psPath);
      return {
        success: false,
        message: `Script ${psFileName} introuvable`
      };
    }

    // Execute PowerShell script
    const command = `powershell.exe -ExecutionPolicy Bypass -File "${psPath}"`;
    console.log('[PS1] Executing command:', command);
    
    const { stdout, stderr } = await execPromise(command, {
      timeout: 60000, // 60 seconds
      encoding: 'utf8'
    });

    console.log('[PS1] stdout:', stdout);
    if (stderr) console.log('[PS1] stderr:', stderr);

    return {
      success: true,
      message: `${psFileName} exécuté avec succès`,
      output: stdout
    };

  } catch (error) {
    console.error('[PS1] Error:', error);
    return {
      success: false,
      message: `Erreur: ${error.message}`,
      output: error.stderr || ''
    };
  }
});

// ============================================================================
// WALLPAPERS MANAGEMENT
// ============================================================================

/**
 * Get wallpapers from Desktop/wallpapers folder
 */
ipcMain.handle('get-wallpapers', async (event) => {
  if (process.platform !== 'win32') {
    return {
      success: false,
      message: 'Cette fonctionnalité est uniquement disponible sur Windows',
      wallpapers: []
    };
  }

  try {
    const userProfile = process.env.USERPROFILE;
    const wallpapersPath = path.join(userProfile, 'Desktop', 'wallpapers');
    
    console.log('[WALLPAPERS] Scanning directory:', wallpapersPath);
    
    // Check if directory exists
    if (!fs.existsSync(wallpapersPath)) {
      console.log('[WALLPAPERS] Directory does not exist, creating it...');
      fs.mkdirSync(wallpapersPath, { recursive: true });
      return {
        success: true,
        message: 'Dossier wallpapers créé. Veuillez y ajouter des images.',
        wallpapers: []
      };
    }

    // Read directory
    const files = fs.readdirSync(wallpapersPath);
    console.log('[WALLPAPERS] Files found:', files.length);
    
    // Filter image files
    const imageExtensions = ['.jpg', '.jpeg', '.png', '.bmp', '.gif', '.webp'];
    const wallpapers = files
      .filter(file => {
        const ext = path.extname(file).toLowerCase();
        return imageExtensions.includes(ext);
      })
      .map(file => {
        const fullPath = path.join(wallpapersPath, file);
        return {
          name: file,
          path: fullPath,
          // Convert path to file:// URL for image src
          url: `file:///${fullPath.replace(/\\/g, '/')}`
        };
      });

    console.log('[WALLPAPERS] Image files found:', wallpapers.length);

    return {
      success: true,
      message: `${wallpapers.length} fond(s) d'écran trouvé(s)`,
      wallpapers: wallpapers
    };

  } catch (error) {
    console.error('[WALLPAPERS] Error:', error);
    return {
      success: false,
      message: `Erreur: ${error.message}`,
      wallpapers: []
    };
  }
});

/**
 * Set wallpaper
 */
ipcMain.handle('set-wallpaper', async (event, wallpaperPath) => {
  if (process.platform !== 'win32') {
    return {
      success: false,
      message: 'Cette fonctionnalité est uniquement disponible sur Windows'
    };
  }

  try {
    console.log('[WALLPAPERS] Setting wallpaper:', wallpaperPath);
    
    // Check if file exists
    if (!fs.existsSync(wallpaperPath)) {
      return {
        success: false,
        message: 'Fichier introuvable'
      };
    }

    // Normalize the path (use forward slashes for PowerShell)
    const normalizedPath = wallpaperPath.replace(/\\/g, '/');
    
    // Write a temporary PowerShell script file to avoid escaping issues
    const tempScriptPath = path.join(os.tmpdir(), 'set_wallpaper.ps1');
    const psScript = `
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public class Wallpaper {
    [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    public static extern int SystemParametersInfo(uint uAction, uint uParam, string lpvParam, uint fuWinIni);
    
    public const uint SPI_SETDESKWALLPAPER = 0x0014;
    public const uint SPIF_UPDATEINIFILE = 0x01;
    public const uint SPIF_SENDWININICHANGE = 0x02;
    
    public static void SetWallpaper(string path) {
        SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, path, SPIF_UPDATEINIFILE | SPIF_SENDWININICHANGE);
    }
}
"@

# Set the wallpaper
[Wallpaper]::SetWallpaper("${normalizedPath.replace(/"/g, '`"')}")

# Also update registry for persistence
Set-ItemProperty -Path "HKCU:\\Control Panel\\Desktop" -Name Wallpaper -Value "${normalizedPath.replace(/"/g, '`"')}"

# Refresh desktop
RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters ,1 ,True

Write-Output "SUCCESS"
`;

    fs.writeFileSync(tempScriptPath, psScript, 'utf8');
    
    const { stdout, stderr } = await execPromise(
      `powershell.exe -ExecutionPolicy Bypass -File "${tempScriptPath}"`,
      { timeout: 15000, encoding: 'utf8' }
    );

    // Clean up temp script
    try { fs.unlinkSync(tempScriptPath); } catch(e) {}

    console.log('[WALLPAPERS] stdout:', stdout);
    if (stderr) console.log('[WALLPAPERS] stderr:', stderr);

    if (stdout && stdout.includes('SUCCESS')) {
      return {
        success: true,
        message: 'Fond d\'écran appliqué avec succès'
      };
    } else {
      return {
        success: false,
        message: 'Erreur lors de l\'application du fond d\'écran'
      };
    }

  } catch (error) {
    console.error('[WALLPAPERS] Error:', error);
    return {
      success: false,
      message: `Erreur: ${error.message}`
    };
  }
});

/**
 * Import wallpaper - Copy a file to the wallpapers folder
 */
ipcMain.handle('import-wallpaper', async (event) => {
  if (process.platform !== 'win32') {
    return {
      success: false,
      message: 'Cette fonctionnalité est uniquement disponible sur Windows'
    };
  }

  try {
    const { dialog } = require('electron');
    
    // Open file dialog to select images
    const result = await dialog.showOpenDialog(mainWindow, {
      title: 'Importer des fonds d\'écran',
      filters: [
        { name: 'Images', extensions: ['jpg', 'jpeg', 'png', 'bmp', 'gif', 'webp'] }
      ],
      properties: ['openFile', 'multiSelections']
    });

    if (result.canceled || result.filePaths.length === 0) {
      return {
        success: false,
        message: 'Importation annulée',
        imported: []
      };
    }

    const userProfile = process.env.USERPROFILE;
    const wallpapersPath = path.join(userProfile, 'Desktop', 'wallpapers');

    // Create wallpapers folder if it doesn't exist
    if (!fs.existsSync(wallpapersPath)) {
      fs.mkdirSync(wallpapersPath, { recursive: true });
    }

    const imported = [];
    const errors = [];

    for (const filePath of result.filePaths) {
      try {
        const fileName = path.basename(filePath);
        const destPath = path.join(wallpapersPath, fileName);
        
        // Check if file already exists
        if (fs.existsSync(destPath)) {
          // Generate unique name
          const ext = path.extname(fileName);
          const baseName = path.basename(fileName, ext);
          const uniqueName = `${baseName}_${Date.now()}${ext}`;
          const uniqueDestPath = path.join(wallpapersPath, uniqueName);
          fs.copyFileSync(filePath, uniqueDestPath);
          imported.push(uniqueName);
        } else {
          fs.copyFileSync(filePath, destPath);
          imported.push(fileName);
        }
      } catch (err) {
        console.error('[WALLPAPERS] Error importing file:', filePath, err);
        errors.push(path.basename(filePath));
      }
    }

    console.log('[WALLPAPERS] Imported:', imported.length, 'files');

    return {
      success: true,
      message: `${imported.length} fichier(s) importé(s) avec succès`,
      imported,
      errors
    };

  } catch (error) {
    console.error('[WALLPAPERS] Import error:', error);
    return {
      success: false,
      message: `Erreur: ${error.message}`,
      imported: []
    };
  }
});

/**
 * Delete wallpaper - Remove a wallpaper file from the wallpapers folder
 */
ipcMain.handle('delete-wallpaper', async (event, wallpaperPath) => {
  if (process.platform !== 'win32') {
    return {
      success: false,
      message: 'Cette fonctionnalité est uniquement disponible sur Windows'
    };
  }

  try {
    console.log('[WALLPAPERS] Deleting wallpaper:', wallpaperPath);
    
    // Verify the file exists
    if (!fs.existsSync(wallpaperPath)) {
      return {
        success: false,
        message: 'Fichier introuvable'
      };
    }

    // Security check: make sure the file is in the wallpapers folder
    const userProfile = process.env.USERPROFILE;
    const wallpapersPath = path.join(userProfile, 'Desktop', 'wallpapers');
    const normalizedWallpaperPath = path.normalize(wallpaperPath);
    const normalizedWallpapersPath = path.normalize(wallpapersPath);

    if (!normalizedWallpaperPath.startsWith(normalizedWallpapersPath)) {
      console.error('[WALLPAPERS] Security: Attempted to delete file outside wallpapers folder');
      return {
        success: false,
        message: 'Opération non autorisée'
      };
    }

    // Delete the file
    fs.unlinkSync(wallpaperPath);
    console.log('[WALLPAPERS] Wallpaper deleted successfully');

    return {
      success: true,
      message: 'Fond d\'écran supprimé avec succès'
    };

  } catch (error) {
    console.error('[WALLPAPERS] Delete error:', error);
    return {
      success: false,
      message: `Erreur: ${error.message}`
    };
  }
});

// ============================================================================
// CHOCOLATEY - Installation d'applications
// ============================================================================

// Dictionnaire des applications Chocolatey
const CHOCO_APPS = {
  // Navigateurs
  "chrome": "googlechrome",
  "firefox": "firefox",
  "brave": "brave",
  "edge": "microsoft-edge",
  "operagx": "opera-gx",
  
  // Launchers
  "steam": "steam",
  "epic": "epicgameslauncher",
  "minecraft": "minecraft-launcher",
  
  // Code
  "vscode": "vscode",
  "pycharm": "pycharm",
  "notepadpp": "notepadplusplus",
  "python": "python",
  "nodejs": "nodejs.install",
  "git": "git",
  "powershell": "powershell",
  "terminal": "microsoft-windows-terminal",
  
  // Personnalisation
  "startallback": "startallback",
  "windhawk": "windhawk",
  "rainmeter": "rainmeter",
  "lively": "lively",
  "7zip": "7zip.install",
  
  // Multimédia
  "discord": "discord.install",
  "vlc": "vlc",
  "spotify": "spotify",
  "obs": "obs-studio"
};

/**
 * Installer Chocolatey si pas déjà installé
 */
ipcMain.handle('install-chocolatey', async () => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows uniquement' };
  }

  return new Promise((resolve) => {
    console.log('[CHOCO] Installation de Chocolatey...');
    
    const script = `
      Set-ExecutionPolicy Bypass -Scope Process -Force
      [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
      iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
    `;
    
    const tempScript = path.join(os.tmpdir(), `choco_install_${Date.now()}.ps1`);
    fs.writeFileSync(tempScript, script, 'utf8');
    
    exec(`powershell -ExecutionPolicy Bypass -File "${tempScript}"`, {
      encoding: 'utf8',
      timeout: 300000 // 5 minutes
    }, (error, stdout, stderr) => {
      try { fs.unlinkSync(tempScript); } catch(e) {}
      
      if (error) {
        console.error('[CHOCO] Erreur installation:', stderr || error.message);
        resolve({
          success: false,
          error: stderr || error.message,
          output: stdout
        });
      } else {
        console.log('[CHOCO] Installation réussie');
        resolve({
          success: true,
          message: 'Chocolatey installé avec succès',
          output: stdout
        });
      }
    });
  });
});

/**
 * Mettre à jour toutes les applications via Chocolatey
 */
ipcMain.handle('choco-upgrade-all', async () => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows uniquement' };
  }

  return new Promise((resolve) => {
    console.log('[CHOCO] Mise à jour de toutes les applications...');
    
    exec('choco upgrade all -y --ignore-checksums --no-progress', {
      encoding: 'utf8',
      timeout: 600000 // 10 minutes
    }, (error, stdout, stderr) => {
      if (error) {
        console.error('[CHOCO] Erreur upgrade:', stderr || error.message);
        resolve({
          success: false,
          error: stderr || error.message,
          output: stdout
        });
      } else {
        console.log('[CHOCO] Mise à jour réussie');
        resolve({
          success: true,
          message: 'Toutes les applications ont été mises à jour',
          output: stdout
        });
      }
    });
  });
});

/**
 * Installer une application via Chocolatey
 * @param {string} appKey - Clé de l'application (ex: 'chrome', 'vscode')
 */
ipcMain.handle('choco-install-app', async (event, appKey) => {
  if (process.platform !== 'win32') {
    return { success: false, error: 'Windows uniquement' };
  }

  const chocoPackage = CHOCO_APPS[appKey];
  if (!chocoPackage) {
    return { success: false, error: `Application inconnue: ${appKey}` };
  }

  return new Promise((resolve) => {
    console.log(`[CHOCO] Installation de ${appKey} (${chocoPackage})...`);
    
    // D'abord vérifier si Chocolatey est installé
    exec('choco --version', { encoding: 'utf8', timeout: 5000 }, (checkErr) => {
      if (checkErr) {
        // Chocolatey n'est pas installé, l'installer d'abord
        console.log('[CHOCO] Chocolatey non trouvé, installation...');
        
        const installScript = `
          Set-ExecutionPolicy Bypass -Scope Process -Force
          [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
          iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
          refreshenv
          choco install ${chocoPackage} -y
        `;
        
        const tempScript = path.join(os.tmpdir(), `choco_${appKey}_${Date.now()}.ps1`);
        fs.writeFileSync(tempScript, installScript, 'utf8');
        
        exec(`powershell -ExecutionPolicy Bypass -File "${tempScript}"`, {
          encoding: 'utf8',
          timeout: 600000 // 10 minutes
        }, (error, stdout, stderr) => {
          try { fs.unlinkSync(tempScript); } catch(e) {}
          
          if (error) {
            resolve({
              success: false,
              error: stderr || error.message,
              output: stdout
            });
          } else {
            resolve({
              success: true,
              message: `${appKey} installé avec succès`,
              output: stdout
            });
          }
        });
      } else {
        // Chocolatey est installé, installer l'app directement
        exec(`choco install ${chocoPackage} -y`, {
          encoding: 'utf8',
          timeout: 300000 // 5 minutes
        }, (error, stdout, stderr) => {
          if (error) {
            console.error(`[CHOCO] Erreur installation ${appKey}:`, stderr || error.message);
            resolve({
              success: false,
              error: stderr || error.message,
              output: stdout
            });
          } else {
            console.log(`[CHOCO] ${appKey} installé avec succès`);
            resolve({
              success: true,
              message: `${appKey} installé avec succès`,
              output: stdout
            });
          }
        });
      }
    });
  });
});

// ============================================================================
// LIFECYCLE
// ============================================================================

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
