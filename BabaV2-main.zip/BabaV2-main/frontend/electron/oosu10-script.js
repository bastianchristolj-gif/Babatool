// OOSU10 PowerShell Script Content
// This script is embedded to avoid file path issues in packaged app

const OOSU10_SCRIPT = `# Script OOSU10 Silent - Chemin personnalisé TEMP
$ErrorActionPreference='SilentlyContinue'
$ProgressPreference='SilentlyContinue'

# Chemin du fichier cfg dans TEMP (sera remplacé dynamiquement)
$cfgPath = "PLACEHOLDER_CFG_PATH"

# Vérifier si le fichier existe
if (-not (Test-Path $cfgPath)) {
    Write-Error "Fichier de configuration non trouvé: $cfgPath"
    exit 1
}

# Télécharger OOSU10
$exePath = "$env:TEMP\\OOSU10.exe"
if (-not (Test-Path $exePath)) {
    try {
        Invoke-WebRequest -Uri "https://dl5.oo-software.com/files/ooshutup10/OOSU10.exe" \`
            -OutFile $exePath -UseBasicParsing
    } catch {
        # Essayer avec une autre méthode
        try {
            $webClient = New-Object System.Net.WebClient
            $webClient.DownloadFile("https://dl5.oo-software.com/files/ooshutup10/OOSU10.exe", $exePath)
        } catch {
            Write-Error "Impossible de télécharger OOSU10.exe"
            exit 2
        }
    }
}

# Fermer OOSU10 si déjà ouvert
Get-Process "OOSU10" -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 300

# Appliquer la configuration
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $exePath
$psi.Arguments = "\`"$cfgPath\`" /quiet"
$psi.CreateNoWindow = $true
$psi.WindowStyle = 'Hidden'
$psi.UseShellExecute = $false

$process = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Seconds 15

# Fermer OOSU10
if ($process -and (-not $process.HasExited)) {
    $process.Kill()
}

# Nettoyer
Get-Process "OOSU10" -ErrorAction SilentlyContinue | Stop-Process -Force
Remove-Item $exePath -ErrorAction SilentlyContinue

Write-Output "Profil OOSU10 appliqué avec succès"
exit 0
`;

module.exports = OOSU10_SCRIPT;
