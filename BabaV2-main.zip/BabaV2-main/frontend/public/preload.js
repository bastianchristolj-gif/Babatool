const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // Info système
  platform: process.platform,
  isElectron: true,
  getVersion: () => process.versions.electron,
  getAppVersion: () => ipcRenderer.invoke('get-app-version'),
  
  // Window controls (les deux noms pour compatibilité)
  minimize: () => ipcRenderer.send('window-minimize'),
  maximize: () => ipcRenderer.send('window-maximize'),
  close: () => ipcRenderer.send('window-close'),
  minimizeWindow: () => ipcRenderer.send('window-minimize'),
  maximizeWindow: () => ipcRenderer.send('window-maximize'),
  closeWindow: () => ipcRenderer.send('window-close'),
  
  // PowerShell execution
  executePowerShell: (commands) => ipcRenderer.invoke('execute-powershell', commands),
  
  // Admin
  checkAdmin: () => ipcRenderer.invoke('check-admin'),
  restartAsAdmin: () => ipcRenderer.invoke('restart-as-admin'),
  
  // External links
  openExternal: (url) => ipcRenderer.invoke('open-external', url),
  
  // System Info
  getSystemInfo: () => ipcRenderer.invoke('get-system-info'),
  
  // ============================================================================
  // MISE À JOUR AUTOMATIQUE
  // ============================================================================
  downloadUpdate: (url, version) => ipcRenderer.invoke('download-update', { url, version }),
  onDownloadProgress: (callback) => {
    ipcRenderer.on('download-progress', (event, data) => callback(data));
  },
  removeDownloadProgressListener: () => {
    ipcRenderer.removeAllListeners('download-progress');
  },
  runSilentInstaller: (filePath) => ipcRenderer.invoke('run-silent-installer', { filePath })
});

console.log('Preload script loaded');
