const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const { exec, spawn } = require('child_process');
const os = require('os');

const isDev = process.env.ELECTRON_DEV === 'true';

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1000,
    minHeight: 700,
    frame: false,
    backgroundColor: '#0d0d0d',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });

  if (isDev) {
    mainWindow.loadURL('http://localhost:3000');
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, '../build/index.html'));
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// Window controls
ipcMain.on('window-minimize', () => mainWindow?.minimize());
ipcMain.on('window-maximize', () => {
  if (mainWindow?.isMaximized()) {
    mainWindow.unmaximize();
  } else {
    mainWindow?.maximize();
  }
});
ipcMain.on('window-close', () => mainWindow?.close());

// Execute PowerShell command
function executePowerShell(script) {
  return new Promise((resolve, reject) => {
    const ps = spawn('powershell.exe', [
      '-NoProfile',
      '-ExecutionPolicy', 'Bypass',
      '-Command', script
    ]);

    let stdout = '';
    let stderr = '';

    ps.stdout.on('data', (data) => {
      stdout += data.toString();
    });

    ps.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    ps.on('close', (code) => {
      if (code === 0) {
        resolve({ success: true, output: stdout.trim(), error: null });
      } else {
        resolve({ success: false, output: stdout.trim(), error: stderr.trim() || `Exit code: ${code}` });
      }
    });

    ps.on('error', (err) => {
      reject(err);
    });

    // Timeout after 30 seconds
    setTimeout(() => {
      ps.kill();
      reject(new Error('Command timeout'));
    }, 30000);
  });
}

// IPC: Execute PowerShell commands
ipcMain.handle('execute-powershell', async (event, commands) => {
  const results = [];
  
  for (const cmd of commands) {
    try {
      const result = await executePowerShell(cmd.script);
      results.push({
        command: cmd.command,
        script: cmd.script,
        ...result
      });
    } catch (error) {
      results.push({
        command: cmd.command,
        script: cmd.script,
        success: false,
        output: null,
        error: error.message
      });
    }
  }
  
  return results;
});

// IPC: Check if running as admin
ipcMain.handle('check-admin', async () => {
  try {
    const result = await executePowerShell(
      '([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)'
    );
    return result.output.toLowerCase() === 'true';
  } catch (error) {
    return false;
  }
});

// IPC: Restart as admin
ipcMain.handle('restart-as-admin', async () => {
  const appPath = process.execPath;
  const args = process.argv.slice(1);
  
  try {
    await executePowerShell(
      `Start-Process "${appPath}" -ArgumentList "${args.join(' ')}" -Verb RunAs`
    );
    app.quit();
    return true;
  } catch (error) {
    return false;
  }
});

// IPC: Open external URL
ipcMain.handle('open-external', async (event, url) => {
  await shell.openExternal(url);
});

// IPC: Get System Information
ipcMain.handle('get-system-info', async () => {
  const systemInfo = {
    hostname: os.hostname(),
    platform: os.platform(),
    arch: os.arch(),
    uptime: os.uptime(),
    totalMemory: os.totalmem(),
    freeMemory: os.freemem(),
    cpuCores: os.cpus().length,
    osVersion: '',
    cpuName: '',
    gpuName: '',
    storage: '',
    aqmoptiVersion: 'v1.0.0'
  };

  try {
    // Get OS Version
    const osVersionResult = await executePowerShell('(Get-CimInstance Win32_OperatingSystem).Caption');
    if (osVersionResult.success) {
      systemInfo.osVersion = osVersionResult.output.trim();
    }

    // Get CPU Name
    const cpuResult = await executePowerShell('(Get-CimInstance Win32_Processor).Name');
    if (cpuResult.success) {
      systemInfo.cpuName = cpuResult.output.trim();
    }

    // Get GPU Name
    const gpuResult = await executePowerShell('(Get-CimInstance Win32_VideoController).Name | Select-Object -First 1');
    if (gpuResult.success) {
      systemInfo.gpuName = gpuResult.output.trim();
    }

    // Get Storage Info
    const storageResult = await executePowerShell("Get-CimInstance Win32_LogicalDisk -Filter \"DriveType=3\" | Select-Object DeviceID, @{N='SizeGB';E={[math]::Round($_.Size/1GB)}}, @{N='FreeGB';E={[math]::Round($_.FreeSpace/1GB)}} | ForEach-Object { \"$($_.DeviceID) $($_.SizeGB)GB ($($_.FreeGB)GB free)\" }");
    if (storageResult.success) {
      systemInfo.storage = storageResult.output.trim();
    }

  } catch (error) {
    console.error('Error getting system info:', error);
  }

  return systemInfo;
});

