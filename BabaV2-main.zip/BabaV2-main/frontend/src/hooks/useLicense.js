import { useState, useEffect } from 'react';
import { LICENSE_TYPES, hasFeatureAccess } from '../utils/licenseConfig';

/**
 * Hook pour gérer la licence utilisateur
 * Utilise la licence validée stockée dans localStorage après validation
 * 
 * @returns {Object} - État de la licence et méthodes
 */
export const useLicense = () => {
  const [userLicense, setUserLicense] = useState(() => {
    // D'abord vérifier la licence validée par le backend
    const validatedLicense = localStorage.getItem('validated_license');
    if (validatedLicense) {
      try {
        const parsed = JSON.parse(validatedLicense);
        if (parsed.plan && Object.values(LICENSE_TYPES).includes(parsed.plan)) {
          return parsed.plan;
        }
      } catch (e) {
        console.error('Error parsing validated license:', e);
      }
    }
    
    // Fallback: vérifier babatool_license
    const babatoolLicense = localStorage.getItem('babatool_license');
    if (babatoolLicense) {
      try {
        const parsed = JSON.parse(babatoolLicense);
        if (parsed.plan && Object.values(LICENSE_TYPES).includes(parsed.plan)) {
          return parsed.plan;
        }
      } catch (e) {
        console.error('Error parsing babatool license:', e);
      }
    }
    
    // Dernier fallback: user_license (pour rétrocompatibilité)
    const savedLicense = localStorage.getItem('user_license');
    return savedLicense && Object.values(LICENSE_TYPES).includes(savedLicense) 
      ? savedLicense 
      : LICENSE_TYPES.TRIAL;
  });
  const [isLoading, setIsLoading] = useState(false);

  // Écouter les changements de localStorage et les événements personnalisés
  useEffect(() => {
    const updateLicenseFromStorage = () => {
      // Priorité: validated_license > babatool_license > user_license
      const validatedLicense = localStorage.getItem('validated_license');
      if (validatedLicense) {
        try {
          const parsed = JSON.parse(validatedLicense);
          if (parsed.plan && Object.values(LICENSE_TYPES).includes(parsed.plan)) {
            setUserLicense(parsed.plan);
            return;
          }
        } catch (e) {}
      }
      
      const babatoolLicense = localStorage.getItem('babatool_license');
      if (babatoolLicense) {
        try {
          const parsed = JSON.parse(babatoolLicense);
          if (parsed.plan && Object.values(LICENSE_TYPES).includes(parsed.plan)) {
            setUserLicense(parsed.plan);
            return;
          }
        } catch (e) {}
      }
    };

    const handleStorageChange = (e) => {
      if (e.key === 'validated_license' || e.key === 'babatool_license' || e.key === 'user_license') {
        updateLicenseFromStorage();
      }
    };

    // Écouter les changements dans d'autres onglets
    window.addEventListener('storage', handleStorageChange);

    // Écouter les événements personnalisés (license-updated, licenseChanged)
    const handleLicenseUpdated = () => {
      updateLicenseFromStorage();
    };
    
    window.addEventListener('license-updated', handleLicenseUpdated);
    window.addEventListener('licenseChanged', handleLicenseUpdated);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('license-updated', handleLicenseUpdated);
      window.removeEventListener('licenseChanged', handleLicenseUpdated);
    };
  }, []);

  // Changer la licence (pour la démo uniquement)
  const setLicense = (newLicense) => {
    setUserLicense(newLicense);
    localStorage.setItem('user_license', newLicense);
    
    // Émettre un événement custom pour notifier tous les composants
    window.dispatchEvent(new CustomEvent('licenseChanged', { detail: newLicense }));
  };

  // Vérifier l'accès à une fonctionnalité
  const checkFeatureAccess = (feature) => {
    return hasFeatureAccess(userLicense, feature);
  };

  // Upgrade de licence (simulé)
  const upgradeLicense = async (targetLicense) => {
    setIsLoading(true);
    
    // TODO: Appeler l'API backend pour upgrader
    // await api.upgradeLicense(targetLicense);
    
    // Simulation
    return new Promise((resolve) => {
      setTimeout(() => {
        setLicense(targetLicense);
        setIsLoading(false);
        resolve({ success: true });
      }, 1000);
    });
  };

  return {
    userLicense,
    setLicense, // Pour la démo uniquement
    checkFeatureAccess,
    upgradeLicense,
    isLoading
  };
};
