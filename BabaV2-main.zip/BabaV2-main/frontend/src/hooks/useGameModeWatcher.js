import { useEffect, useState, useCallback } from 'react';

/**
 * Hook personnalisé pour surveiller le Game Mode Windows en temps réel
 * 
 * @returns {Object} - {
 *   gameModeEnabled: boolean - État actuel du Game Mode,
 *   isWatching: boolean - Si la surveillance est active,
 *   lastUpdate: string - Horodatage de la dernière mise à jour
 * }
 */
export function useGameModeWatcher() {
  const [gameModeEnabled, setGameModeEnabled] = useState(null);
  const [isWatching, setIsWatching] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(null);

  // Callback appelé quand le Game Mode change
  const handleGameModeChange = useCallback((data) => {
    console.log('🎮 Game Mode changé:', data);
    setGameModeEnabled(data.enabled);
    setLastUpdate(data.timestamp);
    
    // Optionnel : afficher une notification
    if (window.electronAPI?.showNotification) {
      window.electronAPI.showNotification(
        'Game Mode Windows',
        `Mode Jeu ${data.enabled ? 'activé' : 'désactivé'}`,
        'info'
      );
    }
  }, []);

  // Démarrer la surveillance au montage du composant
  useEffect(() => {
    if (!window.electronAPI?.startGameModeWatcher) {
      console.log('API Game Mode watcher non disponible (mode web)');
      return;
    }

    // Lire l'état initial
    const loadInitialState = async () => {
      try {
        const state = await window.electronAPI.readGameModeState();
        if (state.success) {
          setGameModeEnabled(state.enabled);
          setLastUpdate(new Date().toISOString());
        }
      } catch (error) {
        console.error('Erreur lecture état initial Game Mode:', error);
      }
    };

    loadInitialState();

    // Enregistrer l'écouteur de changements
    window.electronAPI.onGameModeChanged(handleGameModeChange);
    setIsWatching(true);

    // Nettoyage : retirer l'écouteur au démontage
    return () => {
      if (window.electronAPI?.removeGameModeListener) {
        window.electronAPI.removeGameModeListener();
      }
      setIsWatching(false);
    };
  }, [handleGameModeChange]);

  return {
    gameModeEnabled,
    isWatching,
    lastUpdate
  };
}

/**
 * Hook pour obtenir l'état actuel du Game Mode (une seule fois, pas de surveillance)
 */
export function useGameModeState() {
  const [gameModeEnabled, setGameModeEnabled] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadState = async () => {
      if (!window.electronAPI?.readGameModeState) {
        setLoading(false);
        return;
      }

      try {
        const state = await window.electronAPI.readGameModeState();
        if (state.success) {
          setGameModeEnabled(state.enabled);
        }
      } catch (error) {
        console.error('Erreur lecture Game Mode:', error);
      } finally {
        setLoading(false);
      }
    };

    loadState();
  }, []);

  return { gameModeEnabled, loading };
}
