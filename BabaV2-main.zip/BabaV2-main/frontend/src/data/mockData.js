// Mock data for BaBaTool with localStorage persistence

export const systemInfo = {
  osVersion: "Windows 11 Pro 24H2",
  babatoolVersion: "v1.2.0",
  cpuName: "AMD Ryzen 7 5800X3D",
  ramTotal: "32 GB DDR4",
  gpuName: "NVIDIA RTX 4070",
  storageTotal: "1 TB NVMe SSD",
  hostname: "BABATOOL-PC",
  uptime: "4 hours, 23 minutes"
};

// ============================================================================
// POWER PLAN SETTINGS
// ============================================================================

export const powerModes = [
  { 
    value: 'economy', 
    labelKey: 'mockData.powerModes.economy.label',
    icon: '🔋', 
    descriptionKey: 'mockData.powerModes.economy.description',
    powerPlanGuid: 'a1841308-3541-4fab-bc81-f71556f20b4a', // Power Saver
    commands: {
      powershell: [
        {
          command: 'Activer le mode Économie d\'énergie',
          script: 'powercfg /setactive a1841308-3541-4fab-bc81-f71556f20b4a',
          requireAdmin: true
        }
      ]
    }
  },
  { 
    value: 'normal', 
    labelKey: 'mockData.powerModes.normal.label',
    icon: '⚖️', 
    descriptionKey: 'mockData.powerModes.normal.description',
    powerPlanGuid: '381b4222-f694-41f0-9685-ff5bb260df2e', // Balanced
    commands: {
      powershell: [
        {
          command: 'Activer le mode Équilibré',
          script: 'powercfg /setactive 381b4222-f694-41f0-9685-ff5bb260df2e',
          requireAdmin: true
        }
      ]
    }
  },
  { 
    value: 'performance', 
    labelKey: 'mockData.powerModes.performance.label',
    icon: '⚡', 
    descriptionKey: 'mockData.powerModes.performance.description',
    powerPlanGuid: '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c', // High Performance
    commands: {
      powershell: [
        {
          command: 'Activer le mode Hautes performances',
          script: 'powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c',
          requireAdmin: true
        }
      ]
    }
  }
];

export const powerOptions = [
  {
    id: 'hibernate-enabled',
    titleKey: 'mockData.powerOptions.hibernate.title',
    descriptionKey: 'mockData.powerOptions.hibernate.description',
    categoryKey: 'mockData.categories.sleep',
    type: 'toggle',
    enabled: false,
    enableCommand: 'powercfg /hibernate on',
    disableCommand: 'powercfg /hibernate off',
    requireAdmin: true
  },
  {
    id: 'fast-startup',
    titleKey: 'mockData.powerOptions.fastStartup.title',
    descriptionKey: 'mockData.powerOptions.fastStartup.description',
    categoryKey: 'mockData.categories.startup',
    type: 'toggle',
    enabled: true,
    enableCommand: 'reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Power" /v HiberbootEnabled /t REG_DWORD /d 1 /f',
    disableCommand: 'reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Power" /v HiberbootEnabled /t REG_DWORD /d 0 /f',
    requireAdmin: true
  }
];

// ============================================================================
// HELPER FUNCTIONS FOR PERSISTENCE
// ============================================================================

const STORAGE_KEY = 'babatool_settings';

// Load saved settings from localStorage
const loadSavedSettings = () => {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : {};
  } catch (e) {
    console.error('Error loading settings:', e);
    return {};
  }
};

// Save settings to localStorage
export const saveSettingState = (settingId, enabled) => {
  try {
    const saved = loadSavedSettings();
    saved[settingId] = enabled;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
  } catch (e) {
    console.error('Error saving setting:', e);
  }
};

// Get setting state (from localStorage or default)
const getSettingState = (settingId, defaultValue) => {
  const saved = loadSavedSettings();
  return saved.hasOwnProperty(settingId) ? saved[settingId] : defaultValue;
};

// Apply saved states to settings array
const applyPersistedStates = (settings) => {
  return settings.map(setting => ({
    ...setting,
    enabled: getSettingState(setting.id, setting.enabled)
  }));
};

// ============================================================================
// DEFAULT SETTINGS DATA
// ============================================================================

const defaultPerformanceSettings = [
  {
    id: "power-plan",
    titleKey: "mockData.performanceSettings.powerPlan.title",
    descriptionKey: "mockData.performanceSettings.powerPlan.description",
    enabled: true,
    categoryKey: "mockData.categories.power",
    enableCommands: {
      powershell: [
        {
          command: "Set High Performance Power Plan",
          script: "powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c",
          requireAdmin: true
        }
      ]
    },
    disableCommands: {
      powershell: [
        {
          command: "Set Balanced Power Plan",
          script: "powercfg /setactive 381b4222-f694-41f0-9685-ff5bb260df2e",
          requireAdmin: true
        }
      ]
    }
  },
  {
    id: "game-mode",
    titleKey: "mockData.performanceSettings.gameMode.title",
    descriptionKey: "mockData.performanceSettings.gameMode.description",
    enabled: true,
    categoryKey: "mockData.categories.gaming",
    enableCommands: {
      powershell: [
        {
          command: "Enable Game Mode",
          script: "reg add HKCU\\Software\\Microsoft\\GameBar /v AutoGameModeEnabled /t REG_DWORD /d 1 /f",
          requireAdmin: false
        },
        {
          command: "Enable Auto Game Mode",
          script: "reg add HKCU\\Software\\Microsoft\\GameBar /v AllowAutoGameMode /t REG_DWORD /d 1 /f",
          requireAdmin: false
        }
      ]
    },
    disableCommands: {
      powershell: [
        {
          command: "Disable Game Mode",
          script: "reg add HKCU\\Software\\Microsoft\\GameBar /v AutoGameModeEnabled /t REG_DWORD /d 0 /f",
          requireAdmin: false
        },
        {
          command: "Disable Auto Game Mode",
          script: "reg add HKCU\\Software\\Microsoft\\GameBar /v AllowAutoGameMode /t REG_DWORD /d 0 /f",
          requireAdmin: false
        }
      ]
    }
  },
  {
    id: "hpet",
    titleKey: "mockData.performanceSettings.hpet.title",
    descriptionKey: "mockData.performanceSettings.hpet.description",
    enabled: false,
    categoryKey: "mockData.categories.timers",
    enableCommands: {
      powershell: [
        {
          command: "Disable HPET",
          script: "bcdedit /set useplatformclock false",
          requireAdmin: true
        },
        {
          command: "Disable Dynamic Tick",
          script: "bcdedit /set disabledynamictick yes",
          requireAdmin: true
        }
      ]
    },
    disableCommands: {
      powershell: [
        {
          command: "Enable HPET",
          script: "bcdedit /set useplatformclock true",
          requireAdmin: true
        },
        {
          command: "Enable Dynamic Tick",
          script: "bcdedit /set disabledynamictick no",
          requireAdmin: true
        }
      ]
    }
  },
  {
    id: "core-parking",
    titleKey: "mockData.performanceSettings.coreParking.title",
    descriptionKey: "mockData.performanceSettings.coreParking.description",
    enabled: true,
    categoryKey: "mockData.categories.power",
    enableCommands: {
      powershell: [
        {
          command: "Disable Core Parking",
          script: "powercfg -setacvalueindex scheme_current sub_processor CPMINCORES 100",
          requireAdmin: true
        },
        {
          command: "Apply Changes",
          script: "powercfg -setactive scheme_current",
          requireAdmin: true
        }
      ]
    },
    disableCommands: {
      powershell: [
        {
          command: "Enable Core Parking",
          script: "powercfg -setacvalueindex scheme_current sub_processor CPMINCORES 0",
          requireAdmin: true
        },
        {
          command: "Apply Changes",
          script: "powercfg -setactive scheme_current",
          requireAdmin: true
        }
      ]
    }
  },
  {
    id: "fsync",
    titleKey: "mockData.performanceSettings.fso.title",
    descriptionKey: "mockData.performanceSettings.fso.description",
    enabled: false,
    categoryKey: "mockData.categories.gaming",
    enableCommands: {
      powershell: [
        {
          command: "Enable Fullscreen Optimizations",
          script: "reg delete \"HKCU\\System\\GameConfigStore\" /v GameDVR_FSEBehaviorMode /f 2>nul",
          requireAdmin: false
        }
      ]
    },
    disableCommands: {
      powershell: [
        {
          command: "Disable Fullscreen Optimizations",
          script: "reg add \"HKCU\\System\\GameConfigStore\" /v GameDVR_FSEBehaviorMode /t REG_DWORD /d 2 /f",
          requireAdmin: false
        }
      ]
    }
  },
  {
    id: "superfetch",
    titleKey: "mockData.performanceSettings.superfetch.title",
    descriptionKey: "mockData.performanceSettings.superfetch.description",
    enabled: true,
    categoryKey: "mockData.categories.services",
    enableCommands: {
      powershell: [
        {
          command: "Disable SysMain Service",
          script: "Stop-Service -Name \"SysMain\" -Force",
          requireAdmin: true
        },
        {
          command: "Set Service to Disabled",
          script: "Set-Service -Name \"SysMain\" -StartupType Disabled",
          requireAdmin: true
        }
      ]
    },
    disableCommands: {
      powershell: [
        {
          command: "Enable SysMain Service",
          script: "Set-Service -Name \"SysMain\" -StartupType Automatic",
          requireAdmin: true
        },
        {
          command: "Start SysMain Service",
          script: "Start-Service -Name \"SysMain\"",
          requireAdmin: true
        }
      ]
    }
  }
];

const defaultPrivacySettings = [
  {
    id: "telemetry",
    titleKey: "mockData.privacySettings.telemetry.title",
    descriptionKey: "mockData.privacySettings.telemetry.description",
    enabled: true,
    categoryKey: "mockData.categories.telemetry"
  },
  {
    id: "advertising-id",
    titleKey: "mockData.privacySettings.advertisingId.title",
    descriptionKey: "mockData.privacySettings.advertisingId.description",
    enabled: true,
    categoryKey: "mockData.categories.advertising"
  },
  {
    id: "activity-history",
    titleKey: "mockData.privacySettings.activityHistory.title",
    descriptionKey: "mockData.privacySettings.activityHistory.description",
    enabled: true,
    categoryKey: "mockData.categories.telemetry"
  },
  {
    id: "location-tracking",
    titleKey: "mockData.privacySettings.locationTracking.title",
    descriptionKey: "mockData.privacySettings.locationTracking.description",
    enabled: true,
    categoryKey: "mockData.categories.location"
  },
  {
    id: "cortana",
    titleKey: "mockData.privacySettings.cortana.title",
    descriptionKey: "mockData.privacySettings.cortana.description",
    enabled: true,
    categoryKey: "mockData.categories.features"
  },
  {
    id: "diagnostic-data",
    titleKey: "mockData.privacySettings.diagnosticData.title",
    descriptionKey: "mockData.privacySettings.diagnosticData.description",
    enabled: true,
    categoryKey: "mockData.categories.telemetry"
  }
];

const defaultInterfaceSettings = [
  {
    id: "classic-context",
    titleKey: "mockData.interfaceSettings.classicContext.title",
    descriptionKey: "mockData.interfaceSettings.classicContext.description",
    enabled: false,
    categoryKey: "mockData.categories.explorer"
  },
  {
    id: "legacy-alt-tab",
    titleKey: "mockData.interfaceSettings.legacyAltTab.title",
    descriptionKey: "mockData.interfaceSettings.legacyAltTab.description",
    enabled: false,
    categoryKey: "mockData.categories.system"
  },
  {
    id: "taskbar-left",
    titleKey: "mockData.interfaceSettings.taskbarLeft.title",
    descriptionKey: "mockData.interfaceSettings.taskbarLeft.description",
    enabled: false,
    categoryKey: "mockData.categories.taskbar"
  },
  {
    id: "dark-mode",
    titleKey: "mockData.interfaceSettings.darkMode.title",
    descriptionKey: "mockData.interfaceSettings.darkMode.description",
    enabled: true,
    categoryKey: "mockData.categories.theme"
  },
  {
    id: "animations",
    titleKey: "mockData.interfaceSettings.animations.title",
    descriptionKey: "mockData.interfaceSettings.animations.description",
    enabled: true,
    categoryKey: "mockData.categories.visual"
  },
  {
    id: "transparency",
    titleKey: "mockData.interfaceSettings.transparency.title",
    descriptionKey: "mockData.interfaceSettings.transparency.description",
    enabled: true,
    categoryKey: "mockData.categories.visual"
  }
];

const defaultAdvancedSettings = [
  {
    id: "defender",
    titleKey: "mockData.advancedSettings.defender.title",
    descriptionKey: "mockData.advancedSettings.defender.description",
    enabled: true,
    categoryKey: "mockData.categories.security",
    warning: true
  },
  {
    id: "smartscreen",
    titleKey: "mockData.advancedSettings.smartscreen.title",
    descriptionKey: "mockData.advancedSettings.smartscreen.description",
    enabled: true,
    categoryKey: "mockData.categories.security",
    warning: true
  },
  {
    id: "uac",
    titleKey: "mockData.advancedSettings.uac.title",
    descriptionKey: "mockData.advancedSettings.uac.description",
    enabled: true,
    categoryKey: "mockData.categories.security",
    warning: true
  },
  {
    id: "windows-update",
    titleKey: "mockData.advancedSettings.windowsUpdate.title",
    descriptionKey: "mockData.advancedSettings.windowsUpdate.description",
    enabled: true,
    categoryKey: "mockData.categories.updates"
  },
  {
    id: "mitigations",
    titleKey: "mockData.advancedSettings.mitigations.title",
    descriptionKey: "mockData.advancedSettings.mitigations.description",
    enabled: true,
    categoryKey: "mockData.categories.security",
    warning: true
  }
];

const defaultBloatwareSettings = [
  {
    id: "xbox-gamebar",
    titleKey: "mockData.bloatwareSettings.xboxGamebar.title",
    descriptionKey: "mockData.bloatwareSettings.xboxGamebar.description",
    enabled: false,
    categoryKey: "mockData.categories.xbox"
  },
  {
    id: "onedrive",
    titleKey: "mockData.bloatwareSettings.onedrive.title",
    descriptionKey: "mockData.bloatwareSettings.onedrive.description",
    enabled: false,
    categoryKey: "mockData.categories.microsoftApps"
  },
  {
    id: "cortana",
    titleKey: "mockData.bloatwareSettings.cortana.title",
    descriptionKey: "mockData.bloatwareSettings.cortana.description",
    enabled: false,
    categoryKey: "mockData.categories.microsoftApps"
  },
  {
    id: "teams",
    titleKey: "mockData.bloatwareSettings.teams.title",
    descriptionKey: "mockData.bloatwareSettings.teams.description",
    enabled: false,
    categoryKey: "mockData.categories.microsoftApps"
  },
  {
    id: "widgets",
    titleKey: "mockData.bloatwareSettings.widgets.title",
    descriptionKey: "mockData.bloatwareSettings.widgets.description",
    enabled: false,
    categoryKey: "mockData.categories.windowsApps"
  },
  {
    id: "solitaire",
    titleKey: "mockData.bloatwareSettings.solitaire.title",
    descriptionKey: "mockData.bloatwareSettings.solitaire.description",
    enabled: false,
    categoryKey: "mockData.categories.windowsApps"
  }
];

// ============================================================================
// EXPORTED SETTINGS WITH PERSISTENCE
// ============================================================================

// These getters return settings with persisted states applied
export const getPerformanceSettings = () => applyPersistedStates(defaultPerformanceSettings);
export const getPrivacySettings = () => applyPersistedStates(defaultPrivacySettings);
export const getInterfaceSettings = () => applyPersistedStates(defaultInterfaceSettings);
export const getAdvancedSettings = () => applyPersistedStates(defaultAdvancedSettings);
export const getBloatwareSettings = () => applyPersistedStates(defaultBloatwareSettings);

// Legacy exports for backward compatibility (initial load)
export const performanceSettings = applyPersistedStates(defaultPerformanceSettings);
export const privacySettings = applyPersistedStates(defaultPrivacySettings);
export const interfaceSettings = applyPersistedStates(defaultInterfaceSettings);
export const advancedSettings = applyPersistedStates(defaultAdvancedSettings);
export const bloatwareSettings = applyPersistedStates(defaultBloatwareSettings);

// Static data (no persistence needed)
export const driverCategories = [
  {
    id: "nvidia",
    name: "NVIDIA Drivers",
    icon: "Gpu",
    description: "Download and install NVIDIA graphics drivers",
    url: "https://www.nvidia.com/Download/index.aspx"
  },
  {
    id: "amd",
    name: "AMD Drivers",
    icon: "Cpu",
    description: "Download and install AMD graphics/chipset drivers",
    url: "https://www.amd.com/en/support"
  },
  {
    id: "intel",
    name: "Intel Drivers",
    icon: "Microchip",
    description: "Download and install Intel drivers",
    url: "https://www.intel.com/content/www/us/en/download-center/home.html"
  },
  {
    id: "chipset",
    name: "Chipset Drivers",
    icon: "CircuitBoard",
    description: "Download motherboard chipset drivers",
    url: ""
  },
  {
    id: "audio",
    name: "Audio Drivers",
    icon: "Volume2",
    description: "Download and install audio drivers",
    url: ""
  },
  {
    id: "network",
    name: "Network Drivers",
    icon: "Wifi",
    description: "Download network adapter drivers",
    url: ""
  }
];

export const quickActions = [
  {
    id: "apply-tweaks",
    title: "Apply Recommended Tweaks",
    description: "Apply all recommended BaBaTool optimizations",
    icon: "Zap",
    color: "red"
  },
  {
    id: "restore-defaults",
    title: "Restore Defaults",
    description: "Restore all settings to Windows defaults",
    icon: "RotateCcw",
    color: "orange"
  },
  {
    id: "create-restore",
    title: "Create Restore Point",
    description: "Create a system restore point",
    icon: "Save",
    color: "green"
  }
];

// ============================================================================
// GAMING SETTINGS
// ============================================================================

export const gamingOptions = [
  {
    id: 'game-mode',
    titleKey: 'mockData.gamingOptions.gameMode.title',
    descriptionKey: 'mockData.gamingOptions.gameMode.description',
    categoryKey: 'mockData.categories.system',
    enabled: true,
    enableCommands: {
      powershell: [
        {
          command: 'Enable Game Mode',
          script: 'reg add "HKCU\\Software\\Microsoft\\GameBar" /v AutoGameModeEnabled /t REG_DWORD /d 1 /f',
          requireAdmin: false
        }
      ]
    },
    disableCommands: {
      powershell: [
        {
          command: 'Disable Game Mode',
          script: 'reg add "HKCU\\Software\\Microsoft\\GameBar" /v AutoGameModeEnabled /t REG_DWORD /d 0 /f',
          requireAdmin: false
        }
      ]
    }
  },
  {
    id: 'hardware-acceleration',
    titleKey: 'mockData.gamingOptions.hags.title',
    descriptionKey: 'mockData.gamingOptions.hags.description',
    categoryKey: 'mockData.categories.gpu',
    enabled: true,
    enableCommands: {
      powershell: [
        {
          command: 'Enable Hardware-Accelerated GPU Scheduling',
          script: 'reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers" /v HwSchMode /t REG_DWORD /d 2 /f',
          requireAdmin: true
        }
      ]
    },
    disableCommands: {
      powershell: [
        {
          command: 'Disable Hardware-Accelerated GPU Scheduling',
          script: 'reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers" /v HwSchMode /t REG_DWORD /d 1 /f',
          requireAdmin: true
        }
      ]
    }
  },
  {
    id: 'game-dvr',
    titleKey: 'mockData.gamingOptions.gameDvr.title',
    descriptionKey: 'mockData.gamingOptions.gameDvr.description',
    categoryKey: 'mockData.categories.gamebar',
    enabled: true,
    enableCommands: {
      powershell: [
        {
          command: 'Disable Game DVR',
          script: 'reg add "HKCU\\System\\GameConfigStore" /v GameDVR_Enabled /t REG_DWORD /d 0 /f',
          requireAdmin: false
        }
      ]
    },
    disableCommands: {
      powershell: [
        {
          command: 'Enable Game DVR',
          script: 'reg add "HKCU\\System\\GameConfigStore" /v GameDVR_Enabled /t REG_DWORD /d 1 /f',
          requireAdmin: false
        }
      ]
    }
  },
  {
    id: 'fullscreen-optimization',
    titleKey: 'mockData.gamingOptions.fullscreenOpt.title',
    descriptionKey: 'mockData.gamingOptions.fullscreenOpt.description',
    categoryKey: 'mockData.categories.display',
    enabled: true,
    enableCommands: {
      powershell: [
        {
          command: 'Disable Fullscreen Optimizations',
          script: 'reg add "HKCU\\System\\GameConfigStore" /v GameDVR_FSEBehaviorMode /t REG_DWORD /d 2 /f',
          requireAdmin: false
        }
      ]
    },
    disableCommands: {
      powershell: [
        {
          command: 'Enable Fullscreen Optimizations',
          script: 'reg delete "HKCU\\System\\GameConfigStore" /v GameDVR_FSEBehaviorMode /f',
          requireAdmin: false
        }
      ]
    }
  },
  {
    id: 'mouse-acceleration',
    titleKey: 'mockData.gamingOptions.mouseAccel.title',
    descriptionKey: 'mockData.gamingOptions.mouseAccel.description',
    categoryKey: 'mockData.categories.peripherals',
    enabled: true,
    enableCommands: {
      powershell: [
        {
          command: 'Disable Mouse Acceleration',
          script: 'reg add "HKCU\\Control Panel\\Mouse" /v MouseSpeed /t REG_SZ /d 0 /f; reg add "HKCU\\Control Panel\\Mouse" /v MouseThreshold1 /t REG_SZ /d 0 /f; reg add "HKCU\\Control Panel\\Mouse" /v MouseThreshold2 /t REG_SZ /d 0 /f',
          requireAdmin: false
        }
      ]
    },
    disableCommands: {
      powershell: [
        {
          command: 'Enable Mouse Acceleration',
          script: 'reg add "HKCU\\Control Panel\\Mouse" /v MouseSpeed /t REG_SZ /d 1 /f; reg add "HKCU\\Control Panel\\Mouse" /v MouseThreshold1 /t REG_SZ /d 6 /f; reg add "HKCU\\Control Panel\\Mouse" /v MouseThreshold2 /t REG_SZ /d 10 /f',
          requireAdmin: false
        }
      ]
    }
  },
  {
    id: 'priority-separation',
    titleKey: 'mockData.gamingOptions.prioritySeparation.title',
    descriptionKey: 'mockData.gamingOptions.prioritySeparation.description',
    categoryKey: 'mockData.categories.system',
    enabled: true,
    enableCommands: {
      powershell: [
        {
          command: 'Set Priority Separation',
          script: 'reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\PriorityControl" /v Win32PrioritySeparation /t REG_DWORD /d 38 /f',
          requireAdmin: true
        }
      ]
    },
    disableCommands: {
      powershell: [
        {
          command: 'Reset Priority Separation',
          script: 'reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\PriorityControl" /v Win32PrioritySeparation /t REG_DWORD /d 2 /f',
          requireAdmin: true
        }
      ]
    }
  }
];

// ============================================================================
// OBS SETTINGS
// ============================================================================

export const obsGpuTypes = [
  { 
    value: 'nvidia', 
    label: 'NVIDIA', 
    icon: '/nvidia-icon.png',
    description: 'GPU NVIDIA GeForce/RTX'
  },
  { 
    value: 'amd', 
    label: 'AMD', 
    icon: '/amd-icon.png',
    description: 'GPU AMD Radeon'
  }
];

export const generateObsProfile = (gpuType) => {
  const timestamp = new Date().toISOString();
  
  if (gpuType === 'nvidia') {
    return {
      name: `BabaToolbox_NVIDIA_Profile`,
      created: timestamp,
      gpu: gpuType,
      files: {
        'basic.ini': `[General]
Name=nvidia

[Output]
Mode=Advanced
FilenameFormatting=%CCYY-%MM-%DD %hh-%mm-%ss

[AdvOut]
ApplyServiceSettings=true
Encoder=obs_nvenc_h264_tex
RecType=Standard
RecFilePath=C:%USERPROFILE%\\Videos
RecFormat2=hybrid_mp4
RecTracks=1
AudioEncoder=ffmpeg_aac
RecAudioEncoder=ffmpeg_aac

[Video]
BaseCX=1920
BaseCY=1080
OutputCX=1920
OutputCY=1080
FPSCommon=60
ScaleType=bicubic
ColorFormat=NV12
ColorSpace=709
ColorRange=Partial

[Audio]
SampleRate=48000
ChannelSetup=Stereo`,
        
        'recordEncoder.json': JSON.stringify({
          "encoder": "jim_nvenc",
          "rate_control": "CBR",
          "bitrate": 6000,
          "preset": "p5",
          "profile": "high",
          "gpu": 0,
          "bf": 2,
          "psycho_aq": true,
          "lookahead": false,
          "repeat_headers": true
        }, null, 2),
        
        'streamEncoder.json': JSON.stringify({
          "encoder": "jim_nvenc",
          "rate_control": "CBR",
          "bitrate": 6000,
          "preset": "p5",
          "profile": "high",
          "gpu": 0,
          "bf": 2,
          "psycho_aq": true,
          "lookahead": false,
          "keyint_sec": 2,
          "repeat_headers": true
        }, null, 2)
      },
      description: "Profil optimisé pour GPU NVIDIA avec encodeur NVENC"
    };
  } else if (gpuType === 'amd') {
    return {
      name: `BabaToolbox_AMD_Profile`,
      created: timestamp,
      gpu: gpuType,
      files: {
        'basic.ini': `[General]
Name=amd

[Output]
Mode=Advanced
FilenameFormatting=%CCYY-%MM-%DD %hh-%mm-%ss

[AdvOut]
ApplyServiceSettings=true
Encoder=amd_amf_h264
RecType=Standard
RecFilePath=C:%USERPROFILE%\\Videos
RecFormat2=hybrid_mp4
RecTracks=1
AudioEncoder=ffmpeg_aac
RecAudioEncoder=ffmpeg_aac

[Video]
BaseCX=1920
BaseCY=1080
OutputCX=1920
OutputCY=1080
FPSCommon=60
ScaleType=bicubic
ColorFormat=NV12
ColorSpace=709
ColorRange=Partial

[Audio]
SampleRate=48000
ChannelSetup=Stereo`,
        
        'recordEncoder.json': JSON.stringify({
          "encoder": "amd_amf_h264",
          "rate_control": "CBR",
          "bitrate": 6000,
          "preset": "quality",
          "profile": "high",
          "bf": 0,
          "qvbr_quality_level": 0,
          "filler_data": false,
          "vbaq": true,
          "enforce_hrd": false
        }, null, 2),
        
        'streamEncoder.json': JSON.stringify({
          "encoder": "amd_amf_h264",
          "rate_control": "CBR",
          "bitrate": 6000,
          "preset": "quality",
          "profile": "high",
          "bf": 0,
          "qvbr_quality_level": 0,
          "keyint_sec": 2,
          "vbaq": true,
          "enforce_hrd": false
        }, null, 2)
      },
      description: "Profil optimisé pour GPU AMD avec encodeur AMF"
    };
  }
};

// ============================================================================
// FORTNITE SETTINGS
// ============================================================================

export const fortniteSettings = {
  resolution: {
    label: 'Résolution',
    options: [
      { value: '1920x1080', label: '1920x1080 (Full HD)' },
      { value: '2560x1440', label: '2560x1440 (2K)' },
      { value: '3840x2160', label: '3840x2160 (4K)' },
      { value: '1280x720', label: '1280x720 (HD)' },
      { value: '1600x900', label: '1600x900' }
    ],
    default: '1920x1080'
  },
  windowMode: {
    label: 'Mode fenêtre',
    options: [
      { value: 0, label: 'Plein écran' },
      { value: 1, label: 'Fenêtré' },
      { value: 2, label: 'Fenêtré sans bordure' }
    ],
    default: 2
  },
  viewDistance: {
    label: 'Distance de vue',
    options: [
      { value: 0, label: 'Proche' },
      { value: 1, label: 'Moyenne' },
      { value: 2, label: 'Lointaine' }
    ],
    default: 0
  },
  shadows: {
    label: 'Ombres',
    options: [
      { value: 0, label: 'Désactivé' },
      { value: 1, label: 'Faible' },
      { value: 2, label: 'Moyen' }
    ],
    default: 0
  },
  antiAliasing: {
    label: 'Anti-aliasing',
    options: [
      { value: 0, label: 'Désactivé' },
      { value: 1, label: 'Faible' },
      { value: 2, label: 'Moyen' }
    ],
    default: 0
  },
  textures: {
    label: 'Textures',
    options: [
      { value: 0, label: 'Faible' },
      { value: 1, label: 'Moyen' },
      { value: 2, label: 'Élevé' }
    ],
    default: 0
  },
  effects: {
    label: 'Effets',
    options: [
      { value: 0, label: 'Faible' },
      { value: 1, label: 'Moyen' },
      { value: 2, label: 'Élevé' }
    ],
    default: 0
  },
  postProcessing: {
    label: 'Post-traitement',
    options: [
      { value: 0, label: 'Faible' },
      { value: 1, label: 'Moyen' },
      { value: 2, label: 'Élevé' }
    ],
    default: 0
  }
};

export const generateFortniteConfig = (customSettings = {}) => {
  // Default settings with fixed values for optimal performance
  const defaultSettings = {
    resolution: '1920x1080',
    windowMode: 2, // Fenêtré sans bordure
    viewDistance: 0,
    shadows: 0,
    antiAliasing: 0,
    textures: 0,
    effects: 0,
    postProcessing: 0,
    frameRateLimit: 0, // Illimité
    vsync: false,
    motionBlur: false,
    showFPS: true
  };
  
  // Merge with custom settings
  const settings = { ...defaultSettings, ...customSettings };
  
  // Parse resolution
  const [resX, resY] = settings.resolution.split('x');
  
  // Generate GameUserSettings.ini content
  const iniContent = `[ScalabilityGroups]
sg.ResolutionQuality=100
sg.ViewDistanceQuality=${settings.viewDistance}
sg.AntiAliasingQuality=${settings.antiAliasing}
sg.ShadowQuality=${settings.shadows}
sg.PostProcessQuality=${settings.postProcessing}
sg.TextureQuality=${settings.textures}
sg.EffectsQuality=${settings.effects}
sg.FoliageQuality=${settings.effects}
sg.ShadingQuality=${settings.effects}

[/Script/FortniteGame.FortGameUserSettings]
bMotionBlur=${settings.motionBlur}
bShowFPS=${settings.showFPS}
bUseVSync=${settings.vsync}
FrameRateLimit=${settings.frameRateLimit}.000000
ResolutionSizeX=${resX}
ResolutionSizeY=${resY}
LastConfirmedResolutionSizeX=${resX}
LastConfirmedResolutionSizeY=${resY}
WindowPosX=-1
WindowPosY=-1
FullscreenMode=${settings.windowMode}
LastConfirmedFullscreenMode=${settings.windowMode}
PreferredFullscreenMode=${settings.windowMode}
bUseDesktopResolutionForFullscreen=False
DesiredScreenWidth=${resX}
DesiredScreenHeight=${resY}
LastUserConfirmedDesiredScreenWidth=${resX}
LastUserConfirmedDesiredScreenHeight=${resY}
bDisableMouseAcceleration=True`;

  return {
    name: 'Fortnite_Custom_Config',
    settings: settings,
    iniContent: iniContent
  };
};

// ============================================================================
// INTERFACE SETTINGS - CUSTOM WINDOWS, OLD MENU, TASKBAR
// ============================================================================

export const interfaceCommands = {
  customWindows: {
    darkTheme: {
      enable: {
        command: 'Enable Dark Theme',
        script: `$path = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize"
if (-not (Test-Path $path)) {
  New-Item -Path $path -Force | Out-Null
}
Set-ItemProperty -Path $path -Name "AppsUseLightTheme" -Value 0 -Type DWord -Force
Set-ItemProperty -Path $path -Name "SystemUsesLightTheme" -Value 0 -Type DWord -Force
Write-Output "SUCCESS: Dark theme enabled"`,
        requireAdmin: false
      },
      disable: {
        command: 'Disable Dark Theme',
        script: `$path = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize"
if (-not (Test-Path $path)) {
  New-Item -Path $path -Force | Out-Null
}
Set-ItemProperty -Path $path -Name "AppsUseLightTheme" -Value 1 -Type DWord -Force
Set-ItemProperty -Path $path -Name "SystemUsesLightTheme" -Value 1 -Type DWord -Force
Write-Output "SUCCESS: Dark theme disabled"`,
        requireAdmin: false
      }
    },
    transparency: {
      enable: {
        command: 'Enable Transparency',
        script: `$path = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize"
if (-not (Test-Path $path)) {
  New-Item -Path $path -Force | Out-Null
}
Set-ItemProperty -Path $path -Name "EnableTransparency" -Value 1 -Type DWord -Force
Write-Output "SUCCESS: Transparency enabled"`,
        requireAdmin: false
      },
      disable: {
        command: 'Disable Transparency',
        script: `$path = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize"
if (-not (Test-Path $path)) {
  New-Item -Path $path -Force | Out-Null
}
Set-ItemProperty -Path $path -Name "EnableTransparency" -Value 0 -Type DWord -Force
Write-Output "SUCCESS: Transparency disabled"`,
        requireAdmin: false
      }
    },
    effects: {
      enable: {
        command: 'Enable Visual Effects',
        script: `# Activer les effets d'animation Windows (Parametres > Accessibilite > Effets visuels)
$advPath = "HKCU:\\Control Panel\\Desktop"

# Activer MinAnimate pour les animations de fenetres
Set-ItemProperty -Path $advPath -Name "MinAnimate" -Value "1" -Type String -Force

# Activer via SystemParametersInfo pour application immediate
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class AnimationEffects {
    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool SystemParametersInfo(uint uiAction, uint uiParam, IntPtr pvParam, uint fWinIni);
    
    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool SystemParametersInfo(uint uiAction, uint uiParam, ref ANIMATIONINFO pvParam, uint fWinIni);
    
    [StructLayout(LayoutKind.Sequential)]
    public struct ANIMATIONINFO {
        public uint cbSize;
        public int iMinAnimate;
    }
    
    public const uint SPI_SETANIMATION = 0x0049;
    public const uint SPI_SETCLIENTAREAANIMATION = 0x1043;
    public const uint SPIF_SENDCHANGE = 0x02;
    public const uint SPIF_UPDATEINIFILE = 0x01;
    
    public static void Enable() {
        // Activer animation des fenetres
        ANIMATIONINFO ai = new ANIMATIONINFO();
        ai.cbSize = (uint)Marshal.SizeOf(typeof(ANIMATIONINFO));
        ai.iMinAnimate = 1;
        SystemParametersInfo(SPI_SETANIMATION, ai.cbSize, ref ai, SPIF_SENDCHANGE | SPIF_UPDATEINIFILE);
        
        // Activer animation des controles
        SystemParametersInfo(SPI_SETCLIENTAREAANIMATION, 0, (IntPtr)1, SPIF_SENDCHANGE | SPIF_UPDATEINIFILE);
    }
}
"@

[AnimationEffects]::Enable()

# Mettre a jour UserPreferencesMask pour activer toutes les animations
$currentMask = (Get-ItemProperty -Path $advPath -Name "UserPreferencesMask" -ErrorAction SilentlyContinue).UserPreferencesMask
if ($currentMask) {
  $mask = [byte[]]$currentMask
  # Activer les bits d'animation (bit 1 du byte 1)
  $mask[1] = $mask[1] -bor 0x02
  Set-ItemProperty -Path $advPath -Name "UserPreferencesMask" -Value $mask -Type Binary -Force
}

Write-Output "SUCCESS: Animation effects enabled"`,
        requireAdmin: false
      },
      disable: {
        command: 'Disable Visual Effects',
        script: `# Desactiver les effets d'animation Windows (Parametres > Accessibilite > Effets visuels)
$advPath = "HKCU:\\Control Panel\\Desktop"

# Desactiver MinAnimate pour les animations de fenetres
Set-ItemProperty -Path $advPath -Name "MinAnimate" -Value "0" -Type String -Force

# Desactiver via SystemParametersInfo pour application immediate
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class AnimationEffectsOff {
    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool SystemParametersInfo(uint uiAction, uint uiParam, IntPtr pvParam, uint fWinIni);
    
    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool SystemParametersInfo(uint uiAction, uint uiParam, ref ANIMATIONINFO pvParam, uint fWinIni);
    
    [StructLayout(LayoutKind.Sequential)]
    public struct ANIMATIONINFO {
        public uint cbSize;
        public int iMinAnimate;
    }
    
    public const uint SPI_SETANIMATION = 0x0049;
    public const uint SPI_SETCLIENTAREAANIMATION = 0x1043;
    public const uint SPIF_SENDCHANGE = 0x02;
    public const uint SPIF_UPDATEINIFILE = 0x01;
    
    public static void Disable() {
        // Desactiver animation des fenetres
        ANIMATIONINFO ai = new ANIMATIONINFO();
        ai.cbSize = (uint)Marshal.SizeOf(typeof(ANIMATIONINFO));
        ai.iMinAnimate = 0;
        SystemParametersInfo(SPI_SETANIMATION, ai.cbSize, ref ai, SPIF_SENDCHANGE | SPIF_UPDATEINIFILE);
        
        // Desactiver animation des controles
        SystemParametersInfo(SPI_SETCLIENTAREAANIMATION, 0, IntPtr.Zero, SPIF_SENDCHANGE | SPIF_UPDATEINIFILE);
    }
}
"@

[AnimationEffectsOff]::Disable()

# Mettre a jour UserPreferencesMask pour desactiver les animations
$currentMask = (Get-ItemProperty -Path $advPath -Name "UserPreferencesMask" -ErrorAction SilentlyContinue).UserPreferencesMask
if ($currentMask) {
  $mask = [byte[]]$currentMask
  # Desactiver les bits d'animation (bit 1 du byte 1)
  $mask[1] = $mask[1] -band (-bnot 0x02)
  Set-ItemProperty -Path $advPath -Name "UserPreferencesMask" -Value $mask -Type Binary -Force
}

Write-Output "SUCCESS: Animation effects disabled"`,
        requireAdmin: false
      }
    },
    accentColor: {
      command: 'Apply Accent Color',
      script: (hexColor) => `$hexColor = "${hexColor}"
$hex = $hexColor -replace '#', ''
$r = [convert]::ToInt32($hex.Substring(0,2), 16)
$g = [convert]::ToInt32($hex.Substring(2,2), 16)
$b = [convert]::ToInt32($hex.Substring(4,2), 16)

# Format ABGR pour Windows (Alpha, Blue, Green, Red)
$abgrValue = [uint32](0xFF000000 -bor ($b -shl 16) -bor ($g -shl 8) -bor $r)

# Chemin DWM pour la couleur des fenetres
$dwmPath = "HKCU:\\Software\\Microsoft\\Windows\\DWM"
if (-not (Test-Path $dwmPath)) {
  New-Item -Path $dwmPath -Force | Out-Null
}
Set-ItemProperty -Path $dwmPath -Name "AccentColor" -Value $abgrValue -Type DWord -Force
Set-ItemProperty -Path $dwmPath -Name "ColorizationColor" -Value $abgrValue -Type DWord -Force
Set-ItemProperty -Path $dwmPath -Name "ColorizationAfterglow" -Value $abgrValue -Type DWord -Force

# Chemin Accent pour le menu demarrer et la barre des taches
$accentPath = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Accent"
if (-not (Test-Path $accentPath)) {
  New-Item -Path $accentPath -Force | Out-Null
}
Set-ItemProperty -Path $accentPath -Name "AccentColorMenu" -Value $abgrValue -Type DWord -Force
Set-ItemProperty -Path $accentPath -Name "StartColorMenu" -Value $abgrValue -Type DWord -Force

# Creer le tableau AccentPalette avec la couleur
$palette = New-Object byte[] 32
$palette[0] = $r; $palette[1] = $g; $palette[2] = $b; $palette[3] = 0xFF
$palette[4] = $r; $palette[5] = $g; $palette[6] = $b; $palette[7] = 0xFF
$palette[8] = $r; $palette[9] = $g; $palette[10] = $b; $palette[11] = 0xFF
$palette[12] = $r; $palette[13] = $g; $palette[14] = $b; $palette[15] = 0xFF
$palette[16] = $r; $palette[17] = $g; $palette[18] = $b; $palette[19] = 0xFF
$palette[20] = $r; $palette[21] = $g; $palette[22] = $b; $palette[23] = 0xFF
$palette[24] = $r; $palette[25] = $g; $palette[26] = $b; $palette[27] = 0xFF
$palette[28] = $r; $palette[29] = $g; $palette[30] = $b; $palette[31] = 0xFF
Set-ItemProperty -Path $accentPath -Name "AccentPalette" -Value $palette -Type Binary -Force

Write-Output "SUCCESS: Accent color applied ($hexColor)"`,
      requireAdmin: false
    },
    colorPrevalence: {
      enable: {
        command: 'Enable Color on Taskbar',
        script: `$personalizePath = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize"
if (-not (Test-Path $personalizePath)) {
  New-Item -Path $personalizePath -Force | Out-Null
}
Set-ItemProperty -Path $personalizePath -Name "ColorPrevalence" -Value 1 -Type DWord -Force
Write-Output "SUCCESS: Color prevalence enabled"`,
        requireAdmin: false
      },
      disable: {
        command: 'Disable Color on Taskbar',
        script: `$personalizePath = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize"
if (-not (Test-Path $personalizePath)) {
  New-Item -Path $personalizePath -Force | Out-Null
}
Set-ItemProperty -Path $personalizePath -Name "ColorPrevalence" -Value 0 -Type DWord -Force
Write-Output "SUCCESS: Color prevalence disabled"`,
        requireAdmin: false
      }
    }
  },
  oldMenu: {
    contextMenu: {
      classic: {
        command: 'Enable Classic Context Menu',
        script: `$path = "HKCU:\\Software\\Classes\\CLSID\\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}"
if (-not (Test-Path $path)) {
  New-Item -Path $path -Force | Out-Null
}
$inprocPath = "$path\\InprocServer32"
if (-not (Test-Path $inprocPath)) {
  New-Item -Path $inprocPath -Force | Out-Null
}
Set-ItemProperty -Path $inprocPath -Name "(default)" -Value "" -Force
Write-Output "SUCCESS: Classic context menu enabled"`,
        requireAdmin: false
      },
      modern: {
        command: 'Enable Modern Context Menu',
        script: `$path = "HKCU:\\Software\\Classes\\CLSID\\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}"
if (Test-Path $path) {
  Remove-Item -Path $path -Recurse -Force
  Write-Output "SUCCESS: Modern context menu enabled"
} else {
  Write-Output "SUCCESS: Modern context menu already enabled"
}`,
        requireAdmin: false
      }
    },
    altTab: {
      classic: {
        command: 'Enable Classic Alt+Tab',
        script: `$path = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer"
Set-ItemProperty -Path $path -Name "AltTabSettings" -Value 1 -Type DWord -Force
Write-Output "SUCCESS: Classic Alt+Tab enabled"`,
        requireAdmin: false
      },
      modern: {
        command: 'Enable Modern Alt+Tab',
        script: `$path = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer"
$property = Get-ItemProperty -Path $path -Name "AltTabSettings" -ErrorAction SilentlyContinue
if ($property) {
  Remove-ItemProperty -Path $path -Name "AltTabSettings" -Force
  Write-Output "SUCCESS: Modern Alt+Tab enabled"
} else {
  Write-Output "SUCCESS: Modern Alt+Tab already enabled"
}`,
        requireAdmin: false
      }
    }
  },
  taskbar: {
    autoHide: {
      enable: {
        command: 'Enable Auto-Hide Taskbar',
        script: `$path = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StuckRects3"
$value = Get-ItemProperty -Path $path -Name "Settings" -ErrorAction SilentlyContinue
if ($value) {
  $settings = $value.Settings
  $settings[8] = $settings[8] -bor 0x01
  Set-ItemProperty -Path $path -Name "Settings" -Value $settings -Force
  Write-Output "SUCCESS: Auto-hide taskbar enabled"
} else {
  Write-Output "ERROR: Could not read taskbar settings"
}`,
        requireAdmin: false
      },
      disable: {
        command: 'Disable Auto-Hide Taskbar',
        script: `$path = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StuckRects3"
$value = Get-ItemProperty -Path $path -Name "Settings" -ErrorAction SilentlyContinue
if ($value) {
  $settings = $value.Settings
  $settings[8] = $settings[8] -band (-bnot 0x01)
  Set-ItemProperty -Path $path -Name "Settings" -Value $settings -Force
  Write-Output "SUCCESS: Auto-hide taskbar disabled"
} else {
  Write-Output "ERROR: Could not read taskbar settings"
}`,
        requireAdmin: false
      }
    },
    taskView: {
      enable: {
        command: 'Enable Task View Button',
        script: `$path = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced"
if (-not (Test-Path $path)) {
  New-Item -Path $path -Force | Out-Null
}
Set-ItemProperty -Path $path -Name "ShowTaskViewButton" -Value 1 -Type DWord -Force
Write-Output "SUCCESS: Task View button enabled"`,
        requireAdmin: false
      },
      disable: {
        command: 'Disable Task View Button',
        script: `$path = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced"
if (-not (Test-Path $path)) {
  New-Item -Path $path -Force | Out-Null
}
Set-ItemProperty -Path $path -Name "ShowTaskViewButton" -Value 0 -Type DWord -Force
Write-Output "SUCCESS: Task View button disabled"`,
        requireAdmin: false
      }
    },
    alignment: {
      command: 'Change Taskbar Alignment',
      script: (alignment) => {
        const alignValue = alignment === 'centre' ? 1 : 0;
        return `$path = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced"
if (-not (Test-Path $path)) {
  New-Item -Path $path -Force | Out-Null
}
Set-ItemProperty -Path $path -Name "TaskbarAl" -Value ${alignValue} -Type DWord -Force
Write-Output "SUCCESS: Taskbar alignment changed to ${alignment}"`;
      },
      requireAdmin: false
    }
  }
};
