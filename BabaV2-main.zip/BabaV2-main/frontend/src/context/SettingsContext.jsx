import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { 
  performanceSettings as initialPerformance,
  privacySettings as initialPrivacy,
  interfaceSettings as initialInterface,
  advancedSettings as initialAdvanced,
  bloatwareSettings as initialBloatware,
  saveSettingState
} from '../data/mockData';
import { readMultipleSettings } from '../utils/windowsStateReader';

const SettingsContext = createContext();

export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};

// Fonction helper pour charger les settings avec localStorage
const loadSettingsFromStorage = (defaultSettings) => {
  try {
    const saved = JSON.parse(localStorage.getItem('babatool_settings') || '{}');
    console.log('📦 Loading settings from localStorage:', Object.keys(saved).length, 'saved items');
    
    return defaultSettings.map(setting => {
      const savedValue = saved.hasOwnProperty(setting.id) ? saved[setting.id] : setting.enabled;
      if (saved.hasOwnProperty(setting.id)) {
        console.log(`  ✓ ${setting.id}: localStorage=${saved[setting.id]}, default=${setting.enabled} → using ${savedValue}`);
      }
      return {
        ...setting,
        enabled: savedValue
      };
    });
  } catch (e) {
    console.error('Error loading from localStorage:', e);
    return defaultSettings;
  }
};

export const SettingsProvider = ({ children }) => {
  // Initialiser avec localStorage dès le début
  const [performanceSettings, setPerformanceSettings] = useState(() => loadSettingsFromStorage(initialPerformance));
  const [privacySettings, setPrivacySettings] = useState(() => loadSettingsFromStorage(initialPrivacy));
  const [interfaceSettings, setInterfaceSettings] = useState(() => loadSettingsFromStorage(initialInterface));
  const [advancedSettings, setAdvancedSettings] = useState(() => loadSettingsFromStorage(initialAdvanced));
  const [bloatwareSettings, setBloatwareSettings] = useState(() => loadSettingsFromStorage(initialBloatware));
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [systemInfo, setSystemInfo] = useState(null);
  
  // Check if Electron API is available
  const isElectron = typeof window !== 'undefined' && window.electronAPI?.isElectron === true;
  
  // Toast notifications
  const [toasts, setToasts] = useState([]);

  /**
   * Charge les états réels des paramètres Windows au démarrage
   * Met à jour tous les toggles pour refléter l'état actuel du système
   * ET sauvegarde l'état réel dans localStorage pour persistance
   */
  const loadRealWindowsStates = useCallback(async () => {
    if (!window.electronAPI?.readRegistry) {
      console.log('Electron API not available, skipping Windows state loading');
      return;
    }

    try {
      console.log('Loading real Windows states...');
      
      // Collecter tous les IDs des paramètres
      const allSettingIds = [
        ...performanceSettings.map(s => s.id),
        ...privacySettings.map(s => s.id),
        ...interfaceSettings.map(s => s.id),
        ...advancedSettings.map(s => s.id)
      ];

      // Lire tous les états réels depuis Windows
      const realStates = await readMultipleSettings(allSettingIds, window.electronAPI);
      
      console.log('Real Windows states loaded:', realStates);

      // Sauvegarder TOUS les états réels dans localStorage
      // Cela garantit que les états Windows persistent entre les redémarrages
      Object.entries(realStates).forEach(([settingId, enabled]) => {
        if (enabled !== undefined) {
          try {
            const saved = JSON.parse(localStorage.getItem('babatool_settings') || '{}');
            saved[settingId] = enabled;
            localStorage.setItem('babatool_settings', JSON.stringify(saved));
          } catch (e) {
            console.error(`Error saving state for ${settingId}:`, e);
          }
        }
      });

      console.log('✅ Real Windows states saved to localStorage');

      // Mettre à jour les états des paramètres de performance
      setPerformanceSettings(prev => 
        prev.map(s => {
          if (realStates[s.id] !== undefined) {
            return { ...s, enabled: realStates[s.id] };
          }
          return s;
        })
      );

      // Mettre à jour les états des paramètres de confidentialité
      setPrivacySettings(prev => 
        prev.map(s => {
          if (realStates[s.id] !== undefined) {
            return { ...s, enabled: realStates[s.id] };
          }
          return s;
        })
      );

      // Mettre à jour les états des paramètres d'interface
      setInterfaceSettings(prev => 
        prev.map(s => {
          if (realStates[s.id] !== undefined) {
            return { ...s, enabled: realStates[s.id] };
          }
          return s;
        })
      );

      // Mettre à jour les états des paramètres avancés
      setAdvancedSettings(prev => 
        prev.map(s => {
          if (realStates[s.id] !== undefined) {
            return { ...s, enabled: realStates[s.id] };
          }
          return s;
        })
      );

      console.log('Windows states synchronized with UI');
    } catch (error) {
      console.error('Error loading Windows states:', error);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [performanceSettings, privacySettings, interfaceSettings, advancedSettings]);

  // Check admin status, get system info, and load real Windows states on mount
  useEffect(() => {
    const initialize = async () => {
      if (isElectron) {
        try {
          const admin = await window.electronAPI.checkAdmin();
          setIsAdmin(admin);
          
          // Get system info
          const info = await window.electronAPI.getSystemInfo();
          setSystemInfo(info);
          
          // Load real Windows states for all toggles
          await loadRealWindowsStates();
        } catch (e) {
          console.error('Failed to initialize:', e);
        }
      }
    };
    initialize();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isElectron]);

  // Fonction addToast définie avant son utilisation
  const addToast = useCallback((message, type = 'success', details = null) => {
    const id = Date.now();
    setToasts(prev => [...prev, { id, message, type, details }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  }, []);

  // Surveillance en temps réel du Game Mode
  useEffect(() => {
    if (!isElectron || !window.electronAPI?.onGameModeChanged) {
      return;
    }

    // Callback appelé quand le Game Mode change dans Windows
    const handleGameModeChange = (data) => {
      console.log('🎮 Game Mode changé (surveillance):', data);
      
      // Mettre à jour le paramètre game-mode dans performanceSettings
      setPerformanceSettings(prev => 
        prev.map(s => {
          if (s.id === 'game-mode') {
            console.log(`Mise à jour Game Mode: ${s.enabled} → ${data.enabled}`);
            return { ...s, enabled: data.enabled };
          }
          return s;
        })
      );

      // Optionnel : afficher une notification
      addToast(
        `Mode Jeu Windows ${data.enabled ? 'activé' : 'désactivé'}`,
        'info',
        'Changement détecté automatiquement'
      );
    };

    // Enregistrer l'écouteur
    window.electronAPI.onGameModeChanged(handleGameModeChange);

    // Nettoyage au démontage
    return () => {
      if (window.electronAPI?.removeGameModeListener) {
        window.electronAPI.removeGameModeListener();
      }
    };
  }, [isElectron, addToast]);

  // Execute PowerShell commands
  const executeCommands = async (commands, settingTitle, isEnabling) => {
    const action = isEnabling ? 'activé' : 'désactivé';
    
    // No commands to execute
    if (!commands?.powershell?.length) {
      addToast(`${settingTitle} ${action}`, 'success');
      return true;
    }

    // Check if running in Electron
    if (!isElectron) {
      // Fallback: copy to clipboard for manual execution
      const allScripts = commands.powershell.map(cmd => cmd.script).join('\n');
      try {
        await navigator.clipboard.writeText(allScripts);
        addToast(`${settingTitle} ${action}`, 'success', 'Commandes copiées (mode web)');
      } catch (e) {
        addToast(`${settingTitle} ${action}`, 'success');
      }
      return true;
    }

    // Execute in Electron
    const requiresAdmin = commands.powershell.some(cmd => cmd.requireAdmin);
    
    if (requiresAdmin && !isAdmin) {
      addToast('Privilèges admin requis', 'warning', 'Cliquez sur "Exécuter en Admin"');
      return false;
    }

    setIsLoading(true);
    
    try {
      const results = await window.electronAPI.executePowerShell(commands.powershell);
      
      const successCount = results.filter(r => r.success).length;
      const totalCount = results.length;
      
      if (successCount === totalCount) {
        addToast(`${settingTitle} ${action}`, 'success', `${totalCount} commande(s) exécutée(s)`);
        return true;
      } else if (successCount > 0) {
        addToast(`${settingTitle} - Partiel`, 'warning', `${successCount}/${totalCount} commande(s) OK`);
        return true;
      } else {
        const firstError = results.find(r => !r.success)?.error || 'Erreur inconnue';
        addToast(`Erreur: ${settingTitle}`, 'error', firstError);
        return false;
      }
    } catch (error) {
      addToast('Erreur d\'exécution', 'error', error.message);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const togglePerformance = async (id) => {
    const setting = performanceSettings.find(s => s.id === id);
    if (!setting) return;
    
    const newEnabled = !setting.enabled;
    const commands = newEnabled ? setting.enableCommands : setting.disableCommands;
    
    // Update UI immediately
    setPerformanceSettings(prev => 
      prev.map(s => s.id === id ? { ...s, enabled: newEnabled } : s)
    );
    
    // Save to localStorage
    saveSettingState(id, newEnabled);
    console.log(`💾 Saved ${id} = ${newEnabled} to localStorage`);
    
    // Execute commands
    const success = await executeCommands(commands, setting.title, newEnabled);
    
    // Revert if failed in Electron mode
    if (!success && isElectron) {
      setPerformanceSettings(prev => 
        prev.map(s => s.id === id ? { ...s, enabled: !newEnabled } : s)
      );
      saveSettingState(id, !newEnabled);
    }
  };

  const togglePrivacy = async (id) => {
    const setting = privacySettings.find(s => s.id === id);
    if (!setting) return;
    
    const newEnabled = !setting.enabled;
    const commands = newEnabled ? setting.enableCommands : setting.disableCommands;
    
    setPrivacySettings(prev => 
      prev.map(s => s.id === id ? { ...s, enabled: newEnabled } : s)
    );
    
    // Save to localStorage
    saveSettingState(id, newEnabled);
    console.log(`💾 Privacy: Saved ${id} = ${newEnabled} to localStorage`);
    
    const success = await executeCommands(commands, setting.title, newEnabled);
    
    if (!success && isElectron) {
      setPrivacySettings(prev => 
        prev.map(s => s.id === id ? { ...s, enabled: !newEnabled } : s)
      );
      saveSettingState(id, !newEnabled);
    }
  };

  const toggleInterface = async (id) => {
    const setting = interfaceSettings.find(s => s.id === id);
    if (!setting) return;
    
    const newEnabled = !setting.enabled;
    const commands = newEnabled ? setting.enableCommands : setting.disableCommands;
    
    setInterfaceSettings(prev => 
      prev.map(s => s.id === id ? { ...s, enabled: newEnabled } : s)
    );
    
    // Save to localStorage
    saveSettingState(id, newEnabled);
    
    const success = await executeCommands(commands, setting.title, newEnabled);
    
    if (!success && isElectron) {
      setInterfaceSettings(prev => 
        prev.map(s => s.id === id ? { ...s, enabled: !newEnabled } : s)
      );
      saveSettingState(id, !newEnabled);
    }
  };

  const toggleAdvanced = async (id) => {
    const setting = advancedSettings.find(s => s.id === id);
    if (!setting) return;
    
    const newEnabled = !setting.enabled;
    const commands = newEnabled ? setting.enableCommands : setting.disableCommands;
    
    setAdvancedSettings(prev => 
      prev.map(s => s.id === id ? { ...s, enabled: newEnabled } : s)
    );
    
    // Save to localStorage
    saveSettingState(id, newEnabled);
    
    const success = await executeCommands(commands, setting.title, newEnabled);
    
    if (!success && isElectron) {
      setAdvancedSettings(prev => 
        prev.map(s => s.id === id ? { ...s, enabled: !newEnabled } : s)
      );
      saveSettingState(id, !newEnabled);
    }
  };

  const toggleBloatware = async (id) => {
    const setting = bloatwareSettings.find(s => s.id === id);
    if (!setting) return;
    
    const newEnabled = !setting.enabled;
    const commands = newEnabled ? setting.enableCommands : setting.disableCommands;
    
    setBloatwareSettings(prev => 
      prev.map(s => s.id === id ? { ...s, enabled: newEnabled } : s)
    );
    
    // Save to localStorage
    saveSettingState(id, newEnabled);
    
    const success = await executeCommands(commands, setting.title, newEnabled);
    
    if (!success && isElectron) {
      setBloatwareSettings(prev => 
        prev.map(s => s.id === id ? { ...s, enabled: !newEnabled } : s)
      );
      saveSettingState(id, !newEnabled);
    }
  };

  const restartAsAdmin = async () => {
    if (isElectron) {
      try {
        await window.electronAPI.restartAsAdmin();
      } catch (e) {
        addToast('Erreur', 'error', 'Impossible de redémarrer en admin');
      }
    }
  };

  const openExternal = async (url) => {
    if (isElectron) {
      await window.electronAPI.openExternal(url);
    } else {
      window.open(url, '_blank');
    }
  };

  const value = {
    performanceSettings,
    privacySettings,
    interfaceSettings,
    advancedSettings,
    bloatwareSettings,
    setPerformanceSettings,
    setPrivacySettings,
    setInterfaceSettings,
    setAdvancedSettings,
    setBloatwareSettings,
    togglePerformance,
    togglePrivacy,
    toggleInterface,
    toggleAdvanced,
    toggleBloatware,
    addToast,
    toasts,
    isAdmin,
    isElectron,
    isLoading,
    systemInfo,
    restartAsAdmin,
    openExternal
  };

  return (
    <SettingsContext.Provider value={value}>
      {children}
    </SettingsContext.Provider>
  );
};

export default SettingsContext;
