# Script pour appliquer le .nip et fermer NPI automatiquement
$ErrorActionPreference = 'SilentlyContinue'
$ProgressPreference = 'SilentlyContinue'

# URLs
$NpiUrl = "https://github.com/Baba75020/NIP/releases/download/V1/nvidiaProfileInspector.exe"
$ProfileUrl = "https://github.com/Baba75020/NIP/releases/download/V1/Final.nip"

# Chemins
$TempDir = "$env:TEMP\NVIDIA_Setup"
$NpiPath = "$TempDir\nvidiaProfileInspector.exe"
$ProfilePath = "$TempDir\Final.nip"

# Creer le dossier temporaire
if (-not (Test-Path $TempDir)) {
    New-Item -ItemType Directory -Path $TempDir -Force | Out-Null
}

# Telecharger les fichiers
try {
    # Telecharger NPI
    Write-Host "Telechargement de NVIDIA Profile Inspector..."
    (New-Object System.Net.WebClient).DownloadFile($NpiUrl, $NpiPath)

    # Telecharger le profil
    Write-Host "Telechargement du profil Final.nip..."
    (New-Object System.Net.WebClient).DownloadFile($ProfileUrl, $ProfilePath)
}
catch {
    Write-Host "Erreur de telechargement"
    exit 1
}

# Appliquer le profil et fermer NPI
if (Test-Path $NpiPath) {
    try {
        # Demarrer NPI en arriere-plan pour appliquer le profil
        Write-Host "Application du profil..."
        $process = Start-Process -FilePath $NpiPath -ArgumentList "-import `"$ProfilePath`"" -PassThru

        # Attendre que le processus se termine (fermeture automatique apres import)
        $process.WaitForExit(10000)  # Timeout de 10 secondes

        Write-Host "[SUCCESS] Profil applique avec succes"

        # Forcer la fermeture si toujours ouvert
        Get-Process -Name "nvidiaProfileInspector" -ErrorAction SilentlyContinue | Stop-Process -Force

        # Nettoyer les fichiers temporaires
        Remove-Item $TempDir -Recurse -Force -ErrorAction SilentlyContinue
    }
    catch {
        Write-Host "Erreur lors de l'application"
        exit 1
    }
}
