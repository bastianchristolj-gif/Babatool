# Script Fortnite - Modifie uniquement les parametres existants
param(
    # Mode API/Graphique
    [Parameter(Mandatory=$false)]
    [ValidateSet("DX11", "DX12", "Performance", "OldPerformance")]
    [string]$GraphicsAPI,

    # Qualite des textures
    [Parameter(Mandatory=$false)]
    [ValidateSet("Low", "Medium", "High", "Epic")]
    [string]$Textures,

    # Distance d'affichage
    [Parameter(Mandatory=$false)]
    [ValidateSet("Low", "Medium", "High", "Epic")]
    [string]$ViewDistance,

    # Resolution
    [Parameter(Mandatory=$false)]
    [int]$ResolutionX,

    [Parameter(Mandatory=$false)]
    [int]$ResolutionY,

    # Limite FPS
    [Parameter(Mandatory=$false)]
    [int]$FPSLimit,

    # Identifier tous les parametres
    [switch]$IdentifySettings,

    # Forcer l'acces (admin)
    [switch]$Force
)

# Chemin du fichier
$configPath = "$env:LOCALAPPDATA\FortniteGame\Saved\Config\WindowsClient\GameUserSettings.ini"

# Verifier l'acces
function Test-Access {
    if (-not (Test-Path $configPath)) {
        Write-Host "Fichier non trouve : $configPath" -ForegroundColor Red
        return $false
    }

    try {
        Test-Path $configPath -ErrorAction Stop
        return $true
    }
    catch {
        if ($Force) {
            Write-Host "Tentative de reparation..." -ForegroundColor Yellow
            try {
                Start-Process "takeown" -ArgumentList "/f `"$configPath`"" -Wait -NoNewWindow
                Start-Process "icacls" -ArgumentList "`"$configPath`" /grant `"$env:USERNAME`:F`"" -Wait -NoNewWindow
                return $true
            }
            catch {
                Write-Host "Echec de reparation" -ForegroundColor Red
                return $false
            }
        }
        else {
            Write-Host "Acces refuse. Utilisez -Force" -ForegroundColor Red
            return $false
        }
    }
}

# Identifier TOUS les parametres du fichier (format JSON pour l'app)
function Identify-All-Settings {
    if (-not (Test-Path $configPath)) {
        Write-Host '{"error": "Fichier non trouve"}' 
        return
    }

    $content = Get-Content $configPath
    $settings = @{}
    $currentSection = ""

    foreach ($line in $content) {
        # Detecter une section
        if ($line -match "^\[(.+)\]$") {
            $currentSection = $matches[1]
            continue
        }

        # Detecter un parametre (cle=valeur)
        if ($line -match "^([^=]+)=(.+)$") {
            $key = $matches[1].Trim()
            $value = $matches[2].Trim()
            $settings[$key] = $value
        }
    }

    # Extraire les parametres importants pour l'affichage
    $result = @{
        graphicsAPI = if ($settings["bPreferD3D12InGame"] -eq "1") { "DX12" } else { "DX11" }
        resolutionX = [int]$settings["ResolutionSizeX"]
        resolutionY = [int]$settings["ResolutionSizeY"]
        frameRateLimit = [int]$settings["FrameRateLimit"]
        textures = [int]$settings["sg.TextureQuality"]
        viewDistance = [int]$settings["sg.ViewDistanceQuality"]
        shadows = [int]$settings["sg.ShadowQuality"]
        antiAliasing = [int]$settings["sg.AntiAliasingQuality"]
        effects = [int]$settings["sg.EffectsQuality"]
        postProcess = [int]$settings["sg.PostProcessQuality"]
        overallQuality = [int]$settings["OverallQuality"]
        fullscreen = [int]$settings["FullscreenMode"]
    }

    # Sortie JSON pour l'application
    Write-Host "JSON_START"
    $result | ConvertTo-Json -Compress
    Write-Host "JSON_END"
}

# Modifier un parametre existant
function Update-Setting {
    param($key, $value)

    if (-not (Test-Path $configPath)) {
        Write-Host "Fichier non trouve" -ForegroundColor Red
        return $false
    }

    $content = Get-Content $configPath
    $modified = $false
    $newContent = @()

    foreach ($line in $content) {
        if ($line -match "^$key=") {
            $newContent += "$key=$value"
            $modified = $true
            Write-Host "  [OK] $key = $value" -ForegroundColor Green
        }
        else {
            $newContent += $line
        }
    }

    if ($modified) {
        $newContent | Out-File $configPath -Encoding UTF8 -Force
        return $true
    }
    else {
        Write-Host "  [SKIP] $key non trouve" -ForegroundColor Yellow
        return $false
    }
}

# Table de conversion
$qualityMap = @{
    "Low" = 0
    "Medium" = 1
    "High" = 2
    "Epic" = 3
}

# Point d'entree
try {
    # Identifier TOUS les parametres (mode JSON)
    if ($IdentifySettings) {
        Identify-All-Settings
        return
    }

    Write-Host "`nCONFIGURATION FORTNITE" -ForegroundColor Cyan
    Write-Host "--------------------------" -ForegroundColor DarkCyan

    # Verifier l'acces
    if (-not (Test-Access)) {
        return
    }

    # Verifier qu'au moins un parametre est specifie
    $hasParams = $false
    if ($GraphicsAPI) { $hasParams = $true }
    if ($Textures) { $hasParams = $true }
    if ($ViewDistance) { $hasParams = $true }
    if ($ResolutionX -or $ResolutionY) { $hasParams = $true }
    if ($FPSLimit) { $hasParams = $true }

    if (-not $hasParams) {
        Write-Host "`nUTILISATION :" -ForegroundColor Yellow
        Write-Host "  .\Fotnite.ps1 -IdentifySettings" -ForegroundColor Gray
        Write-Host "  .\Fotnite.ps1 -GraphicsAPI Performance -FPSLimit 240" -ForegroundColor Gray
        Write-Host "  .\Fotnite.ps1 -Textures Low -ViewDistance Low -Force" -ForegroundColor Gray
        return
    }

    Write-Host "`nModification des parametres :" -ForegroundColor Cyan

    # API Graphique
    if ($GraphicsAPI) {
        switch ($GraphicsAPI) {
            "DX11" {
                Update-Setting -key "bPreferD3D12InGame" -value "0"
                Update-Setting -key "OverallQuality" -value "3"
            }
            "DX12" {
                Update-Setting -key "bPreferD3D12InGame" -value "1"
                Update-Setting -key "OverallQuality" -value "3"
            }
            "Performance" {
                Update-Setting -key "bPreferD3D12InGame" -value "0"
                Update-Setting -key "OverallQuality" -value "0"
                Update-Setting -key "sg.ShadowQuality" -value "0"
                Update-Setting -key "sg.AntiAliasingQuality" -value "0"
                Update-Setting -key "sg.PostProcessQuality" -value "0"
                Update-Setting -key "sg.EffectsQuality" -value "0"
            }
            "OldPerformance" {
                Update-Setting -key "bPreferD3D12InGame" -value "0"
                Update-Setting -key "OverallQuality" -value "0"
                Update-Setting -key "sg.ShadowQuality" -value "0"
                Update-Setting -key "sg.AntiAliasingQuality" -value "0"
                Update-Setting -key "sg.PostProcessQuality" -value "0"
                Update-Setting -key "sg.EffectsQuality" -value "0"
                Update-Setting -key "sg.GlobalIlluminationQuality" -value "0"
                Update-Setting -key "sg.ReflectionQuality" -value "0"
            }
        }
    }

    # Textures
    if ($Textures) {
        $value = $qualityMap[$Textures]
        Update-Setting -key "sg.TextureQuality" -value $value
    }

    # Distance d'affichage
    if ($ViewDistance) {
        $value = $qualityMap[$ViewDistance]
        Update-Setting -key "sg.ViewDistanceQuality" -value $value
    }

    # Resolution
    if ($ResolutionX) {
        Update-Setting -key "ResolutionSizeX" -value $ResolutionX
        Update-Setting -key "LastUserConfirmedResolutionSizeX" -value $ResolutionX
    }
    if ($ResolutionY) {
        Update-Setting -key "ResolutionSizeY" -value $ResolutionY
        Update-Setting -key "LastUserConfirmedResolutionSizeY" -value $ResolutionY
    }

    # FPS Limit
    if ($FPSLimit) {
        Update-Setting -key "FrameRateLimit" -value $FPSLimit
    }

    Write-Host "`n[SUCCESS] Modification terminee !" -ForegroundColor Green
    Write-Host "Redemarrez Fortnite pour appliquer les changements." -ForegroundColor Yellow

}
catch {
    Write-Host "`n[ERROR] Erreur : $_" -ForegroundColor Red
}
