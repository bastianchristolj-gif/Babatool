import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

import fr from './locales/fr.json';
import en from './locales/en.json';

const resources = {
  fr: { translation: fr },
  en: { translation: en }
};

// Get saved language from localStorage or default to 'fr'
const savedLanguage = localStorage.getItem('babatool_language') || 'fr';

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    lng: savedLanguage,
    fallbackLng: 'fr',
    
    detection: {
      order: ['localStorage', 'navigator'],
      lookupLocalStorage: 'babatool_language',
      caches: ['localStorage']
    },
    
    interpolation: {
      escapeValue: false // React already escapes values
    },
    
    react: {
      useSuspense: false
    }
  });

// Function to change language and persist it
export const changeLanguage = (lang) => {
  localStorage.setItem('babatool_language', lang);
  i18n.changeLanguage(lang);
};

export default i18n;
