import React from 'react';
import { CheckCircle2, XCircle, Terminal, AlertTriangle } from 'lucide-react';

const ToastNotifications = ({ toasts }) => {
  if (!toasts.length) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 space-y-3">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className={`
            flex items-center gap-3 px-4 py-3 rounded-xl shadow-2xl backdrop-blur-xl min-w-[280px]
            animate-in slide-in-from-right-5 fade-in duration-300
            ${toast.type === 'success' 
              ? 'bg-emerald-500/20 border border-emerald-500/30' 
              : toast.type === 'warning'
              ? 'bg-amber-500/20 border border-amber-500/30'
              : 'bg-red-500/20 border border-red-500/30'
            }
          `}
        >
          <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${
            toast.type === 'success' ? 'bg-emerald-500/20' : 
            toast.type === 'warning' ? 'bg-amber-500/20' : 'bg-red-500/20'
          }`}>
            {toast.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            ) : toast.type === 'warning' ? (
              <AlertTriangle className="w-5 h-5 text-amber-400" />
            ) : (
              <XCircle className="w-5 h-5 text-red-400" />
            )}
          </div>
          <div className="flex flex-col flex-1 min-w-0">
            <span className="text-sm font-semibold text-white truncate">{toast.message}</span>
            {toast.details && (
              <span className="text-xs text-[#888] truncate">{toast.details}</span>
            )}
          </div>
          <Terminal className="w-4 h-4 text-[#555] flex-shrink-0" />
        </div>
      ))}
    </div>
  );
};

export default ToastNotifications;
