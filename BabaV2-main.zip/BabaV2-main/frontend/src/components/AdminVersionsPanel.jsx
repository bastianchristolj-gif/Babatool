import React, { useState, useEffect } from 'react';
import { callEdgeFunction } from '../lib/supabase';
import { APP_TYPE } from '../lib/version';

const AdminVersionsPanel = () => {
  const [versions, setVersions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [error, setError] = useState(null);

  const fetchVersions = async () => {
    setLoading(true);
    try {
      const result = await callEdgeFunction('admin-operations', { action: 'get_versions' });
      if (result.success) {
        setVersions(result.versions || []);
      } else {
        setError(result.error);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVersions();
  }, []);

  const handleCreateVersion = async (formData) => {
    try {
      const result = await callEdgeFunction('admin-operations', {
        action: 'create_version',
        ...formData,
        app_type: APP_TYPE
      });
      if (result.success) {
        setShowCreateModal(false);
        fetchVersions();
      } else {
        alert('Erreur: ' + result.error);
      }
    } catch (err) {
      alert('Erreur: ' + err.message);
    }
  };

  const handleSetLatest = async (versionId) => {
    try {
      const result = await callEdgeFunction('admin-operations', {
        action: 'set_latest_version',
        version_id: versionId,
        app_type: APP_TYPE
      });
      if (result.success) {
        fetchVersions();
      } else {
        alert('Erreur: ' + result.error);
      }
    } catch (err) {
      alert('Erreur: ' + err.message);
    }
  };

  const handleDelete = async (versionId) => {
    if (!window.confirm('Supprimer cette version ?')) return;
    
    try {
      const result = await callEdgeFunction('admin-operations', {
        action: 'delete_version',
        version_id: versionId
      });
      if (result.success) {
        fetchVersions();
      } else {
        alert('Erreur: ' + result.error);
      }
    } catch (err) {
      alert('Erreur: ' + err.message);
    }
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="text-gray-500">Chargement des versions...</div>
      </div>
    );
  }

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white">Versions</h1>
          <p className="text-gray-500 text-sm mt-1">Gérer les mises à jour de l'application</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="px-5 py-2.5 bg-[#ff3333] hover:bg-[#cc0000] rounded-lg font-medium transition flex items-center gap-2"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          Nouvelle Version
        </button>
      </div>

      {error && (
        <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 mb-6">
          <p className="text-red-400">{error}</p>
        </div>
      )}

      {/* Table des versions */}
      <div className="bg-[#111] border border-gray-800 rounded-xl overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-800">
              <th className="text-left py-4 px-6 text-gray-500 font-normal text-sm">Version</th>
              <th className="text-left py-4 px-6 text-gray-500 font-normal text-sm">Status</th>
              <th className="text-left py-4 px-6 text-gray-500 font-normal text-sm">Notes</th>
              <th className="text-left py-4 px-6 text-gray-500 font-normal text-sm">Date</th>
              <th className="text-left py-4 px-6 text-gray-500 font-normal text-sm">Actions</th>
            </tr>
          </thead>
          <tbody>
            {versions.length === 0 ? (
              <tr>
                <td colSpan="5" className="py-16 text-center text-gray-600">
                  Aucune version publiée
                </td>
              </tr>
            ) : (
              versions.map((v) => (
                <tr key={v.id} className="border-b border-gray-800/50 hover:bg-white/[0.02] transition">
                  <td className="py-4 px-6">
                    <span className="text-white font-mono text-lg">{v.version}</span>
                  </td>
                  <td className="py-4 px-6">
                    {v.is_latest ? (
                      <span className="px-3 py-1 bg-green-500/20 border border-green-500/30 text-green-400 rounded text-xs font-bold uppercase">
                        ACTUELLE
                      </span>
                    ) : (
                      <span className="px-3 py-1 bg-gray-500/20 border border-gray-500/30 text-gray-400 rounded text-xs font-bold uppercase">
                        ARCHIVE
                      </span>
                    )}
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-gray-400 text-sm truncate block max-w-xs" title={v.patch_notes}>
                      {v.patch_notes ? v.patch_notes.substring(0, 50) + (v.patch_notes.length > 50 ? '...' : '') : '-'}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-gray-400 text-sm">
                      {new Date(v.release_date || v.created_at).toLocaleDateString('fr-FR')}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-2">
                      {!v.is_latest && (
                        <button
                          onClick={() => handleSetLatest(v.id)}
                          className="px-3 py-1.5 bg-red-500/20 hover:bg-red-500/30 text-blue-400 rounded text-xs font-medium transition"
                        >
                          Définir actuelle
                        </button>
                      )}
                      <button
                        onClick={() => handleDelete(v.id)}
                        className="px-3 py-1.5 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded text-xs font-medium transition"
                      >
                        Supprimer
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Modal création */}
      {showCreateModal && (
        <CreateVersionModal 
          onClose={() => setShowCreateModal(false)}
          onCreate={handleCreateVersion}
        />
      )}
    </div>
  );
};

// Modal pour créer une version
const CreateVersionModal = ({ onClose, onCreate }) => {
  const [version, setVersion] = useState('');
  const [downloadUrl, setDownloadUrl] = useState('');
  const [patchNotes, setPatchNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!version || !downloadUrl) {
      alert('Version et URL sont requis');
      return;
    }
    setSubmitting(true);
    await onCreate({ version, download_url: downloadUrl, patch_notes: patchNotes });
    setSubmitting(false);
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
      <div className="bg-[#111] border border-gray-800 rounded-xl p-8 w-full max-w-lg">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white">Nouvelle Version</h2>
            <p className="text-gray-500 text-sm mt-1">Publier une mise à jour</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition p-1">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-gray-400 text-sm mb-2">Version *</label>
            <input
              type="text"
              value={version}
              onChange={(e) => setVersion(e.target.value)}
              placeholder="1.1.0"
              className="w-full bg-[#0a0a0a] border border-gray-800 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-gray-600 transition font-mono"
              required
            />
          </div>

          <div>
            <label className="block text-gray-400 text-sm mb-2">URL de téléchargement *</label>
            <input
              type="url"
              value={downloadUrl}
              onChange={(e) => setDownloadUrl(e.target.value)}
              placeholder="https://github.com/user/repo/releases/download/v1.1.0/App-Setup-1.1.0.exe"
              className="w-full bg-[#0a0a0a] border border-gray-800 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-gray-600 transition text-sm"
              required
            />
            <p className="text-gray-600 text-xs mt-1">URL directe vers le .exe sur GitHub Releases</p>
          </div>

          <div>
            <label className="block text-gray-400 text-sm mb-2">Notes de mise à jour</label>
            <textarea
              value={patchNotes}
              onChange={(e) => setPatchNotes(e.target.value)}
              placeholder="- Nouvelle fonctionnalité X\n- Correction du bug Y\n- Amélioration des performances"
              className="w-full bg-[#0a0a0a] border border-gray-800 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-gray-600 transition resize-none"
              rows="4"
            />
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 text-gray-400 hover:text-white border border-gray-800 rounded-lg transition"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="flex-1 px-4 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium transition disabled:opacity-50"
            >
              {submitting ? 'Publication...' : 'Publier'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AdminVersionsPanel;
