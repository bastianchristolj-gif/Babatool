import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { changeLanguage } from '../i18n';
import { 
  Home, 
  Gauge, 
  Shield, 
  Palette, 
  HardDrive, 
  Trash2,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Zap,
  Download,
  RefreshCw,
  Globe,
  Rocket,
  Code,
  Sliders,
  Film,
  Package
} from 'lucide-react';

// Drapeaux avec images
const languages = [
  { code: 'fr', name: 'Français', flag: '/flags/fr.webp' },
  { code: 'en', name: 'English', flag: '/flags/en.jpg' },
];

const Sidebar = ({ activeSection, setActiveSection, isCollapsed, setIsCollapsed }) => {
  const { t, i18n } = useTranslation();
  
  const navItems = [
    { id: 'home', labelKey: 'nav.home', icon: Home, section: 'General' },
    { id: 'performance', labelKey: 'nav.performance', icon: Gauge, section: 'Main' },
    { id: 'privacy', labelKey: 'nav.privacy', icon: Shield, section: 'Main' },
    { id: 'interface', labelKey: 'nav.interface', icon: Palette, section: 'Main' },
    { id: 'bloatware', labelKey: 'nav.debloat', icon: Trash2, section: 'Main' },
    { id: 'clean', labelKey: 'nav.clean', icon: '🧹', emoji: true, section: 'Main' },
    { id: 'software', labelKey: 'nav.software', icon: Package, section: 'Main' },
    { id: 'updates', labelKey: 'nav.updates', icon: Download, section: 'System' },
    { id: 'drivers', labelKey: 'nav.hardware', icon: HardDrive, section: 'Hardware' },
  ];

  const sections = ['General', 'Main', 'System', 'Hardware'];
  const sectionLabelKeys = {
    'General': 'sidebar.general',
    'Main': 'sidebar.main',
    'System': 'sidebar.system',
    'Hardware': 'sidebar.hardware'
  };
  const [licenseType, setLicenseType] = useState('Utilisateur');
  const [selectedLang, setSelectedLang] = useState(i18n.language || 'fr');
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);
  const [refreshingLicense, setRefreshingLicense] = useState(false);
  const [softwareMenuOpen, setSoftwareMenuOpen] = useState(false);
  
  // Function to refresh license from server
  const refreshLicense = async () => {
    setRefreshingLicense(true);
    try {
      const validatedLicense = localStorage.getItem('validated_license');
      if (!validatedLicense) {
        console.log('No license to refresh');
        setRefreshingLicense(false);
        return;
      }

      const license = JSON.parse(validatedLicense);
      const hwid = localStorage.getItem('device_hwid');
      
      if (!hwid || !license.license_key) {
        console.log('Missing HWID or license key');
        setRefreshingLicense(false);
        return;
      }

      console.log('=== REFRESHING LICENSE ===');
      console.log('License Key:', license.license_key);
      console.log('HWID:', hwid);

      let responseData;

      // Use Electron proxy if available
      if (window.electronAPI?.apiRequest) {
        console.log('Using Electron proxy to refresh license');
        const result = await window.electronAPI.apiRequest(
          'POST',
          '/api/license/validate',
          {
            license_key: license.license_key,
            hwid: hwid
          }
        );

        if (!result.success || result.status !== 200) {
          throw new Error(result.error || 'Erreur du proxy Electron');
        }

        responseData = result.data;
      } else {
        // Fallback: direct axios request
        const axios = require('axios');
        const BACKEND_URL = process.env.REACT_APP_BACKEND_URL || '';
        console.log('Using axios to refresh license. Backend:', BACKEND_URL);
        
        const response = await axios.post(
          `${BACKEND_URL}/api/license/validate`,
          {
            license_key: license.license_key,
            hwid: hwid
          },
          {
            timeout: 15000,
            headers: {
              'Content-Type': 'application/json'
            }
          }
        );

        responseData = response.data;
      }

      console.log('License refresh response:', responseData);

      if (responseData.valid) {
        // Update license data from server
        localStorage.setItem('validated_license', JSON.stringify(responseData.license));
        localStorage.setItem('babatool_license', JSON.stringify({
          plan: responseData.license.plan,
          pseudo: responseData.license.pseudo,
          status: responseData.license.status
        }));
        
        // Trigger update event
        window.dispatchEvent(new Event('license-updated'));
        
        // Reload license info immediately
        loadLicenseInfo();
        
        console.log('License refreshed successfully');
      } else {
        console.log('License invalid:', responseData.message);
      }
    } catch (err) {
      console.error('Error refreshing license:', err);
    } finally {
      setRefreshingLicense(false);
    }
  };
  
  // Function to load license from localStorage
  const loadLicenseInfo = () => {
    // Try babatool_license first, then validated_license as fallback
    let storedLicense = localStorage.getItem('babatool_license');
    
    if (!storedLicense) {
      storedLicense = localStorage.getItem('validated_license');
      console.log('Trying fallback: validated_license'); // Debug log
    }
    
    if (storedLicense) {
      try {
        const licenseData = JSON.parse(storedLicense);
        console.log('License data loaded:', licenseData); // Debug log
        
        // Check for plan in different possible keys
        const plan = licenseData.plan || licenseData.type || licenseData.license_type;
        
        if (plan) {
          const planLabels = {
            'lifetime': 'Lifetime',
            'standard': 'Standard',
            'trial': 'Trial',
            'premium': 'Premium'
          };
          const displayType = planLabels[plan.toLowerCase()] || plan;
          console.log('Setting license type to:', displayType); // Debug log
          setLicenseType(displayType);
        } else {
          console.log('No plan found in license data'); // Debug log
          setLicenseType('Utilisateur');
        }
      } catch (e) {
        console.error('Error parsing license:', e);
        setLicenseType('Utilisateur');
      }
    } else {
      console.log('No license found in localStorage'); // Debug log
      setLicenseType('Utilisateur');
    }
  };

  useEffect(() => {
    // Load license info on mount
    loadLicenseInfo();
    
    // Listen for license updates
    const handleLicenseUpdate = () => {
      console.log('License update event received'); // Debug log
      loadLicenseInfo();
    };
    window.addEventListener('license-updated', handleLicenseUpdate);
    
    // Quick polling at startup (every 500ms for first 5 seconds)
    let quickCount = 0;
    const quickInterval = setInterval(() => {
      loadLicenseInfo();
      quickCount++;
      if (quickCount >= 10) {
        clearInterval(quickInterval);
      }
    }, 500);
    
    // Regular polling: check localStorage every 1 second after startup
    const regularInterval = setInterval(() => {
      loadLicenseInfo();
    }, 1000);
    
    // Auto-refresh license from server every 30 minutes
    const autoRefreshInterval = setInterval(() => {
      console.log('Auto-refreshing license from server...');
      refreshLicense();
    }, 30 * 60 * 1000); // 30 minutes
    
    return () => {
      window.removeEventListener('license-updated', handleLicenseUpdate);
      clearInterval(quickInterval);
      clearInterval(regularInterval);
      clearInterval(autoRefreshInterval);
    };
  }, []);

  const handleLanguageChange = (langCode) => {
    setSelectedLang(langCode);
    changeLanguage(langCode); // Use i18n changeLanguage
    setLangDropdownOpen(false);
    // Dispatch event for other components to update
    window.dispatchEvent(new CustomEvent('language-changed', { detail: { lang: langCode } }));
  };

  const currentLang = languages.find(l => l.code === selectedLang) || languages[0];
  
  return (
    <div 
      className={`h-full flex flex-col transition-all duration-300 ease-out ${
        isCollapsed ? 'w-[72px]' : 'w-[260px]'
      }`}
      style={{ background: '#0c0c0c' }}
    >
      {/* Logo Area */}
      <div className={`p-4 ${isCollapsed ? 'px-3' : ''}`}>
        <div className={`flex items-center gap-3 ${isCollapsed ? 'justify-center' : ''}`}>
          <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 overflow-hidden" style={{ background: '#161616', border: '1px solid #1e1e1e' }}>
            <img src={process.env.PUBLIC_URL + "/logo.png"} alt="BaBaTool" className="w-7 h-7 object-contain" />
          </div>
          {!isCollapsed && (
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="text-white font-bold text-sm tracking-wide">BABATOOL</span>
                {/* Language Dropdown - avec images */}
                <div className="relative">
                  <button
                    onClick={() => setLangDropdownOpen(!langDropdownOpen)}
                    className="flex items-center gap-1.5 px-2 py-1 rounded-md hover:bg-white/5 transition-colors"
                    data-testid="lang-dropdown-btn"
                  >
                    <img 
                      src={process.env.PUBLIC_URL + currentLang.flag} 
                      alt={currentLang.name}
                      className="w-5 h-4 object-cover rounded-sm"
                    />
                    <ChevronDown className={`w-3 h-3 text-[#666] transition-transform ${langDropdownOpen ? 'rotate-180' : ''}`} />
                  </button>
                  
                  {langDropdownOpen && (
                    <div 
                      className="absolute right-0 top-full mt-1 py-1 rounded-lg shadow-xl z-50 min-w-[120px]"
                      style={{ background: '#161616', border: '1px solid #2a2a2a' }}
                    >
                      {languages.map(lang => (
                        <button
                          key={lang.code}
                          onClick={() => handleLanguageChange(lang.code)}
                          data-testid={`lang-${lang.code}`}
                          className={`w-full flex items-center gap-3 px-3 py-2 hover:bg-white/10 transition-colors ${
                            selectedLang === lang.code ? 'bg-[#ff3333]/10' : ''
                          }`}
                        >
                          <img 
                            src={process.env.PUBLIC_URL + lang.flag} 
                            alt={lang.name}
                            className="w-6 h-4 object-cover rounded-sm"
                          />
                          <span className={`text-sm ${selectedLang === lang.code ? 'text-[#ff3333]' : 'text-white'}`}>
                            {lang.name}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              <span className="text-[#444] text-[10px] tracking-widest font-medium">TWEAKS</span>
            </div>
          )}
        </div>
        
        {/* License Badge */}
        {!isCollapsed && (
          <div className="flex items-center justify-between gap-2 mt-3 px-1">
            <div className="flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-[#ff3333]" />
              <span className="text-[#ff3333] text-xs font-medium">{licenseType}</span>
            </div>
            <button
              onClick={refreshLicense}
              disabled={refreshingLicense}
              className="p-1 hover:bg-white/5 rounded transition-colors disabled:opacity-50"
              title="Rafraîchir la licence"
            >
              <RefreshCw className={`w-3 h-3 text-[#666] hover:text-[#ff3333] transition-colors ${refreshingLicense ? 'animate-spin' : ''}`} />
            </button>
          </div>
        )}
      </div>

      {/* Divider */}
      <div className="mx-3 h-px" style={{ background: '#1a1a1a' }} />

      {/* Navigation */}
      <nav className="flex-1 py-3 overflow-y-auto">
        {sections.map((section, sectionIndex) => (
          <div key={section} className={sectionIndex > 0 ? 'mt-6' : ''}>
            {!isCollapsed && (
              <div className="px-4 py-2 text-[10px] font-semibold tracking-[0.2em] uppercase text-[#444]">
                {t(sectionLabelKeys[section])}
              </div>
            )}
            <div className="space-y-1">
              {navItems.filter(item => item.section === section).map((item) => {
                const Icon = item.icon;
                const isActive = activeSection === item.id;
                const label = t(item.labelKey);
                
                return (
                  <div key={item.id} className="relative flex items-center">
                    {/* Trait indicateur à gauche */}
                    {isActive && (
                      <div 
                        className="absolute left-0 w-[3px] h-6 rounded-r-full bg-[#ff3333]"
                        style={{ top: '50%', transform: 'translateY(-50%)' }}
                      />
                    )}
                    <button
                      onClick={() => setActiveSection(item.id)}
                      data-testid={`nav-${item.id}`}
                      className={`w-full flex items-center gap-3 px-4 py-2.5 mx-2 rounded-lg transition-all duration-200 ${
                        isActive 
                          ? 'text-white' 
                          : 'text-[#666] hover:text-[#999] hover:bg-white/[0.02]'
                      } ${isCollapsed ? 'justify-center mx-1 px-2' : ''}`}
                      style={isActive ? { background: '#1a1a1a' } : {}}
                      title={isCollapsed ? label : ''}
                    >
                      {item.emoji ? (
                        <span 
                          className="text-[18px] flex-shrink-0 transition-all duration-200"
                          style={{
                            filter: isActive ? 'none' : 'grayscale(100%) brightness(0.6)',
                            opacity: isActive ? 1 : 0.6
                          }}
                        >
                          {Icon}
                        </span>
                      ) : (
                        <Icon 
                          className={`w-[18px] h-[18px] flex-shrink-0 ${isActive ? 'text-[#ff3333]' : ''}`}
                          strokeWidth={1.5}
                        />
                      )}
                      {!isCollapsed && (
                        <>
                          <span className="text-[13px] font-medium flex-1 text-left">{label}</span>
                          {item.premium && (
                            <Sparkles className="w-3 h-3 text-[#ff3333]" />
                          )}
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* Collapse Toggle */}
      <div className="p-2" style={{ borderTop: '1px solid #1a1a1a' }}>
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          data-testid="sidebar-toggle"
          className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-[#555] hover:text-[#888] hover:bg-white/[0.02] transition-all ${
            isCollapsed ? 'justify-center' : ''
          }`}
        >
          {isCollapsed ? (
            <ChevronRight className="w-4 h-4" strokeWidth={1.5} />
          ) : (
            <>
              <ChevronLeft className="w-4 h-4" strokeWidth={1.5} />
              <span className="text-[13px] font-medium">{selectedLang === 'fr' ? 'Réduire' : 'Collapse'}</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
