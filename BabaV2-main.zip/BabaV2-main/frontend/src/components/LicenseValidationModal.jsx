import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import axios from 'axios';

// ============================================================================
// CONFIGURATION
// ============================================================================
const SKIP_LICENSE_VALIDATION = false; // true = pas de licence requise, false = licence requise

// URL du backend - Cette URL est utilisée uniquement quand le proxy Electron n'est pas disponible
// En mode Electron avec proxy, l'URL est configurée dans main.js
const getBackendURL = () => {
  // Utiliser l'URL de l'environnement
  return process.env.REACT_APP_BACKEND_URL || '';
};

const BACKEND_URL = getBackendURL();

const LicenseValidationModal = ({ onValidated }) => {
  const { t } = useTranslation();
  const [licenseKey, setLicenseKey] = useState('');
  const [hwid, setHwid] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isValidated, setIsValidated] = useState(false);
  const [checkComplete, setCheckComplete] = useState(false);

  useEffect(() => {
    // Validation de licence OBLIGATOIRE
    // Le code de free license a été supprimé
    
    // Generate HWID
    const generateHWID = () => {
      // En mode Electron, utiliser l'API Electron si disponible
      if (window.electronAPI?.getHWID) {
        return window.electronAPI.getHWID();
      }
      // Sinon, générer un ID basé sur le navigateur
      const userAgent = navigator.userAgent;
      const screen = `${window.screen.width}x${window.screen.height}`;
      const language = navigator.language;
      const platform = navigator.platform;
      return `${userAgent}-${screen}-${language}-${platform}`;
    };

    let currentHWID = localStorage.getItem('device_hwid');
    if (!currentHWID) {
      currentHWID = generateHWID();
      localStorage.setItem('device_hwid', currentHWID);
    }
    setHwid(currentHWID);

    // Vérifier la licence au démarrage
    const checkLicense = async () => {
      const validatedLicense = localStorage.getItem('validated_license');
      
      if (!validatedLicense) {
        setLoading(false);
        setCheckComplete(true);
        return;
      }

      try {
        const license = JSON.parse(validatedLicense);
        
        // Re-valider la licence auprès du serveur
        console.log('=== RE-VALIDATION AU DÉMARRAGE ===');
        console.log('Backend URL:', BACKEND_URL);
        console.log('License Key:', license.license_key);
        console.log('Using Electron proxy:', !!window.electronAPI?.apiRequest);
        
        let responseData;
        
        // Utiliser le proxy Electron si disponible
        if (window.electronAPI?.apiRequest) {
          console.log('Using Electron API proxy for re-validation');
          const result = await window.electronAPI.apiRequest(
            'POST',
            '/api/license/validate',
            {
              license_key: license.license_key,
              hwid: currentHWID
            }
          );
          
          if (!result.success || result.status !== 200) {
            throw new Error(result.error || 'Erreur du proxy Electron');
          }
          
          responseData = result.data;
        } else {
          // Fallback: requête directe avec axios
          console.log('Using axios for re-validation');
          const response = await axios.post(
            `${BACKEND_URL}/api/license/validate`,
            {
              license_key: license.license_key,
              hwid: currentHWID
            },
            { 
              timeout: 15000,
              headers: {
                'Content-Type': 'application/json'
              }
            }
          );
          responseData = response.data;
        }

        console.log('Re-validation response:', responseData);

        if (responseData.valid) {
          // Mise à jour des données de licence depuis le serveur
          localStorage.setItem('validated_license', JSON.stringify(responseData.license));
          // Store license info for sidebar
          localStorage.setItem('babatool_license', JSON.stringify({
            plan: responseData.license.plan,
            pseudo: responseData.license.pseudo,
            status: responseData.license.status
          }));
          // Dispatch event for sidebar to update
          window.dispatchEvent(new Event('license-updated'));
          setIsValidated(true);
          onValidated(responseData.license);
        } else {
          localStorage.removeItem('validated_license');
          localStorage.removeItem('babatool_license');
          setIsValidated(false);
          setError(responseData.message || 'Licence invalide ou révoquée');
        }
      } catch (err) {
        console.error('Erreur de re-validation:', err);
        
        // Mode offline : si une licence existe et était valide, on la garde
        try {
          const storedLicense = JSON.parse(validatedLicense);
          if (storedLicense && storedLicense.status === 'active') {
            console.log('Mode offline - utilisation de la licence locale');
            setIsValidated(true);
            onValidated(storedLicense);
            return;
          }
        } catch (e) {
          // Licence locale invalide
        }
        
        localStorage.removeItem('validated_license');
        setIsValidated(false);
        setError('Impossible de vérifier la licence. Vérifiez votre connexion internet.');
      } finally {
        setLoading(false);
        setCheckComplete(true);
      }
    };

    checkLicense();
  }, [onValidated]);

  const handleValidate = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      console.log('=== VALIDATION DE LICENCE ===');
      console.log('Backend URL:', BACKEND_URL);
      console.log('License Key:', licenseKey);
      console.log('HWID:', hwid);
      console.log('Electron API available:', !!window.electronAPI);
      console.log('Electron API Proxy available:', !!window.electronAPI?.apiRequest);
      
      let responseData;
      
      // Utiliser le proxy Electron si disponible
      if (window.electronAPI?.apiRequest) {
        console.log('Utilisation du proxy Electron');
        const result = await window.electronAPI.apiRequest(
          'POST',
          '/api/license/validate',
          {
            license_key: licenseKey,
            hwid: hwid
          }
        );
        
        console.log('Résultat proxy:', result);
        
        if (!result.success) {
          throw new Error(result.error || 'Erreur du proxy Electron');
        }
        
        if (result.status !== 200) {
          throw new Error(`Erreur HTTP ${result.status}`);
        }
        
        responseData = result.data;
      } else {
        // Fallback : requête directe avec axios
        console.log('Utilisation d\'axios (pas de proxy)');
        const response = await axios.post(
          `${BACKEND_URL}/api/license/validate`,
          {
            license_key: licenseKey,
            hwid: hwid
          },
          { 
            timeout: 15000,
            headers: {
              'Content-Type': 'application/json'
            }
          }
        );
        
        responseData = response.data;
      }

      console.log('Response:', responseData);

      if (responseData.valid) {
        localStorage.setItem('validated_license', JSON.stringify(responseData.license));
        // Store license info for sidebar
        localStorage.setItem('babatool_license', JSON.stringify({
          plan: responseData.license.plan,
          pseudo: responseData.license.pseudo,
          status: responseData.license.status
        }));
        // Dispatch event for sidebar to update
        window.dispatchEvent(new Event('license-updated'));
        setIsValidated(true);
        onValidated(responseData.license);
      } else {
        setError(responseData.message || 'Licence invalide');
      }
    } catch (err) {
      console.error('=== ERREUR DE VALIDATION ===');
      console.error('Error object:', err);
      console.error('Error code:', err.code);
      console.error('Error message:', err.message);
      console.error('Error response:', err.response);
      
      let errorMessage = '';
      
      if (err.code === 'ECONNABORTED' || err.message.includes('timeout')) {
        errorMessage = `Délai de connexion dépassé. Backend: ${BACKEND_URL}`;
      } else if (err.response?.data?.message) {
        errorMessage = err.response.data.message;
      } else if (err.message.includes('Network Error') || err.code === 'ERR_NETWORK') {
        errorMessage = `Erreur réseau. Impossible de contacter le serveur. Vérifiez votre connexion internet.`;
      } else if (err.message.includes('JSON') || err.message.includes('parsing') || err.message.includes('Unexpected')) {
        // Erreur de parsing JSON - probablement une réponse HTML ou erreur serveur
        errorMessage = `Erreur de communication avec le serveur. Veuillez réessayer.`;
      } else {
        errorMessage = `Erreur: ${err.message}`;
      }
      
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  // Écran de chargement pendant la vérification initiale
  if (!checkComplete) {
    return (
      <div className="fixed inset-0 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4 z-50">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-[#ff3333] border-t-transparent rounded-full animate-spin"></div>
          <p className="text-gray-400 text-sm">{t('license.checking')}</p>
        </div>
      </div>
    );
  }

  if (isValidated) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="w-full max-w-md">
        <div className="bg-[#1a1a1a] rounded-2xl border border-white/10 p-8 shadow-2xl">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-[#ff3333] to-[#cc0000] flex items-center justify-center">
              <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
              </svg>
            </div>
          </div>

          <h1 className="text-2xl font-bold text-white text-center mb-2">
            {t('license.title')}
          </h1>
          <p className="text-gray-400 text-center mb-6">
            {t('license.subtitle')}
          </p>

          <form onSubmit={handleValidate} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                {t('license.keyLabel')}
              </label>
              <input
                type="text"
                value={licenseKey}
                onChange={(e) => setLicenseKey(e.target.value.toUpperCase())}
                className="w-full px-4 py-3 bg-[#0d0d0d] border border-white/10 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-[#ff3333] transition font-mono text-center tracking-wider"
                placeholder={t('license.placeholder')}
                required
                disabled={loading}
                data-testid="license-key-input"
              />
            </div>

            {error && (
              <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg" data-testid="license-error">
                <p className="text-red-400 text-sm">{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-[#ff3333] to-[#cc0000] text-white rounded-lg font-medium hover:shadow-lg hover:shadow-[#ff3333]/20 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              data-testid="validate-license-button"
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  {t('license.validating')}
                </>
              ) : (
                t('license.validate')
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default LicenseValidationModal;
