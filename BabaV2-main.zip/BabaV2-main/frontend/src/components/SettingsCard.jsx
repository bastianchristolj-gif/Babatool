import React from 'react';
import { Switch } from '../components/ui/switch';
import { AlertTriangle } from 'lucide-react';

const SettingsCard = ({ setting, onToggle, accentColor = "#ff3333" }) => {
  return (
    <div 
      className="bg-gradient-to-br from-[#151515] to-[#0d0d0d] rounded-2xl p-5 hover:from-[#1a1a1a] hover:to-[#111] transition-all duration-300 border border-white/5 hover:border-white/10 group"
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="text-white text-sm font-semibold truncate group-hover:text-white/90">
              {setting.title}
            </h3>
            {setting.warning && (
              <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0" />
            )}
          </div>
          <p className="text-[#666] text-xs mt-1.5 line-clamp-2 leading-relaxed">
            {setting.description}
          </p>
          {setting.category && (
            <span 
              className="inline-block mt-3 px-2.5 py-1 rounded-lg text-[10px] font-semibold uppercase tracking-wider"
              style={{ 
                backgroundColor: `${accentColor}15`,
                color: accentColor
              }}
            >
              {setting.category}
            </span>
          )}
        </div>
        <Switch
          checked={setting.enabled}
          onCheckedChange={() => onToggle(setting.id)}
          className="data-[state=checked]:bg-[#ff3333] flex-shrink-0 scale-110"
          style={{
            '--switch-color': accentColor
          }}
        />
      </div>
    </div>
  );
};

export default SettingsCard;
