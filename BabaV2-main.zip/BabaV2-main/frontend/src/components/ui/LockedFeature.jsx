import React, { useState } from 'react';
import { Lock, Crown, Zap } from 'lucide-react';
import { LICENSE_TYPES, LICENSE_UPGRADE_MESSAGES } from '../../utils/licenseConfig';
import UpgradeModal from './UpgradeModal';
import { useLicense } from '../../hooks/useLicense';

/**
 * LockedFeature - Composant pour afficher une fonctionnalité verrouillée
 * 
 * @param {Object} props
 * @param {string} props.requiredLicense - Licence requise (premium, lifetime)
 * @param {React.ReactNode} props.children - Contenu à afficher quand déverrouillé
 * @param {boolean} props.isLocked - Si la fonctionnalité est verrouillée
 * @param {string} props.title - Titre personnalisé (optionnel)
 * @param {string} props.description - Description personnalisée (optionnel)
 */
const LockedFeature = ({ 
  requiredLicense, 
  children, 
  isLocked = false,
  title,
  description
}) => {
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const { userLicense, upgradeLicense } = useLicense();
  
  // Si pas verrouillé, afficher le contenu normalement
  if (!isLocked) {
    return <>{children}</>;
  }

  const upgradeInfo = LICENSE_UPGRADE_MESSAGES[requiredLicense] || LICENSE_UPGRADE_MESSAGES[LICENSE_TYPES.PREMIUM];
  
  // Icône selon le type de licence
  const LicenseIcon = requiredLicense === LICENSE_TYPES.LIFETIME ? Crown : requiredLicense === LICENSE_TYPES.PREMIUM ? Zap : Lock;

  const handleUpgradeClick = () => {
    setShowUpgradeModal(true);
  };

  const handleUpgrade = async (targetLicense) => {
    // TODO: Intégrer avec le système de paiement
    await upgradeLicense(targetLicense);
    setShowUpgradeModal(false);
    // Pas besoin de recharger, le hook useLicense gère le changement automatiquement
  };

  return (
    <>
      <div className="locked-feature-wrapper">
        {/* Contenu flouté en arrière-plan */}
        <div className="locked-feature-content">
          {children}
        </div>
        
        {/* Overlay de verrouillage */}
        <div className="locked-feature-overlay">
          <div className="locked-feature-card">
            <div className="locked-feature-icon">
              <LicenseIcon size={48} strokeWidth={1.5} />
            </div>
            
            <h3 className="locked-feature-title">
              {title || upgradeInfo.title}
            </h3>
            
            <p className="locked-feature-description">
              {description || upgradeInfo.description}
            </p>
            
            <div className="locked-feature-badge" style={{ backgroundColor: upgradeInfo.badgeColor }}>
              {upgradeInfo.badge}
            </div>
            
            <button 
              onClick={handleUpgradeClick}
              className={`locked-feature-upgrade-btn ${requiredLicense === LICENSE_TYPES.LIFETIME ? 'lifetime' : ''}`}
            >
              <Crown size={18} strokeWidth={2.5} />
              <span>Améliorer ma licence</span>
            </button>
            
            <p className="locked-feature-hint">
              Débloquez toutes les fonctionnalités avancées
            </p>
          </div>
        </div>
      </div>

      {/* Modal d'upgrade */}
      {showUpgradeModal && (
        <UpgradeModal
          currentLicense={userLicense}
          targetLicense={requiredLicense}
          onClose={() => setShowUpgradeModal(false)}
          onUpgrade={handleUpgrade}
        />
      )}
    </>
  );
};

export default LockedFeature;
