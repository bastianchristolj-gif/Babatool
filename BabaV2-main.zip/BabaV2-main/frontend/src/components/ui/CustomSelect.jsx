import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, Check } from 'lucide-react';

/**
 * CustomSelect - Dropdown personnalisé avec style complet
 * 
 * @param {Object} props
 * @param {string} props.value - Valeur sélectionnée
 * @param {Function} props.onChange - Callback lors du changement
 * @param {Array} props.options - Liste des options [{value, label, icon?, iconUrl?}]
 * @param {string} props.className - Classes CSS additionnelles
 * @param {string} props.placeholder - Texte placeholder
 * @param {string} props.variant - Variante de style ('default' ou 'nvidia-green')
 */
const CustomSelect = ({ value, onChange, options, className = '', placeholder = 'Sélectionner...', variant = 'default' }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const dropdownRef = useRef(null);
  
  // Trouver l'option sélectionnée
  const selectedOption = options.find(opt => opt.value === value);
  
  // Filtrer les options par recherche
  const filteredOptions = options.filter(opt =>
    opt.label.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // Fermer le dropdown quand on clique à l'extérieur
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
        setSearchTerm('');
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);
  
  // Gérer la sélection d'une option
  const handleSelect = (option) => {
    onChange(option.value);
    setIsOpen(false);
    setSearchTerm('');
  };
  
  // Gérer les touches clavier
  const handleKeyDown = (e) => {
    if (e.key === 'Escape') {
      setIsOpen(false);
      setSearchTerm('');
    } else if (e.key === 'Enter' && filteredOptions.length === 1) {
      handleSelect(filteredOptions[0]);
    }
  };
  
  return (
    <div ref={dropdownRef} className={`custom-select-wrapper ${variant === 'nvidia-green' ? 'nvidia-green' : ''} ${className}`}>
      {/* Bouton principal */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="custom-select-trigger"
        aria-haspopup="listbox"
        aria-expanded={isOpen}
      >
        <span className="custom-select-value">
          {selectedOption?.iconUrl && (
            <img 
              src={selectedOption.iconUrl} 
              alt={selectedOption.label}
              className="custom-select-game-icon"
            />
          )}
          {selectedOption?.icon && !selectedOption?.iconUrl && (
            <span className="custom-select-icon">{selectedOption.icon}</span>
          )}
          <span>{selectedOption?.label || placeholder}</span>
        </span>
        <ChevronDown 
          className={`custom-select-chevron ${isOpen ? 'open' : ''}`}
          size={18}
          strokeWidth={2.5}
        />
      </button>
      
      {/* Menu déroulant */}
      {isOpen && (
        <div className="custom-select-menu">
          {/* Recherche (optionnel, si plus de 5 options) */}
          {options.length > 5 && (
            <div className="custom-select-search">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Rechercher..."
                className="custom-select-search-input"
                autoFocus
              />
            </div>
          )}
          
          {/* Liste des options */}
          <div className="custom-select-options" role="listbox">
            {filteredOptions.length === 0 ? (
              <div className="custom-select-option-empty">
                Aucun résultat
              </div>
            ) : (
              filteredOptions.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => handleSelect(option)}
                  className={`custom-select-option ${option.value === value ? 'selected' : ''}`}
                  role="option"
                  aria-selected={option.value === value}
                >
                  {option.iconUrl && (
                    <img 
                      src={option.iconUrl} 
                      alt={option.label}
                      className="custom-select-game-icon"
                    />
                  )}
                  {option.icon && !option.iconUrl && (
                    <span className="custom-select-option-icon">{option.icon}</span>
                  )}
                  <span className="custom-select-option-label">{option.label}</span>
                  {option.value === value && (
                    <Check className="custom-select-check" size={16} strokeWidth={2.5} />
                  )}
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomSelect;
