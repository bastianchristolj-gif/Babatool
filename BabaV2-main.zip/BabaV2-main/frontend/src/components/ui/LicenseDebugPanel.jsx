import React from 'react';
import { Shield, Crown, Zap } from 'lucide-react';
import { useLicense } from '../../hooks/useLicense';
import { LICENSE_TYPES } from '../../utils/licenseConfig';

/**
 * LicenseDebugPanel - Panneau de debug pour changer la licence (DEV ONLY)
 */
const LicenseDebugPanel = () => {
  const { userLicense, setLicense } = useLicense();

  const licenses = [
    { 
      type: LICENSE_TYPES.TRIAL, 
      name: 'Trial', 
      icon: Shield,
      color: '#666666',
      description: 'Gaming + Plan d\'alimentation'
    },
    { 
      type: LICENSE_TYPES.PREMIUM, 
      name: 'Premium', 
      icon: Zap,
      color: '#ff3333',
      description: 'Tout sauf Matériel'
    },
    { 
      type: LICENSE_TYPES.LIFETIME, 
      name: 'Lifetime', 
      icon: Crown,
      color: '#76b900',
      description: 'Accès complet'
    }
  ];

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <div className="bg-gradient-to-br from-[#1a1a1a] to-[#0d0d0d] border-2 border-[#2d2d2d] rounded-2xl p-4 shadow-2xl">
        <div className="flex items-center gap-2 mb-3">
          <Shield className="w-5 h-5 text-[#ff3333]" strokeWidth={2} />
          <h3 className="text-white font-bold text-sm">Licence (Debug)</h3>
        </div>
        
        <div className="space-y-2">
          {licenses.map((license) => {
            const Icon = license.icon;
            const isActive = userLicense === license.type;
            
            return (
              <button
                key={license.type}
                onClick={() => setLicense(license.type)}
                className={`w-full px-4 py-3 rounded-xl transition-all duration-200 flex items-center gap-3 ${
                  isActive 
                    ? 'bg-gradient-to-r from-[#2a2a2a] to-[#1f1f1f] border-2' 
                    : 'bg-[#161616] border border-[#2a2a2a] hover:bg-[#1f1f1f]'
                }`}
                style={{
                  borderColor: isActive ? license.color : undefined
                }}
              >
                <Icon 
                  className="w-5 h-5 flex-shrink-0" 
                  style={{ color: license.color }}
                  strokeWidth={2}
                />
                <div className="flex-1 text-left">
                  <div className="text-white font-semibold text-sm">
                    {license.name}
                    {isActive && <span className="ml-2 text-xs opacity-60">✓ Active</span>}
                  </div>
                  <div className="text-gray-500 text-xs">{license.description}</div>
                </div>
              </button>
            );
          })}
        </div>
        
        <div className="mt-3 pt-3 border-t border-[#2a2a2a]">
          <p className="text-xs text-gray-600 text-center">
            🔧 Panel de développement
          </p>
        </div>
      </div>
    </div>
  );
};

export default LicenseDebugPanel;
