import React from 'react';
import { Crown, Zap, Shield, Check, X } from 'lucide-react';
import { LICENSE_TYPES } from '../../utils/licenseConfig';

/**
 * UpgradeModal - Modal pour améliorer la licence
 */
const UpgradeModal = ({ currentLicense, targetLicense, onClose, onUpgrade }) => {
  const plans = {
    [LICENSE_TYPES.TRIAL]: {
      name: 'Trial',
      icon: Shield,
      color: '#666666',
      price: 'Gratuit',
      features: [
        'Gaming & Plan d\'alimentation',
        'Support de base',
        'Durée : 7 jours'
      ]
    },
    [LICENSE_TYPES.PREMIUM]: {
      name: 'Premium',
      icon: Zap,
      color: '#ff3333',
      price: '29.99€',
      features: [
        'Toutes les fonctionnalités Trial',
        'Configuration Fortnite optimisée',
        'Paramètres OBS automatiques',
        'Privacy, Interface, Bloatware',
        'Support prioritaire',
        'Durée : 1 an'
      ]
    },
    [LICENSE_TYPES.LIFETIME]: {
      name: 'Lifetime',
      icon: Crown,
      color: '#76b900',
      price: '79.99€',
      features: [
        'Toutes les fonctionnalités Premium',
        'Installation drivers NVIDIA',
        'Profils gaming optimisés',
        'Mises à jour à vie',
        'Support VIP',
        'Durée : À vie'
      ]
    }
  };

  const currentPlan = plans[currentLicense];
  const targetPlan = plans[targetLicense];

  if (!targetPlan) {
    return null;
  }

  const TargetIcon = targetPlan.icon;

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4 z-[100]">
      <div className="bg-gradient-to-br from-[#1a1a1a] to-[#0d0d0d] border-2 border-[#2d2d2d] rounded-2xl p-8 w-full max-w-2xl shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <div 
              className="w-16 h-16 rounded-2xl flex items-center justify-center"
              style={{ 
                backgroundColor: `${targetPlan.color}20`,
                border: `2px solid ${targetPlan.color}`
              }}
            >
              <TargetIcon 
                size={32} 
                style={{ color: targetPlan.color }}
                strokeWidth={2}
              />
            </div>
            <div>
              <h2 className="text-3xl font-bold text-white">
                Passer à {targetPlan.name}
              </h2>
              <p className="text-gray-400 text-sm mt-1">
                Débloquez toutes les fonctionnalités avancées
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-white transition p-2 rounded-lg hover:bg-white/5"
          >
            <X size={24} strokeWidth={2} />
          </button>
        </div>

        {/* Comparaison */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Plan Actuel */}
          {currentPlan && (
            <div className="bg-[#111] border border-gray-800 rounded-xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <div 
                  className="w-10 h-10 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: `${currentPlan.color}20` }}
                >
                  <Shield size={20} style={{ color: currentPlan.color }} />
                </div>
                <div>
                  <h3 className="text-white font-semibold">Plan Actuel</h3>
                  <p className="text-gray-500 text-sm">{currentPlan.name}</p>
                </div>
              </div>
              <div className="space-y-2">
                {currentPlan.features.map((feature, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-gray-400 text-sm">
                    <Check size={16} className="mt-0.5 flex-shrink-0" style={{ color: currentPlan.color }} />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Plan Cible */}
          <div 
            className="border-2 rounded-xl p-6 relative overflow-hidden"
            style={{ 
              borderColor: targetPlan.color,
              backgroundColor: `${targetPlan.color}05`
            }}
          >
            <div className="absolute top-0 right-0 px-3 py-1 text-xs font-bold text-white rounded-bl-lg"
                 style={{ backgroundColor: targetPlan.color }}>
              RECOMMANDÉ
            </div>
            <div className="flex items-center gap-3 mb-4">
              <div 
                className="w-10 h-10 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: targetPlan.color }}
              >
                <TargetIcon size={20} color="#ffffff" strokeWidth={2.5} />
              </div>
              <div>
                <h3 className="text-white font-semibold">Plan {targetPlan.name}</h3>
                <p className="text-xl font-bold" style={{ color: targetPlan.color }}>
                  {targetPlan.price}
                </p>
              </div>
            </div>
            <div className="space-y-2">
              {targetPlan.features.map((feature, idx) => (
                <div key={idx} className="flex items-start gap-2 text-white text-sm">
                  <Check size={16} className="mt-0.5 flex-shrink-0" style={{ color: targetPlan.color }} />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-4">
          <button
            onClick={onClose}
            className="flex-1 px-6 py-4 rounded-xl font-semibold text-white transition-all duration-300 bg-[#1a1a1a] hover:bg-[#222222] border border-gray-800"
          >
            Plus tard
          </button>
          <button
            onClick={() => onUpgrade(targetLicense)}
            className="flex-1 px-6 py-4 rounded-xl font-semibold text-white transition-all duration-300 flex items-center justify-center gap-3"
            style={{ 
              background: `linear-gradient(135deg, ${targetPlan.color} 0%, ${targetPlan.color}dd 100%)`,
              boxShadow: `0 4px 16px ${targetPlan.color}40`
            }}
          >
            <Crown size={20} strokeWidth={2.5} />
            <span>Passer à {targetPlan.name}</span>
          </button>
        </div>

        {/* Info */}
        <p className="text-center text-gray-500 text-xs mt-6">
          🔒 Paiement sécurisé • ✓ Activation instantanée • ↩️ Garantie 30 jours
        </p>
      </div>
    </div>
  );
};

export default UpgradeModal;
