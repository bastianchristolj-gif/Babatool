import React, { useState, useEffect, useCallback } from 'react';
import { APP_VERSION, APP_TYPE } from '../lib/version';
import { callEdgeFunction } from '../lib/supabase';

const UpdateChecker = () => {
  const [updateInfo, setUpdateInfo] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [downloadStatus, setDownloadStatus] = useState('');
  const [error, setError] = useState(null);

  // Détection si on est dans Electron
  const isElectron = typeof window !== 'undefined' && window.electronAPI?.isElectron;

  // Comparaison de versions (ex: "1.0.0" vs "1.1.0")
  const compareVersions = (current, latest) => {
    const currentParts = current.split('.').map(Number);
    const latestParts = latest.split('.').map(Number);
    
    for (let i = 0; i < Math.max(currentParts.length, latestParts.length); i++) {
      const a = currentParts[i] || 0;
      const b = latestParts[i] || 0;
      if (b > a) return true;
      if (a > b) return false;
    }
    return false;
  };

  // Vérifier les mises à jour
  const checkForUpdates = useCallback(async () => {
    try {
      const result = await callEdgeFunction('get-update-info', { app_type: APP_TYPE });
      
      if (result.success && result.update_available && result.version) {
        const latestVersion = result.version.version;
        if (compareVersions(APP_VERSION, latestVersion)) {
          setUpdateInfo(result.version);
          setShowModal(true);
        }
      }
    } catch (err) {
      console.error('Update check failed:', err);
    }
  }, []);

  useEffect(() => {
    // Vérifier au démarrage après 3 secondes
    const timer = setTimeout(checkForUpdates, 3000);
    
    // Vérifier toutes les 30 minutes
    const interval = setInterval(checkForUpdates, 30 * 60 * 1000);
    
    return () => {
      clearTimeout(timer);
      clearInterval(interval);
    };
  }, [checkForUpdates]);

  // Écouter le progrès du téléchargement (Electron)
  useEffect(() => {
    if (!isElectron) return;

    const handleProgress = (data) => {
      setDownloadProgress(data.percentage || 0);
      setDownloadStatus(data.status || 'downloading');
      
      if (data.status === 'completed') {
        setDownloadStatus('Installation...');
      }
    };

    window.electronAPI.onDownloadProgress(handleProgress);
    
    return () => {
      window.electronAPI.removeDownloadProgressListener();
    };
  }, [isElectron]);

  // Télécharger et installer la mise à jour
  const handleUpdate = async () => {
    if (!updateInfo?.download_url) return;

    if (isElectron) {
      // Mode Electron : télécharger et installer
      setDownloading(true);
      setError(null);
      setDownloadProgress(0);
      setDownloadStatus('Démarrage...');

      try {
        const result = await window.electronAPI.downloadUpdate(
          updateInfo.download_url,
          updateInfo.version
        );

        if (result.success && result.filePath) {
          setDownloadStatus('Lancement de l\'installation...');
          await window.electronAPI.runSilentInstaller(result.filePath);
        } else {
          setError(result.error || 'Échec du téléchargement');
          setDownloading(false);
        }
      } catch (err) {
        setError(err.message);
        setDownloading(false);
      }
    } else {
      // Mode navigateur : ouvrir le lien
      window.open(updateInfo.download_url, '_blank');
      setShowModal(false);
    }
  };

  if (!showModal || !updateInfo) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100] p-4">
      <div className="bg-[#111] border border-gray-800 rounded-xl p-6 w-full max-w-md">
        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-xl bg-[#ff3333]/20 flex items-center justify-center">
            <svg className="w-6 h-6 text-[#ff3333]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Mise à jour disponible</h2>
            <p className="text-gray-500 text-sm">Version {updateInfo.version}</p>
          </div>
        </div>

        {/* Version actuelle */}
        <div className="flex items-center gap-2 mb-4 text-sm">
          <span className="text-gray-500">Version actuelle :</span>
          <span className="text-gray-300 font-mono">{APP_VERSION}</span>
          <svg className="w-4 h-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
          </svg>
          <span className="text-[#ff3333] font-mono">{updateInfo.version}</span>
        </div>

        {/* Notes de patch */}
        {updateInfo.patch_notes && (
          <div className="bg-[#0a0a0a] border border-gray-800 rounded-lg p-4 mb-4 max-h-40 overflow-y-auto">
            <h3 className="text-gray-400 text-xs font-semibold uppercase mb-2">Notes de mise à jour</h3>
            <p className="text-gray-300 text-sm whitespace-pre-wrap">{updateInfo.patch_notes}</p>
          </div>
        )}

        {/* Barre de progression */}
        {downloading && (
          <div className="mb-4">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-400">{downloadStatus}</span>
              <span className="text-[#ff3333]">{downloadProgress}%</span>
            </div>
            <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-[#ff3333] to-[#ff6666] transition-all duration-300"
                style={{ width: `${downloadProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* Erreur */}
        {error && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 mb-4">
            <p className="text-red-400 text-sm">{error}</p>
          </div>
        )}

        {/* Boutons */}
        <div className="flex gap-3">
          <button
            onClick={() => setShowModal(false)}
            disabled={downloading}
            className="flex-1 px-4 py-3 text-gray-400 hover:text-white border border-gray-800 rounded-lg transition disabled:opacity-50"
          >
            Plus tard
          </button>
          <button
            onClick={handleUpdate}
            disabled={downloading}
            className="flex-1 px-4 py-3 bg-gradient-to-r from-[#ff3333] to-[#cc0000] hover:from-[#ff4444] hover:to-[#dd0000] text-white rounded-lg font-medium transition flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {downloading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Téléchargement...
              </>
            ) : (
              <>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
                Mettre à jour
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default UpdateChecker;
