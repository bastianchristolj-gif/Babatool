import React from 'react';
import { Minus, Square, X, Shield, ShieldAlert } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';

const TitleBar = () => {
  const { isAdmin, isElectron, restartAsAdmin } = useSettings();

  const handleMinimize = () => {
    if (window.electronAPI) window.electronAPI.minimizeWindow();
  };
  
  const handleMaximize = () => {
    if (window.electronAPI) window.electronAPI.maximizeWindow();
  };
  
  const handleClose = () => {
    if (window.electronAPI) window.electronAPI.closeWindow();
  };

  return (
    <div 
      className="h-10 bg-[#0a0a0a] flex items-center justify-between select-none border-b border-white/5"
      style={{ WebkitAppRegion: 'drag' }}
    >
      {/* Left side - Logo and title */}
      <div className="flex items-center gap-3 px-4" style={{ WebkitAppRegion: 'no-drag' }}>
        <div className="w-6 h-6 rounded-md flex items-center justify-center overflow-hidden">
          <img src={process.env.PUBLIC_URL + "/logo.png"} alt="BaBaTool" className="w-full h-full object-contain" />
        </div>
        <span className="text-[#888] text-xs font-medium">BaBaTool</span>
        
        {/* Admin indicator */}
        {isElectron ? (
          isAdmin ? (
            <div className="flex items-center gap-1.5 px-2 py-0.5 bg-emerald-500/10 rounded text-emerald-400 text-[10px] font-semibold">
              <Shield className="w-3 h-3" />
              Admin
            </div>
          ) : (
            <button
              onClick={restartAsAdmin}
              className="flex items-center gap-1.5 px-2 py-0.5 bg-amber-500/10 rounded text-amber-400 text-[10px] font-semibold hover:bg-amber-500/20 transition-colors"
            >
              <ShieldAlert className="w-3 h-3" />
              Exécuter en Admin
            </button>
          )
        ) : (
          <div className="flex items-center gap-1.5 px-2 py-0.5 bg-[#ff3333]/10 rounded text-[#ff3333] text-[10px] font-semibold">
            Mode Web
          </div>
        )}
      </div>

      {/* Right side - Window controls */}
      <div className="flex items-center" style={{ WebkitAppRegion: 'no-drag' }}>
        <button 
          onClick={handleMinimize}
          className="w-12 h-10 flex items-center justify-center text-[#888] hover:bg-white/5 transition-colors"
        >
          <Minus className="w-4 h-4" />
        </button>
        <button 
          onClick={handleMaximize}
          className="w-12 h-10 flex items-center justify-center text-[#888] hover:bg-white/5 transition-colors"
        >
          <Square className="w-3 h-3" />
        </button>
        <button 
          onClick={handleClose}
          className="w-12 h-10 flex items-center justify-center text-[#888] hover:bg-red-500 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

export default TitleBar;
