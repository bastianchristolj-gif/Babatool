import React from 'react';
import { Gamepad2, Activity } from 'lucide-react';
import { useGameModeWatcher } from '../hooks/useGameModeWatcher';

/**
 * Composant indicateur d'état du Game Mode Windows en temps réel
 * Affiche l'état actuel et si la surveillance est active
 */
export function GameModeIndicator({ className = '' }) {
  const { gameModeEnabled, isWatching, lastUpdate } = useGameModeWatcher();

  if (!window.electronAPI?.readGameModeState) {
    // Mode web - pas d'indicateur
    return null;
  }

  if (gameModeEnabled === null) {
    // Chargement initial
    return (
      <div className={`flex items-center gap-2 px-3 py-2 rounded-lg bg-gray-800/50 ${className}`}>
        <Activity className="w-4 h-4 text-gray-400 animate-pulse" />
        <span className="text-sm text-gray-400">Chargement...</span>
      </div>
    );
  }

  return (
    <div className={`flex items-center gap-3 px-4 py-2 rounded-lg transition-all ${
      gameModeEnabled 
        ? 'bg-green-500/10 border border-green-500/30' 
        : 'bg-gray-800/50 border border-gray-700/50'
    } ${className}`}>
      {/* Icône Game Mode */}
      <div className={`relative ${gameModeEnabled ? 'text-green-400' : 'text-gray-400'}`}>
        <Gamepad2 className="w-5 h-5" />
        {isWatching && (
          <span className="absolute -top-1 -right-1 w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
        )}
      </div>

      {/* État */}
      <div className="flex flex-col">
        <span className={`text-sm font-medium ${
          gameModeEnabled ? 'text-green-400' : 'text-gray-300'
        }`}>
          Mode Jeu Windows
        </span>
        <span className="text-xs text-gray-500">
          {gameModeEnabled ? 'Activé' : 'Désactivé'}
          {isWatching && ' • Surveillé'}
        </span>
      </div>

      {/* Indicateur de synchronisation */}
      {lastUpdate && (
        <div className="ml-auto">
          <Activity className={`w-4 h-4 ${
            gameModeEnabled ? 'text-green-400' : 'text-gray-500'
          }`} />
        </div>
      )}
    </div>
  );
}

/**
 * Badge compact pour l'indicateur Game Mode
 */
export function GameModeBadge({ className = '' }) {
  const { gameModeEnabled, isWatching } = useGameModeWatcher();

  if (!window.electronAPI?.readGameModeState || gameModeEnabled === null) {
    return null;
  }

  return (
    <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium ${
      gameModeEnabled 
        ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
        : 'bg-gray-800/50 text-gray-400 border border-gray-700/50'
    } ${className}`}>
      <Gamepad2 className="w-3 h-3" />
      <span>{gameModeEnabled ? 'Mode Jeu ON' : 'Mode Jeu OFF'}</span>
      {isWatching && (
        <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse" />
      )}
    </div>
  );
}

/**
 * Composant de notification toast pour changements Game Mode
 */
export function GameModeToast({ enabled, onClose }) {
  return (
    <div className={`flex items-center gap-3 p-4 rounded-lg shadow-lg ${
      enabled 
        ? 'bg-green-500/20 border border-green-500/50' 
        : 'bg-gray-800 border border-gray-700'
    }`}>
      <Gamepad2 className={`w-5 h-5 ${enabled ? 'text-green-400' : 'text-gray-400'}`} />
      <div className="flex-1">
        <p className={`text-sm font-medium ${enabled ? 'text-green-300' : 'text-gray-300'}`}>
          Mode Jeu Windows {enabled ? 'activé' : 'désactivé'}
        </p>
        <p className="text-xs text-gray-500 mt-1">
          Changement détecté automatiquement
        </p>
      </div>
      <button
        onClick={onClose}
        className="text-gray-400 hover:text-gray-200 transition-colors"
      >
        ✕
      </button>
    </div>
  );
}
