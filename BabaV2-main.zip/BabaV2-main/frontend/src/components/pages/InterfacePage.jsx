import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Palette, Monitor, Image, Menu, LayoutGrid, RefreshCw, Check, FolderOpen, AlertCircle, Upload, Plus, Trash2, X, Eye } from 'lucide-react';
import { useSettings } from '../../context/SettingsContext';
import { interfaceCommands } from '../../data/mockData';
import LockedFeature from '../ui/LockedFeature';
import { useLicense } from '../../hooks/useLicense';
import { FEATURE_CATEGORIES, LICENSE_TYPES } from '../../utils/licenseConfig';

const InterfacePage = () => {
  const { t } = useTranslation();
  const { addToast } = useSettings();
  const { checkFeatureAccess } = useLicense();
  const [selectedTab, setSelectedTab] = useState('custom-windows');
  const [isApplying, setIsApplying] = useState(false);

  // Custom Windows states
  const [darkTheme, setDarkTheme] = useState(false);
  const [transparency, setTransparency] = useState(false);
  const [effects, setEffects] = useState(false);
  const [colorPrevalence, setColorPrevalence] = useState(false); // Afficher couleur sur barre des tâches
  const [accentColor, setAccentColor] = useState('#ff3333');
  const [detectingStates, setDetectingStates] = useState(false);
  const [statesDetected, setStatesDetected] = useState(false);

  // Wallpapers states
  const [wallpapers, setWallpapers] = useState([]);
  const [loadingWallpapers, setLoadingWallpapers] = useState(false);
  const [selectedWallpaper, setSelectedWallpaper] = useState(null);
  const [applyingWallpaper, setApplyingWallpaper] = useState(false);
  const [wallpaperError, setWallpaperError] = useState(null);

  // Old Menu states
  const [contextMenuStyle, setContextMenuStyle] = useState('moderne'); // 'classique' or 'moderne'
  const [altTabStyle, setAltTabStyle] = useState('moderne'); // 'classique' or 'moderne'
  const [applyingOldMenu, setApplyingOldMenu] = useState(null); // null, 'context-menu', or 'alt-tab'

  // Taskbar states
  const [autoHideTaskbar, setAutoHideTaskbar] = useState(false);
  const [taskViewEnabled, setTaskViewEnabled] = useState(true); // Vue des tâches
  const [taskbarAlignment, setTaskbarAlignment] = useState('centre'); // 'centre', 'gauche'
  const [applyingTaskbar, setApplyingTaskbar] = useState(false);

  // Detection states for Old Menu and Taskbar
  const [detectingOldMenuStates, setDetectingOldMenuStates] = useState(false);
  const [oldMenuStatesDetected, setOldMenuStatesDetected] = useState(false);
  const [detectingTaskbarStates, setDetectingTaskbarStates] = useState(false);
  const [taskbarStatesDetected, setTaskbarStatesDetected] = useState(false);

  // Restart Explorer function
  const restartExplorer = async () => {
    if (!window.electronAPI?.executePowerShell) {
      return;
    }

    try {
      const commands = [{
        command: 'Restart Explorer',
        script: `
          Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
          Start-Sleep -Milliseconds 500
          Start-Process explorer
          Write-Output "SUCCESS: Explorer restarted"
        `
      }];

      await window.electronAPI.executePowerShell(commands);
    } catch (error) {
      console.error('Error restarting explorer:', error);
    }
  };

  // Detect Old Menu states
  const detectOldMenuStates = async () => {
    if (!window.electronAPI?.executePowerShell) {
      return;
    }

    setDetectingOldMenuStates(true);

    try {
      // Detect context menu style
      const contextMenuCommands = [{
        command: 'Detect Context Menu Style',
        script: `
          $path = "HKCU:\\Software\\Classes\\CLSID\\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\\InprocServer32"
          if (Test-Path $path) {
            Write-Output "CLASSIC"
          } else {
            Write-Output "MODERN"
          }
        `
      }];
      const contextResult = await window.electronAPI.executePowerShell(contextMenuCommands);
      if (contextResult && contextResult[0]?.output) {
        const output = contextResult[0].output.trim();
        setContextMenuStyle(output === 'CLASSIC' ? 'classique' : 'moderne');
      }

      // Detect Alt+Tab style
      const altTabCommands = [{
        command: 'Detect Alt+Tab Style',
        script: `
          $path = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer"
          $value = Get-ItemProperty -Path $path -Name "AltTabSettings" -ErrorAction SilentlyContinue
          if ($value -and $value.AltTabSettings -eq 1) {
            Write-Output "CLASSIC"
          } else {
            Write-Output "MODERN"
          }
        `
      }];
      const altTabResult = await window.electronAPI.executePowerShell(altTabCommands);
      if (altTabResult && altTabResult[0]?.output) {
        const output = altTabResult[0].output.trim();
        setAltTabStyle(output === 'CLASSIC' ? 'classique' : 'moderne');
      }

      setOldMenuStatesDetected(true);
    } catch (error) {
      console.error('Error detecting Old Menu states:', error);
    } finally {
      setDetectingOldMenuStates(false);
    }
  };

  // Detect Taskbar states
  const detectTaskbarStates = async () => {
    if (!window.electronAPI?.executePowerShell) {
      return;
    }

    setDetectingTaskbarStates(true);

    try {
      // Detect auto-hide
      const autoHideCommands = [{
        command: 'Detect Auto-Hide',
        script: `
          $path = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StuckRects3"
          $value = Get-ItemProperty -Path $path -Name "Settings" -ErrorAction SilentlyContinue
          if ($value) {
            $settings = $value.Settings
            if ($settings[8] -band 0x01) {
              Write-Output "ENABLED"
            } else {
              Write-Output "DISABLED"
            }
          } else {
            Write-Output "DISABLED"
          }
        `
      }];
      const autoHideResult = await window.electronAPI.executePowerShell(autoHideCommands);
      if (autoHideResult && autoHideResult[0]?.output) {
        setAutoHideTaskbar(autoHideResult[0].output.trim() === 'ENABLED');
      }

      // Detect Task View button
      const taskViewCommands = [{
        command: 'Detect Task View',
        script: `
          $path = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced"
          $value = Get-ItemProperty -Path $path -Name "ShowTaskViewButton" -ErrorAction SilentlyContinue
          if ($value -and $value.ShowTaskViewButton -eq 0) {
            Write-Output "DISABLED"
          } else {
            Write-Output "ENABLED"
          }
        `
      }];
      const taskViewResult = await window.electronAPI.executePowerShell(taskViewCommands);
      if (taskViewResult && taskViewResult[0]?.output) {
        setTaskViewEnabled(taskViewResult[0].output.trim() === 'ENABLED');
      }

      // Detect Taskbar alignment
      const alignmentCommands = [{
        command: 'Detect Taskbar Alignment',
        script: `
          $path = "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced"
          $value = Get-ItemProperty -Path $path -Name "TaskbarAl" -ErrorAction SilentlyContinue
          if ($value -and $value.TaskbarAl -eq 0) {
            Write-Output "LEFT"
          } else {
            Write-Output "CENTER"
          }
        `
      }];
      const alignmentResult = await window.electronAPI.executePowerShell(alignmentCommands);
      if (alignmentResult && alignmentResult[0]?.output) {
        setTaskbarAlignment(alignmentResult[0].output.trim() === 'LEFT' ? 'gauche' : 'centre');
      }

      setTaskbarStatesDetected(true);
    } catch (error) {
      console.error('Error detecting Taskbar states:', error);
    } finally {
      setDetectingTaskbarStates(false);
    }
  };

  // Detect Windows states on mount
  useEffect(() => {
    if (selectedTab === 'custom-windows' && window.electronAPI?.readMultipleSettings) {
      detectWindowsStates();
    }
  }, [selectedTab]);

  // Detect Old Menu states when switching to old-menu tab - instant detection
  useEffect(() => {
    if (selectedTab === 'old-menu' && window.electronAPI?.executePowerShell && !oldMenuStatesDetected) {
      detectOldMenuStates();
    }
  }, [selectedTab, oldMenuStatesDetected]);

  // Detect Taskbar states when switching to taskbar tab - instant detection
  useEffect(() => {
    if (selectedTab === 'barre-taches' && window.electronAPI?.executePowerShell && !taskbarStatesDetected) {
      detectTaskbarStates();
    }
  }, [selectedTab, taskbarStatesDetected]);

  // Initial detection on component mount for all tabs
  useEffect(() => {
    const runInitialDetection = async () => {
      if (window.electronAPI?.executePowerShell) {
        // Detect Old Menu states immediately
        detectOldMenuStates();
        // Detect Taskbar states immediately
        detectTaskbarStates();
      }
    };
    runInitialDetection();
  }, []);

  // Function to detect current Windows states
  const detectWindowsStates = async () => {
    if (!window.electronAPI?.readMultipleSettings) {
      return;
    }

    setDetectingStates(true);

    try {
      // Try standard API first
      const settings = await window.electronAPI.readMultipleSettings([
        'dark-mode',
        'transparency',
        'animations',
        'color-prevalence'
      ]);

      if (settings) {
        if (settings['dark-mode'] !== null) setDarkTheme(settings['dark-mode'] === true);
        if (settings['transparency'] !== null) setTransparency(settings['transparency'] === true);
        if (settings['color-prevalence'] !== null) setColorPrevalence(settings['color-prevalence'] === true);
        
        // For effects/animations, use PowerShell detection if API result is uncertain
        if (settings['animations'] !== null) {
          setEffects(settings['animations'] === true);
        } else if (window.electronAPI?.executePowerShell) {
          // Fallback: detect effects via PowerShell - check MinAnimate value
          const effectsCommands = [{
            command: 'Detect Visual Effects',
            script: `
              $advPath = "HKCU:\\Control Panel\\Desktop"
              $minAnimate = Get-ItemProperty -Path $advPath -Name "MinAnimate" -ErrorAction SilentlyContinue
              if ($minAnimate -and $minAnimate.MinAnimate -eq "1") {
                Write-Output "ENABLED"
              } else {
                Write-Output "DISABLED"
              }
            `
          }];
          const effectsResult = await window.electronAPI.executePowerShell(effectsCommands);
          if (effectsResult && effectsResult[0]?.output) {
            setEffects(effectsResult[0].output.trim() === 'ENABLED');
          }
        }
        
        setStatesDetected(true);
      }
    } catch (error) {
      console.error('Error detecting Windows states:', error);
    } finally {
      setDetectingStates(false);
    }
  };

  // Load wallpapers when switching to wallpapers tab
  useEffect(() => {
    if (selectedTab === 'wallpapers') {
      loadWallpapers();
    }
  }, [selectedTab]);

  // Function to load wallpapers from the user's Desktop/wallpapers folder
  const loadWallpapers = async () => {
    if (!window.electronAPI?.getWallpapers) {
      setWallpaperError('Cette fonctionnalité nécessite l\'application Electron');
      return;
    }

    setLoadingWallpapers(true);
    setWallpaperError(null);

    try {
      const result = await window.electronAPI.getWallpapers();
      if (result.success) {
        setWallpapers(result.wallpapers || []);
        if (result.wallpapers?.length === 0) {
          setWallpaperError('Aucun fond d\'écran trouvé. Ajoutez des images dans Desktop/wallpapers');
        }
      } else {
        setWallpaperError(result.error || 'Erreur lors du chargement des fonds d\'écran');
        setWallpapers([]);
      }
    } catch (error) {
      console.error('Error loading wallpapers:', error);
      setWallpaperError('Erreur: ' + error.message);
      setWallpapers([]);
    } finally {
      setLoadingWallpapers(false);
    }
  };

  // Function to apply a wallpaper
  const applyWallpaper = async (wallpaper) => {
    if (!window.electronAPI?.setWallpaper) {
      addToast('Cette fonctionnalité nécessite l\'application Electron', 'error');
      return;
    }

    setApplyingWallpaper(true);
    setSelectedWallpaper(wallpaper.path);

    try {
      const result = await window.electronAPI.setWallpaper(wallpaper.path);
      if (result.success) {
        addToast('✅ Fond d\'écran appliqué avec succès !', 'success');
      } else {
        addToast('❌ Erreur: ' + (result.error || 'Impossible d\'appliquer le fond d\'écran'), 'error');
        setSelectedWallpaper(null);
      }
    } catch (error) {
      console.error('Error applying wallpaper:', error);
      addToast('❌ Erreur: ' + error.message, 'error');
      setSelectedWallpaper(null);
    } finally {
      setApplyingWallpaper(false);
    }
  };

  // Function to import wallpapers
  const [importingWallpaper, setImportingWallpaper] = useState(false);
  
  const importWallpapers = async () => {
    if (!window.electronAPI?.importWallpaper) {
      addToast('Cette fonctionnalité nécessite l\'application Electron', 'error');
      return;
    }

    setImportingWallpaper(true);

    try {
      const result = await window.electronAPI.importWallpaper();
      if (result.success && result.imported?.length > 0) {
        addToast(`✅ ${result.imported.length} fichier(s) importé(s) !`, 'success');
        // Refresh wallpapers list
        await loadWallpapers();
      } else if (result.message === 'Importation annulée') {
        // User cancelled, no toast needed
      } else {
        addToast('❌ ' + (result.message || 'Erreur lors de l\'importation'), 'error');
      }
    } catch (error) {
      console.error('Error importing wallpapers:', error);
      addToast('❌ Erreur: ' + error.message, 'error');
    } finally {
      setImportingWallpaper(false);
    }
  };

  // Function to delete a wallpaper
  const [deletingWallpaper, setDeletingWallpaper] = useState(null);
  
  const deleteWallpaper = async (wallpaper, e) => {
    e.stopPropagation(); // Prevent triggering the apply wallpaper action
    
    if (!window.electronAPI?.deleteWallpaper) {
      addToast('Cette fonctionnalité nécessite l\'application Electron', 'error');
      return;
    }

    setDeletingWallpaper(wallpaper.path);

    try {
      const result = await window.electronAPI.deleteWallpaper(wallpaper.path);
      if (result.success) {
        addToast('✅ Fond d\'écran supprimé !', 'success');
        // Remove from local state
        setWallpapers(prev => prev.filter(w => w.path !== wallpaper.path));
        // Clear selection if deleted wallpaper was selected
        if (selectedWallpaper === wallpaper.path) {
          setSelectedWallpaper(null);
        }
      } else {
        addToast('❌ ' + (result.message || 'Erreur lors de la suppression'), 'error');
      }
    } catch (error) {
      console.error('Error deleting wallpaper:', error);
      addToast('❌ Erreur: ' + error.message, 'error');
    } finally {
      setDeletingWallpaper(null);
    }
  };

  // Custom Windows functions
  const toggleDarkTheme = async (enabled) => {
    if (!window.electronAPI?.executePowerShell) {
      addToast('Cette fonctionnalité nécessite l\'application Electron', 'error');
      return;
    }

    setDarkTheme(enabled);

    try {
      const commandData = enabled 
        ? interfaceCommands.customWindows.darkTheme.enable
        : interfaceCommands.customWindows.darkTheme.disable;

      const commands = [{
        command: commandData.command,
        script: commandData.script
      }];

      const results = await window.electronAPI.executePowerShell(commands);
      const success = results && results[0]?.output?.includes('SUCCESS');

      if (success) {
        addToast(`✅ Thème ${enabled ? 'sombre' : 'clair'} activé !`, 'success');
        await restartExplorer();
      } else {
        addToast('❌ Erreur lors de l\'application', 'error');
        setDarkTheme(!enabled);
      }
    } catch (error) {
      console.error('Error toggling dark theme:', error);
      addToast('❌ Erreur: ' + error.message, 'error');
      setDarkTheme(!enabled);
    }
  };

  const toggleTransparency = async (enabled) => {
    if (!window.electronAPI?.executePowerShell) {
      addToast('Cette fonctionnalité nécessite l\'application Electron', 'error');
      return;
    }

    setTransparency(enabled);

    try {
      const commandData = enabled
        ? interfaceCommands.customWindows.transparency.enable
        : interfaceCommands.customWindows.transparency.disable;

      const commands = [{
        command: commandData.command,
        script: commandData.script
      }];

      const results = await window.electronAPI.executePowerShell(commands);
      const success = results && results[0]?.output?.includes('SUCCESS');

      if (success) {
        addToast(`✅ Transparence ${enabled ? 'activée' : 'désactivée'} !`, 'success');
        await restartExplorer();
      } else {
        addToast('❌ Erreur lors de l\'application', 'error');
        setTransparency(!enabled);
      }
    } catch (error) {
      console.error('Error toggling transparency:', error);
      addToast('❌ Erreur: ' + error.message, 'error');
      setTransparency(!enabled);
    }
  };

  const toggleEffects = async (enabled) => {
    if (!window.electronAPI?.executePowerShell) {
      addToast('Cette fonctionnalité nécessite l\'application Electron', 'error');
      return;
    }

    setEffects(enabled);

    try {
      const commandData = enabled
        ? interfaceCommands.customWindows.effects.enable
        : interfaceCommands.customWindows.effects.disable;

      const commands = [{
        command: commandData.command,
        script: commandData.script
      }];

      const results = await window.electronAPI.executePowerShell(commands);
      const success = results && results[0]?.output?.includes('SUCCESS');

      if (success) {
        addToast(`✅ Effets visuels ${enabled ? 'activés' : 'désactivés'} !`, 'success');
        await restartExplorer();
      } else {
        addToast('❌ Erreur lors de l\'application', 'error');
        setEffects(!enabled);
      }
    } catch (error) {
      console.error('Error toggling effects:', error);
      addToast('❌ Erreur: ' + error.message, 'error');
      setEffects(!enabled);
    }
  };

  const toggleColorPrevalence = async (enabled) => {
    if (!window.electronAPI?.executePowerShell) {
      addToast('Cette fonctionnalité nécessite l\'application Electron', 'error');
      return;
    }

    setColorPrevalence(enabled);

    try {
      const commandData = enabled
        ? interfaceCommands.customWindows.colorPrevalence.enable
        : interfaceCommands.customWindows.colorPrevalence.disable;

      const commands = [{
        command: commandData.command,
        script: commandData.script
      }];

      const results = await window.electronAPI.executePowerShell(commands);
      const success = results && results[0]?.output?.includes('SUCCESS');

      if (success) {
        addToast(`✅ Couleur sur la barre des tâches ${enabled ? 'activée' : 'désactivée'} !`, 'success');
        await restartExplorer();
      } else {
        addToast('❌ Erreur lors de l\'application', 'error');
        setColorPrevalence(!enabled);
      }
    } catch (error) {
      console.error('Error toggling color prevalence:', error);
      addToast('❌ Erreur: ' + error.message, 'error');
      setColorPrevalence(!enabled);
    }
  };

  const applyAccentColor = async (color) => {
    if (!window.electronAPI?.executePowerShell) {
      addToast('Cette fonctionnalité nécessite l\'application Electron', 'error');
      return;
    }

    setAccentColor(color);

    try {
      const script = interfaceCommands.customWindows.accentColor.script(color);

      const commands = [{
        command: interfaceCommands.customWindows.accentColor.command,
        script: script
      }];

      const results = await window.electronAPI.executePowerShell(commands);
      const success = results && results[0]?.output?.includes('SUCCESS');

      if (success) {
        addToast('✅ Couleur d\'accentuation appliquée !', 'success');
        await restartExplorer();
      } else {
        addToast('❌ Erreur lors de l\'application', 'error');
      }
    } catch (error) {
      console.error('Error applying accent color:', error);
      addToast('❌ Erreur: ' + error.message, 'error');
    }
  };

  // Function to apply context menu style
  const applyContextMenuStyle = async (style) => {
    if (!window.electronAPI?.executePowerShell) {
      addToast('Cette fonctionnalité nécessite l\'application Electron', 'error');
      return;
    }

    setApplyingOldMenu('context-menu');
    setContextMenuStyle(style);

    try {
      const commandData = style === 'classique'
        ? interfaceCommands.oldMenu.contextMenu.classic
        : interfaceCommands.oldMenu.contextMenu.modern;

      const commands = [{
        command: commandData.command,
        script: commandData.script
      }];

      const results = await window.electronAPI.executePowerShell(commands);
      const success = results && results[0]?.output?.includes('SUCCESS');

      if (success) {
        addToast(`✅ Menu contextuel ${style} activé !`, 'success');
        await restartExplorer();
      } else {
        addToast('❌ Erreur lors de l\'application', 'error');
      }
    } catch (error) {
      console.error('Error applying context menu style:', error);
      addToast('❌ Erreur: ' + error.message, 'error');
    } finally {
      setApplyingOldMenu(null);
    }
  };

  // Function to apply Alt+Tab style
  const applyAltTabStyle = async (style) => {
    if (!window.electronAPI?.executePowerShell) {
      addToast('Cette fonctionnalité nécessite l\'application Electron', 'error');
      return;
    }

    setApplyingOldMenu('alt-tab');
    setAltTabStyle(style);

    try {
      const commandData = style === 'classique'
        ? interfaceCommands.oldMenu.altTab.classic
        : interfaceCommands.oldMenu.altTab.modern;

      const commands = [{
        command: commandData.command,
        script: commandData.script
      }];

      const results = await window.electronAPI.executePowerShell(commands);
      const success = results && results[0]?.output?.includes('SUCCESS');

      if (success) {
        addToast(`✅ Alt+Tab ${style} activé !`, 'success');
        await restartExplorer();
      } else {
        addToast('❌ Erreur lors de l\'application', 'error');
      }
    } catch (error) {
      console.error('Error applying Alt+Tab style:', error);
      addToast('❌ Erreur: ' + error.message, 'error');
    } finally {
      setApplyingOldMenu(null);
    }
  };

  // Taskbar functions
  const toggleAutoHideTaskbar = async (enabled) => {
    if (!window.electronAPI?.executePowerShell) {
      addToast('Cette fonctionnalité nécessite l\'application Electron', 'error');
      return;
    }

    setApplyingTaskbar(true);
    setAutoHideTaskbar(enabled);

    try {
      const commandData = enabled
        ? interfaceCommands.taskbar.autoHide.enable
        : interfaceCommands.taskbar.autoHide.disable;

      const commands = [{
        command: commandData.command,
        script: commandData.script
      }];

      const results = await window.electronAPI.executePowerShell(commands);
      const success = results && results[0]?.output?.includes('SUCCESS');

      if (success) {
        addToast(`✅ Masquage automatique ${enabled ? 'activé' : 'désactivé'} !`, 'success');
        await restartExplorer();
      } else {
        addToast('❌ Erreur lors de l\'application', 'error');
        setAutoHideTaskbar(!enabled);
      }
    } catch (error) {
      console.error('Error toggling taskbar auto-hide:', error);
      addToast('❌ Erreur: ' + error.message, 'error');
      setAutoHideTaskbar(!enabled);
    } finally {
      setApplyingTaskbar(false);
    }
  };

  const toggleTaskView = async (enabled) => {
    if (!window.electronAPI?.executePowerShell) {
      addToast('Cette fonctionnalité nécessite l\'application Electron', 'error');
      return;
    }

    setApplyingTaskbar(true);
    setTaskViewEnabled(enabled);

    try {
      const commandData = enabled
        ? interfaceCommands.taskbar.taskView.enable
        : interfaceCommands.taskbar.taskView.disable;

      const commands = [{
        command: commandData.command,
        script: commandData.script
      }];

      const results = await window.electronAPI.executePowerShell(commands);
      const success = results && results[0]?.output?.includes('SUCCESS');

      if (success) {
        addToast(`✅ Vue des tâches ${enabled ? 'activée' : 'désactivée'} !`, 'success');
        await restartExplorer();
      } else {
        addToast('❌ Erreur lors de l\'application', 'error');
        setTaskViewEnabled(!enabled);
      }
    } catch (error) {
      console.error('Error toggling task view:', error);
      addToast('❌ Erreur: ' + error.message, 'error');
      setTaskViewEnabled(!enabled);
    } finally {
      setApplyingTaskbar(false);
    }
  };

  const changeTaskbarAlignment = async (alignment) => {
    if (!window.electronAPI?.executePowerShell) {
      addToast('Cette fonctionnalité nécessite l\'application Electron', 'error');
      return;
    }

    setApplyingTaskbar(true);
    setTaskbarAlignment(alignment);

    try {
      const script = interfaceCommands.taskbar.alignment.script(alignment);

      const commands = [{
        command: interfaceCommands.taskbar.alignment.command,
        script: script
      }];

      const results = await window.electronAPI.executePowerShell(commands);
      const success = results && results[0]?.output?.includes('SUCCESS');

      if (success) {
        addToast(`✅ Alignement changé : ${alignment} !`, 'success');
        await restartExplorer();
      } else {
        addToast('❌ Erreur lors de l\'application', 'error');
      }
    } catch (error) {
      console.error('Error changing taskbar alignment:', error);
      addToast('❌ Erreur: ' + error.message, 'error');
    } finally {
      setApplyingTaskbar(false);
    }
  };

  // Available accent colors
  const accentColors = [
    { name: 'Rouge', value: '#ff3333' },
    { name: 'Bleu', value: '#0078d4' },
    { name: 'Vert', value: '#10b981' },
    { name: 'Violet', value: '#8b5cf6' },
    { name: 'Orange', value: '#f97316' },
    { name: 'Rose', value: '#ec4899' }
  ];

  // Tabs options
  const tabs = [
    { id: 'custom-windows', label: t('interface.customWindows.title'), icon: Monitor },
    { id: 'wallpapers', label: t('interface.wallpapers.title'), icon: Image },
    { id: 'old-menu', label: t('interface.oldMenu.title'), icon: Menu },
    { id: 'barre-taches', label: t('interface.taskbar.title'), icon: LayoutGrid }
  ];

  const handleApply = async () => {
    setIsApplying(true);

    try {
      const currentTab = tabs.find(tab => tab.id === selectedTab);
      
      // Simulate applying the customization
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      addToast(`✅ ${currentTab.label} appliqué avec succès !`, 'success');
    } catch (error) {
      console.error('Error applying interface:', error);
      addToast('❌ Erreur lors de l\'application', 'error');
    } finally {
      setIsApplying(false);
    }
  };

  const renderTabContent = () => {
    switch (selectedTab) {
      case 'custom-windows':
        return (
          <div className="space-y-4">
            <div className="exm-card">
              <div className="flex items-start justify-between gap-4 mb-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center flex-shrink-0">
                    <Monitor className="w-6 h-6 text-blue-400" strokeWidth={1.5} />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold mb-2">{t('interface.customWindows.title')}</h3>
                    <p className="text-[#888] text-sm leading-relaxed">
                      {t('interface.customWindows.description')}
                    </p>
                    {statesDetected && (
                      <p className="text-green-400/70 text-xs mt-1">
                        ✓ {t('interface.customWindows.statesDetected')}
                      </p>
                    )}
                  </div>
                </div>
                <button
                  onClick={detectWindowsStates}
                  disabled={detectingStates}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-500/20 hover:bg-green-500/30 transition-colors text-sm text-green-400 hover:text-green-300 disabled:opacity-50 flex-shrink-0"
                  data-testid="detect-states-btn"
                >
                  {detectingStates ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                  <span>{detectingStates ? t('interface.customWindows.detecting') : t('interface.customWindows.detectStates')}</span>
                </button>
              </div>

              {/* Toggle Options */}
              <div className="space-y-4">
                {/* Dark Theme Toggle */}
                <div className="flex items-center justify-between p-4 bg-[#1a1a1a] rounded-lg hover:bg-[#222] transition-colors">
                  <div>
                    <h4 className="text-white font-medium mb-1">{t('interface.customWindows.darkTheme')}</h4>
                    <p className="text-[#666] text-xs">{t('interface.customWindows.darkThemeDesc')}</p>
                  </div>
                  <button
                    onClick={() => toggleDarkTheme(!darkTheme)}
                    className={`relative w-14 h-7 rounded-full transition-colors duration-200 ${
                      darkTheme ? 'bg-[#ff3333]' : 'bg-[#333]'
                    }`}
                    data-testid="dark-theme-toggle"
                  >
                    <span
                      className={`absolute top-0.5 left-0.5 w-6 h-6 bg-white rounded-full transition-transform duration-200 ${
                        darkTheme ? 'translate-x-7' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                {/* Transparency Toggle */}
                <div className="flex items-center justify-between p-4 bg-[#1a1a1a] rounded-lg hover:bg-[#222] transition-colors">
                  <div>
                    <h4 className="text-white font-medium mb-1">{t('interface.customWindows.transparency')}</h4>
                    <p className="text-[#666] text-xs">{t('interface.customWindows.transparencyDesc')}</p>
                  </div>
                  <button
                    onClick={() => toggleTransparency(!transparency)}
                    className={`relative w-14 h-7 rounded-full transition-colors duration-200 ${
                      transparency ? 'bg-[#ff3333]' : 'bg-[#333]'
                    }`}
                    data-testid="transparency-toggle"
                  >
                    <span
                      className={`absolute top-0.5 left-0.5 w-6 h-6 bg-white rounded-full transition-transform duration-200 ${
                        transparency ? 'translate-x-7' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                {/* Effects Toggle */}
                <div className="flex items-center justify-between p-4 bg-[#1a1a1a] rounded-lg hover:bg-[#222] transition-colors">
                  <div>
                    <h4 className="text-white font-medium mb-1">{t('interface.customWindows.effects')}</h4>
                    <p className="text-[#666] text-xs">{t('interface.customWindows.effectsDesc')}</p>
                  </div>
                  <button
                    onClick={() => toggleEffects(!effects)}
                    className={`relative w-14 h-7 rounded-full transition-colors duration-200 ${
                      effects ? 'bg-[#ff3333]' : 'bg-[#333]'
                    }`}
                    data-testid="effects-toggle"
                  >
                    <span
                      className={`absolute top-0.5 left-0.5 w-6 h-6 bg-white rounded-full transition-transform duration-200 ${
                        effects ? 'translate-x-7' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                {/* Color Prevalence Toggle */}
                <div className="flex items-center justify-between p-4 bg-[#1a1a1a] rounded-lg hover:bg-[#222] transition-colors">
                  <div>
                    <h4 className="text-white font-medium mb-1">{t('interface.customWindows.colorPrevalence')}</h4>
                    <p className="text-[#666] text-xs">{t('interface.customWindows.colorPrevalenceDesc')}</p>
                  </div>
                  <button
                    onClick={() => toggleColorPrevalence(!colorPrevalence)}
                    className={`relative w-14 h-7 rounded-full transition-colors duration-200 ${
                      colorPrevalence ? 'bg-[#ff3333]' : 'bg-[#333]'
                    }`}
                    data-testid="color-prevalence-toggle"
                  >
                    <span
                      className={`absolute top-0.5 left-0.5 w-6 h-6 bg-white rounded-full transition-transform duration-200 ${
                        colorPrevalence ? 'translate-x-7' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                {/* Accent Color Selector */}
                <div className="p-4 bg-[#1a1a1a] rounded-lg">
                  <div className="mb-3">
                    <h4 className="text-white font-medium mb-1">{t('interface.customWindows.accentColor')}</h4>
                    <p className="text-[#666] text-xs">{t('interface.customWindows.accentColorDesc')}</p>
                  </div>
                  <div className="grid grid-cols-6 gap-3">
                    {accentColors.map(color => (
                      <button
                        key={color.value}
                        onClick={() => applyAccentColor(color.value)}
                        className={`aspect-square rounded-lg transition-all duration-200 hover:scale-110 ${
                          accentColor === color.value ? 'ring-2 ring-white ring-offset-2 ring-offset-[#0a0a0a]' : ''
                        }`}
                        style={{ backgroundColor: color.value }}
                        title={color.name}
                        data-testid={`accent-color-${color.name.toLowerCase()}`}
                      />
                    ))}
                  </div>
                  <div className="mt-3 flex items-center gap-2">
                    <div 
                      className="w-8 h-8 rounded-lg" 
                      style={{ backgroundColor: accentColor }}
                    />
                    <span className="text-white text-sm">
                      {accentColors.find(c => c.value === accentColor)?.name || 'Personnalisé'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Info Card */}
            <div className="exm-card border-blue-500/20">
              <div className="flex items-start gap-3">
                <span className="text-blue-400 text-xl">💡</span>
                <div>
                  <p className="text-blue-400 text-sm font-medium mb-2">{t('interface.customWindows.infoTitle')}</p>
                  <p className="text-[#666] text-xs leading-relaxed">
                    {t('interface.customWindows.infoDesc')}
                  </p>
                </div>
              </div>
            </div>
          </div>
        );

      case 'wallpapers':
        return (
          <LockedFeature
            requiredLicense={LICENSE_TYPES.PREMIUM}
            isLocked={!checkFeatureAccess(FEATURE_CATEGORIES.INTERFACE_WALLPAPERS)}
            title="🖼️ Wallpapers - Premium"
            description="Personnalisez votre fond d'écran avec une collection de wallpapers. Disponible avec la licence Premium."
          >
          <div className="space-y-4">
            <div className="exm-card">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-green-500/20 to-emerald-500/20 flex items-center justify-center flex-shrink-0">
                  <Image className="w-6 h-6 text-green-400" strokeWidth={1.5} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="text-white font-semibold mb-2">{t('interface.wallpapers.title')}</h3>
                    <div className="flex items-center gap-2">
                      {/* Import Button */}
                      <button
                        onClick={importWallpapers}
                        disabled={importingWallpaper || loadingWallpapers}
                        className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-green-500/20 hover:bg-green-500/30 transition-colors text-sm text-green-400 hover:text-green-300 disabled:opacity-50"
                        data-testid="import-wallpapers-btn"
                      >
                        {importingWallpaper ? (
                          <div className="w-4 h-4 border-2 border-green-400 border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <Plus className="w-4 h-4" />
                        )}
                        <span>{t('interface.wallpapers.import')}</span>
                      </button>
                      {/* Refresh Button */}
                      <button
                        onClick={loadWallpapers}
                        disabled={loadingWallpapers || importingWallpaper}
                        className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#1a1a1a] hover:bg-[#222] transition-colors text-sm text-[#888] hover:text-white disabled:opacity-50"
                        data-testid="refresh-wallpapers-btn"
                      >
                        <RefreshCw className={`w-4 h-4 ${loadingWallpapers ? 'animate-spin' : ''}`} />
                        <span>{t('interface.wallpapers.refresh')}</span>
                      </button>
                    </div>
                  </div>
                  <p className="text-[#888] text-sm leading-relaxed">
                    {t('interface.wallpapers.description')}
                  </p>
                </div>
              </div>

              {/* Loading State */}
              {loadingWallpapers && (
                <div className="flex flex-col items-center justify-center py-12">
                  <div className="w-10 h-10 border-2 border-green-400 border-t-transparent rounded-full animate-spin mb-4"></div>
                  <p className="text-[#888] text-sm">{t('interface.wallpapers.loading')}</p>
                </div>
              )}

              {/* Error State */}
              {!loadingWallpapers && wallpaperError && (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <div className="w-16 h-16 rounded-full bg-orange-500/10 flex items-center justify-center mb-4">
                    <AlertCircle className="w-8 h-8 text-orange-400" />
                  </div>
                  <p className="text-[#888] text-sm mb-2">{wallpaperError}</p>
                  <p className="text-[#666] text-xs mb-4">
                    {t('interface.wallpapers.addWallpaperDesc')}
                  </p>
                  {/* Import button in error state */}
                  <button
                    onClick={importWallpapers}
                    disabled={importingWallpaper}
                    className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-500/20 hover:bg-green-500/30 transition-colors text-sm text-green-400 hover:text-green-300 disabled:opacity-50"
                    data-testid="import-wallpapers-error-btn"
                  >
                    {importingWallpaper ? (
                      <div className="w-4 h-4 border-2 border-green-400 border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <Upload className="w-4 h-4" />
                    )}
                    <span>{t('interface.wallpapers.importWallpapers')}</span>
                  </button>
                </div>
              )}

              {/* Wallpapers Grid */}
              {!loadingWallpapers && !wallpaperError && wallpapers.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                  {wallpapers.map((wallpaper, index) => (
                    <div
                      key={wallpaper.path || index}
                      className={`relative aspect-video rounded-lg overflow-hidden group transition-all duration-200 hover:ring-2 hover:ring-green-400 hover:scale-[1.02] ${
                        selectedWallpaper === wallpaper.path ? 'ring-2 ring-green-400' : ''
                      }`}
                      data-testid={`wallpaper-${index}`}
                    >
                      {/* Clickable image area */}
                      <button
                        onClick={() => applyWallpaper(wallpaper)}
                        disabled={applyingWallpaper || deletingWallpaper === wallpaper.path}
                        className="w-full h-full"
                      >
                        <img
                          src={wallpaper.dataUrl || wallpaper.url}
                          alt={wallpaper.name || `Wallpaper ${index + 1}`}
                          className="w-full h-full object-cover"
                          loading="lazy"
                        />
                      </button>
                      
                      {/* Overlay on hover */}
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none flex items-center justify-center">
                        <span className="text-white text-xs font-medium px-2 py-1 bg-black/50 rounded truncate max-w-[90%]">
                          {wallpaper.name}
                        </span>
                      </div>

                      {/* Delete button */}
                      <button
                        onClick={(e) => deleteWallpaper(wallpaper, e)}
                        disabled={deletingWallpaper === wallpaper.path}
                        className="absolute top-2 left-2 w-7 h-7 rounded-full bg-red-500/80 hover:bg-red-500 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10"
                        data-testid={`delete-wallpaper-${index}`}
                        title={t('interface.wallpapers.delete')}
                      >
                        {deletingWallpaper === wallpaper.path ? (
                          <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <Trash2 className="w-3.5 h-3.5 text-white" />
                        )}
                      </button>

                      {/* Selected indicator */}
                      {selectedWallpaper === wallpaper.path && (
                        <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-green-500 flex items-center justify-center">
                          <Check className="w-4 h-4 text-white" />
                        </div>
                      )}

                      {/* Applying indicator */}
                      {applyingWallpaper && selectedWallpaper === wallpaper.path && (
                        <div className="absolute inset-0 bg-black/60 flex items-center justify-center z-20">
                          <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* Empty State (no error, just no wallpapers found yet) */}
              {!loadingWallpapers && !wallpaperError && wallpapers.length === 0 && (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <div className="w-16 h-16 rounded-full bg-[#1a1a1a] flex items-center justify-center mb-4">
                    <FolderOpen className="w-8 h-8 text-[#444]" />
                  </div>
                  <p className="text-[#888] text-sm mb-2">{t('interface.wallpapers.noWallpapers')}</p>
                  <p className="text-[#666] text-xs mb-4">
                    {t('interface.wallpapers.clickImport')}
                  </p>
                  {/* Import button in empty state */}
                  <button
                    onClick={importWallpapers}
                    disabled={importingWallpaper}
                    className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-500/20 hover:bg-green-500/30 transition-colors text-sm text-green-400 hover:text-green-300 disabled:opacity-50"
                    data-testid="import-wallpapers-empty-btn"
                  >
                    {importingWallpaper ? (
                      <div className="w-4 h-4 border-2 border-green-400 border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <Upload className="w-4 h-4" />
                    )}
                    <span>{t('interface.wallpapers.importWallpapers')}</span>
                  </button>
                </div>
              )}
            </div>

            {/* Info card for wallpapers */}
            <div className="exm-card border-green-500/20">
              <div className="flex items-start gap-3">
                <span className="text-green-400 text-xl">📁</span>
                <div>
                  <p className="text-green-400 text-sm font-medium mb-2">{t('interface.wallpapers.locationTitle')}</p>
                  <p className="text-[#666] text-xs leading-relaxed">
                    {t('interface.wallpapers.locationDesc')}
                  </p>
                </div>
              </div>
            </div>
          </div>
          </LockedFeature>
        );

      case 'old-menu':
        return (
          <div className="space-y-4">
            <div className="exm-card">
              <div className="flex items-start justify-between gap-4 mb-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-500/20 to-pink-500/20 flex items-center justify-center flex-shrink-0">
                    <Menu className="w-6 h-6 text-purple-400" strokeWidth={1.5} />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold mb-2">{t('interface.oldMenu.title')}</h3>
                    <p className="text-[#888] text-sm leading-relaxed">
                      {t('interface.oldMenu.description')}
                    </p>
                    {oldMenuStatesDetected && (
                      <p className="text-green-400/70 text-xs mt-1">
                        ✓ États détectés avec succès
                      </p>
                    )}
                  </div>
                </div>
                <button
                  onClick={detectOldMenuStates}
                  disabled={detectingOldMenuStates}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-500/20 hover:bg-green-500/30 transition-colors text-sm text-green-400 hover:text-green-300 disabled:opacity-50 flex-shrink-0"
                  data-testid="detect-old-menu-states-btn"
                >
                  {detectingOldMenuStates ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                  <span>{detectingOldMenuStates ? 'Détection...' : 'Détecter'}</span>
                </button>
              </div>

              {/* Context Menu Option */}
              <div className="space-y-4">
                <div className="p-4 bg-[#1a1a1a] rounded-lg">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h4 className="text-white font-medium mb-1">{t('interface.oldMenu.contextMenu')}</h4>
                      <p className="text-[#666] text-xs">{t('interface.oldMenu.contextMenuDesc')}</p>
                    </div>
                    {applyingOldMenu === 'context-menu' && (
                      <div className="w-5 h-5 border-2 border-purple-400 border-t-transparent rounded-full animate-spin" />
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => applyContextMenuStyle('classique')}
                      disabled={applyingOldMenu !== null}
                      className={`p-4 rounded-lg border-2 transition-all duration-200 ${
                        contextMenuStyle === 'classique'
                          ? 'border-purple-500 bg-purple-500/10'
                          : 'border-[#333] bg-[#111] hover:border-[#444]'
                      } ${applyingOldMenu !== null ? 'opacity-50 cursor-not-allowed' : ''}`}
                      data-testid="context-menu-classique"
                    >
                      <div className="text-center">
                        <div className="w-10 h-10 mx-auto mb-2 rounded-lg bg-[#333] flex items-center justify-center">
                          <Menu className="w-5 h-5 text-purple-400" />
                        </div>
                        <span className={`text-sm font-medium ${contextMenuStyle === 'classique' ? 'text-purple-400' : 'text-white'}`}>
                          {t('interface.oldMenu.classic')}
                        </span>
                        <p className="text-[#666] text-xs mt-1">{t('interface.oldMenu.windows10')}</p>
                      </div>
                    </button>
                    <button
                      onClick={() => applyContextMenuStyle('moderne')}
                      disabled={applyingOldMenu !== null}
                      className={`p-4 rounded-lg border-2 transition-all duration-200 ${
                        contextMenuStyle === 'moderne'
                          ? 'border-purple-500 bg-purple-500/10'
                          : 'border-[#333] bg-[#111] hover:border-[#444]'
                      } ${applyingOldMenu !== null ? 'opacity-50 cursor-not-allowed' : ''}`}
                      data-testid="context-menu-moderne"
                    >
                      <div className="text-center">
                        <div className="w-10 h-10 mx-auto mb-2 rounded-lg bg-[#333] flex items-center justify-center">
                          <LayoutGrid className="w-5 h-5 text-blue-400" />
                        </div>
                        <span className={`text-sm font-medium ${contextMenuStyle === 'moderne' ? 'text-purple-400' : 'text-white'}`}>
                          {t('interface.oldMenu.modern')}
                        </span>
                        <p className="text-[#666] text-xs mt-1">{t('interface.oldMenu.windows11')}</p>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Alt+Tab Option */}
                <div className="p-4 bg-[#1a1a1a] rounded-lg">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h4 className="text-white font-medium mb-1">{t('interface.oldMenu.altTab')}</h4>
                      <p className="text-[#666] text-xs">{t('interface.oldMenu.altTabDesc')}</p>
                    </div>
                    {applyingOldMenu === 'alt-tab' && (
                      <div className="w-5 h-5 border-2 border-purple-400 border-t-transparent rounded-full animate-spin" />
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => applyAltTabStyle('classique')}
                      disabled={applyingOldMenu !== null}
                      className={`p-4 rounded-lg border-2 transition-all duration-200 ${
                        altTabStyle === 'classique'
                          ? 'border-purple-500 bg-purple-500/10'
                          : 'border-[#333] bg-[#111] hover:border-[#444]'
                      } ${applyingOldMenu !== null ? 'opacity-50 cursor-not-allowed' : ''}`}
                      data-testid="alt-tab-classique"
                    >
                      <div className="text-center">
                        <div className="w-10 h-10 mx-auto mb-2 rounded-lg bg-[#333] flex items-center justify-center">
                          <div className="grid grid-cols-2 gap-0.5">
                            <div className="w-2 h-2 bg-purple-400 rounded-sm"></div>
                            <div className="w-2 h-2 bg-purple-400/50 rounded-sm"></div>
                            <div className="w-2 h-2 bg-purple-400/50 rounded-sm"></div>
                            <div className="w-2 h-2 bg-purple-400/30 rounded-sm"></div>
                          </div>
                        </div>
                        <span className={`text-sm font-medium ${altTabStyle === 'classique' ? 'text-purple-400' : 'text-white'}`}>
                          {t('interface.oldMenu.classic')}
                        </span>
                        <p className="text-[#666] text-xs mt-1">{t('interface.oldMenu.simpleThumbnails')}</p>
                      </div>
                    </button>
                    <button
                      onClick={() => applyAltTabStyle('moderne')}
                      disabled={applyingOldMenu !== null}
                      className={`p-4 rounded-lg border-2 transition-all duration-200 ${
                        altTabStyle === 'moderne'
                          ? 'border-purple-500 bg-purple-500/10'
                          : 'border-[#333] bg-[#111] hover:border-[#444]'
                      } ${applyingOldMenu !== null ? 'opacity-50 cursor-not-allowed' : ''}`}
                      data-testid="alt-tab-moderne"
                    >
                      <div className="text-center">
                        <div className="w-10 h-10 mx-auto mb-2 rounded-lg bg-[#333] flex items-center justify-center">
                          <div className="flex gap-0.5">
                            <div className="w-3 h-4 bg-blue-400 rounded-sm"></div>
                            <div className="w-3 h-4 bg-blue-400/50 rounded-sm"></div>
                            <div className="w-3 h-4 bg-blue-400/30 rounded-sm"></div>
                          </div>
                        </div>
                        <span className={`text-sm font-medium ${altTabStyle === 'moderne' ? 'text-purple-400' : 'text-white'}`}>
                          {t('interface.oldMenu.modern')}
                        </span>
                        <p className="text-[#666] text-xs mt-1">{t('interface.oldMenu.fullPreview')}</p>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Info Card */}
            <div className="exm-card border-purple-500/20">
              <div className="flex items-start gap-3">
                <span className="text-purple-400 text-xl">💡</span>
                <div>
                  <p className="text-purple-400 text-sm font-medium mb-2">{t('interface.oldMenu.infoTitle')}</p>
                  <p className="text-[#666] text-xs leading-relaxed">
                    {t('interface.oldMenu.infoDesc')}
                  </p>
                </div>
              </div>
            </div>
          </div>
        );

      case 'barre-taches':
        return (
          <div className="space-y-4">
            <div className="exm-card">
              <div className="flex items-start justify-between gap-4 mb-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-orange-500/20 to-red-500/20 flex items-center justify-center flex-shrink-0">
                    <LayoutGrid className="w-6 h-6 text-orange-400" strokeWidth={1.5} />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold mb-2">{t('interface.taskbar.title')}</h3>
                    <p className="text-[#888] text-sm leading-relaxed">
                      {t('interface.taskbar.description')}
                    </p>
                    {taskbarStatesDetected && (
                      <p className="text-green-400/70 text-xs mt-1">
                        ✓ États détectés avec succès
                      </p>
                    )}
                  </div>
                </div>
                <button
                  onClick={detectTaskbarStates}
                  disabled={detectingTaskbarStates}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-500/20 hover:bg-green-500/30 transition-colors text-sm text-green-400 hover:text-green-300 disabled:opacity-50 flex-shrink-0"
                  data-testid="detect-taskbar-states-btn"
                >
                  {detectingTaskbarStates ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                  <span>{detectingTaskbarStates ? 'Détection...' : 'Détecter'}</span>
                </button>
              </div>

              <div className="space-y-4">
                {/* Auto-hide Taskbar Toggle */}
                <div className="p-4 bg-[#1a1a1a] rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-white font-medium mb-1">{t('interface.taskbar.autoHide')}</h4>
                      <p className="text-[#666] text-xs">{t('interface.taskbar.autoHideDesc')}</p>
                    </div>
                    <button
                      onClick={() => toggleAutoHideTaskbar(!autoHideTaskbar)}
                      disabled={applyingTaskbar}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        autoHideTaskbar ? 'bg-orange-500' : 'bg-[#333]'
                      } ${applyingTaskbar ? 'opacity-50 cursor-not-allowed' : ''}`}
                      data-testid="auto-hide-taskbar-toggle"
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          autoHideTaskbar ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>

                {/* Task View Toggle */}
                <div className="p-4 bg-[#1a1a1a] rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-white font-medium mb-1">{t('interface.taskbar.taskView')}</h4>
                      <p className="text-[#666] text-xs">{t('interface.taskbar.taskViewDesc')}</p>
                    </div>
                    <button
                      onClick={() => toggleTaskView(!taskViewEnabled)}
                      disabled={applyingTaskbar}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        taskViewEnabled ? 'bg-orange-500' : 'bg-[#333]'
                      } ${applyingTaskbar ? 'opacity-50 cursor-not-allowed' : ''}`}
                      data-testid="task-view-toggle"
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          taskViewEnabled ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>

                {/* Taskbar Alignment */}
                <div className="p-4 bg-[#1a1a1a] rounded-lg">
                  <div className="mb-4">
                    <h4 className="text-white font-medium mb-1">{t('interface.taskbar.alignment')}</h4>
                    <p className="text-[#666] text-xs">{t('interface.taskbar.alignmentDesc')}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { id: 'centre', label: t('interface.taskbar.alignmentCenter'), icon: '⬌' },
                      { id: 'gauche', label: t('interface.taskbar.alignmentLeft'), icon: '⬅' }
                    ].map(align => (
                      <button
                        key={align.id}
                        onClick={() => changeTaskbarAlignment(align.id)}
                        disabled={applyingTaskbar}
                        className={`p-4 rounded-lg border-2 transition-all duration-200 ${
                          taskbarAlignment === align.id
                            ? 'border-orange-500 bg-orange-500/10'
                            : 'border-[#333] bg-[#111] hover:border-[#444]'
                        } ${applyingTaskbar ? 'opacity-50 cursor-not-allowed' : ''}`}
                        data-testid={`taskbar-alignment-${align.id}`}
                      >
                        <div className="flex flex-col items-center gap-2">
                          <span className="text-2xl">{align.icon}</span>
                          <span className={`text-sm font-medium ${
                            taskbarAlignment === align.id ? 'text-orange-400' : 'text-white'
                          }`}>
                            {align.label}
                          </span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Info Card */}
            <div className="exm-card border-orange-500/20">
              <div className="flex items-start gap-3">
                <span className="text-orange-400 text-xl">💡</span>
                <div>
                  <p className="text-orange-400 text-sm font-medium mb-2">{t('interface.taskbar.infoTitle')}</p>
                  <p className="text-[#666] text-xs leading-relaxed">
                    {t('interface.taskbar.infoDesc')}
                  </p>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="space-y-6 exm-fade-in">
      {/* Header */}
      <div>
        <h1 className="exm-section-title">{t('nav.interface')}</h1>
        <p className="exm-section-subtitle">Personnalisez l&apos;apparence de votre système Windows</p>
      </div>

      {/* Tabs - Same style as Performance page */}
      <div className="exm-tabs">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setSelectedTab(tab.id)}
              data-testid={`interface-tab-${tab.id}`}
              className={`exm-tab ${selectedTab === tab.id ? 'active' : ''}`}
            >
              <Icon className="w-4 h-4" strokeWidth={1.5} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      <div className="exm-fade-in">
        {renderTabContent()}
      </div>

      {/* Apply Button - Hidden on Wallpapers, Old Menu, Barre des tâches and Custom Windows tabs */}
      {selectedTab !== 'wallpapers' && selectedTab !== 'old-menu' && selectedTab !== 'barre-taches' && selectedTab !== 'custom-windows' && (
        <div className="exm-card max-w-3xl mx-auto">
          <button
            onClick={handleApply}
            disabled={isApplying}
            className="exm-btn-primary w-full flex items-center justify-center gap-2 disabled:opacity-50"
            data-testid="apply-interface-btn"
          >
            {isApplying ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span>Application en cours...</span>
              </>
            ) : (
              <>
                <Palette className="w-5 h-5" />
                <span>Appliquer la personnalisation</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* Info Card */}
      <div className="exm-card border-purple-500/20">
        <div className="flex items-start gap-3">
          <span className="text-purple-400 text-xl">💡</span>
          <div>
            <p className="text-purple-400 text-sm font-medium mb-2">{t('interface.globalTip.title')}</p>
            <p className="text-[#666] text-xs leading-relaxed">
              {t('interface.globalTip.description')}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InterfacePage;
