import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from 'recharts';

const DashboardHomePage = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const getAuthHeaders = () => {
    const token = localStorage.getItem('admin_token');
    if (!token) {
      navigate('/admin/login');
      return null;
    }
    return { Authorization: `Bearer ${token}` };
  };

  useEffect(() => {
    const fetchStats = async () => {
      const headers = getAuthHeaders();
      if (!headers) return;

      try {
        const [statsRes, licensesRes] = await Promise.all([
          axios.get(`${process.env.REACT_APP_BACKEND_URL}/api/admin/stats`, { headers }),
          axios.get(`${process.env.REACT_APP_BACKEND_URL}/api/admin/licenses`, { headers })
        ]);

        const licenses = licensesRes.data;
        const lifetimeCount = licenses.filter(l => !l.expires_at).length;

        setStats({
          ...statsRes.data,
          lifetime_licenses: lifetimeCount
        });
      } catch (err) {
        console.error('Error fetching stats:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
    const interval = setInterval(fetchStats, 30000);
    return () => clearInterval(interval);
  }, []);

  if (loading || !stats) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  const statusData = [
    { name: 'Active', value: stats.active_licenses, color: '#10b981' },
    { name: 'Inactive', value: stats.suspended_licenses + stats.expired_licenses, color: '#6b7280' }
  ];

  const planData = [
    { name: 'Lifetime', value: stats.lifetime_licenses, color: '#f59e0b' }
  ];

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-white mb-2">Dashboard</h1>
        <p className="text-gray-400 text-sm">License management overview</p>
      </div>

      {/* Status Indicator */}
      <div className="flex justify-end mb-6">
        <div className="flex items-center gap-2 px-4 py-2 bg-[#ff3333]/10 border border-[#ff3333]/30 rounded-lg">
          <div className="w-2 h-2 bg-[#ff3333] rounded-full animate-pulse"></div>
          <span className="text-[#ff3333] text-sm font-medium">System Online</span>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
        <StatCard
          title="Total Licenses"
          value={stats.total_licenses}
          icon={<KeyIcon />}
          color="blue"
        />
        <StatCard
          title="Active"
          value={stats.active_licenses}
          icon={<CheckIcon />}
          color="green"
        />
        <StatCard
          title="Inactive"
          value={stats.suspended_licenses + stats.expired_licenses}
          icon={<PauseIcon />}
          color="gray"
        />
        <StatCard
          title="Banned"
          value={stats.suspended_licenses}
          icon={<BanIcon />}
          color="red"
        />
        <StatCard
          title="Expired"
          value={stats.expired_licenses}
          icon={<ClockIcon />}
          color="yellow"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Status Distribution */}
        <div className="bg-[#0a0a0a] border border-gray-800 rounded-lg p-6">
          <h3 className="text-white text-lg font-semibold mb-6">Status Distribution</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={statusData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={2}
                dataKey="value"
              >
                {statusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Legend
                verticalAlign="bottom"
                height={36}
                content={<CustomLegend data={statusData} />}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Plan Distribution */}
        <div className="bg-[#0a0a0a] border border-gray-800 rounded-lg p-6">
          <h3 className="text-white text-lg font-semibold mb-6">Plan Distribution</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={planData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={2}
                dataKey="value"
              >
                {planData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Legend
                verticalAlign="bottom"
                height={36}
                content={<CustomLegend data={planData} />}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Plans Overview */}
        <div className="bg-[#0a0a0a] border border-gray-800 rounded-lg p-6">
          <h3 className="text-white text-lg font-semibold mb-6">Plans Overview</h3>
          <div className="space-y-4">
            <PlanItem icon={<BoltIcon />} name="Trial" count={0} color="blue" />
            <PlanItem icon={<StarIcon />} name="Standard" count={0} color="purple" />
            <PlanItem icon={<CrownIcon />} name="Lifetime" count={stats.lifetime_licenses} color="yellow" />
          </div>
        </div>
      </div>

      {/* Admin Credentials */}
      <div className="bg-[#0a0a0a] border border-gray-800 rounded-lg p-6">
        <h3 className="text-white text-lg font-semibold mb-2">Admin Credentials</h3>
        <p className="text-gray-400 text-sm mb-6">Default login for testing</p>
        <div className="flex justify-end gap-8 text-sm">
          <div>
            <span className="text-gray-400">Username: </span>
            <span className="text-white">admin</span>
          </div>
          <div>
            <span className="text-gray-400">Password: </span>
            <span className="text-white">admin123</span>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, icon, color }) => {
  const colorClasses = {
    blue: 'bg-blue-500/10 border-blue-500/30',
    green: 'bg-[#ff3333]/10 border-[#ff3333]/30',
    gray: 'bg-gray-500/10 border-gray-500/30',
    red: 'bg-red-500/10 border-red-500/30',
    yellow: 'bg-yellow-500/10 border-yellow-500/30',
  };

  const iconColorClasses = {
    blue: 'text-blue-500',
    green: 'text-[#ff3333]',
    gray: 'text-gray-500',
    red: 'text-red-500',
    yellow: 'text-yellow-500',
  };

  return (
    <div className={`${colorClasses[color]} border rounded-lg p-4`}>
      <div className="flex items-center justify-between mb-3">
        <div className={iconColorClasses[color]}>{icon}</div>
        <span className="text-white text-3xl font-bold">{value}</span>
      </div>
      <p className="text-gray-400 text-sm">{title}</p>
    </div>
  );
};

const PlanItem = ({ icon, name, count, color }) => {
  const iconColorClasses = {
    blue: 'text-blue-500',
    purple: 'text-[#ff3333]',
    yellow: 'text-yellow-500',
  };

  return (
    <div className="bg-[#111] border border-gray-800 rounded-lg p-4 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className={iconColorClasses[color]}>{icon}</div>
        <span className="text-white">{name}</span>
      </div>
      <span className="text-white text-2xl font-bold">{count}</span>
    </div>
  );
};

const CustomLegend = ({ data }) => (
  <div className="flex justify-center gap-6 mt-4">
    {data.map((entry, index) => (
      <div key={index} className="flex items-center gap-2">
        <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: entry.color }}></div>
        <span className="text-gray-400 text-sm">{entry.name}</span>
      </div>
    ))}
  </div>
);

// Icons
const KeyIcon = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
  </svg>
);

const CheckIcon = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const PauseIcon = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const BanIcon = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
  </svg>
);

const ClockIcon = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const BoltIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
  </svg>
);

const StarIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
  </svg>
);

const CrownIcon = () => (
  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
    <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" />
    <path fillRule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm9.707 5.707a1 1 0 00-1.414-1.414L9 12.586l-1.293-1.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
  </svg>
);

export default DashboardHomePage;