import React, { useState, useEffect, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { Gauge, Search, SlidersHorizontal, ArrowUpDown, RefreshCw, Cpu, Gamepad2, Target, CheckCircle2, Loader2 } from 'lucide-react';
import { useSettings } from '../../context/SettingsContext';
import { powerModes, powerOptions, gamingOptions, obsGpuTypes } from '../../data/mockData';
import CustomSelect from '../ui/CustomSelect';
import LockedFeature from '../ui/LockedFeature';
import { useLicense } from '../../hooks/useLicense';
import { FEATURE_CATEGORIES, LICENSE_TYPES } from '../../utils/licenseConfig';

const PerformancePage = () => {
  const { t } = useTranslation();
  const { addToast } = useSettings();
  const { userLicense, checkFeatureAccess } = useLicense();
  const [selectedProfile, setSelectedProfile] = useState('power');
  const [powerMode, setPowerMode] = useState('normal');
  const [powerOptionsState, setPowerOptionsState] = useState(() => 
    powerOptions.map(opt => ({ ...opt }))
  );
  const [gamingOptionsState, setGamingOptionsState] = useState(() =>
    gamingOptions.map(opt => ({ ...opt }))
  );
  const [selectedGpu, setSelectedGpu] = useState('');
  const [isElectron, setIsElectron] = useState(false);
  const [isDetectingSettings, setIsDetectingSettings] = useState(false);
  const [settingsDetected, setSettingsDetected] = useState(false);
  const [lastDetectionTime, setLastDetectionTime] = useState(null);
  const [isLoadingInitialStates, setIsLoadingInitialStates] = useState(true);
  
  // Fortnite settings state - Only parameters from Fotnite.ps1
  const [fortniteSettings, setFortniteSettings] = useState({
    graphicsAPI: 'OldPerformance',
    resolutionX: 1920,
    resolutionY: 1080,
    frameRateLimit: 240,
    textures: 0,
    viewDistance: 1
  });

  const profiles = [
    { value: 'power', labelKey: 'performance.tabs.powerPlan', icon: '⚡' },
    { value: 'gaming', labelKey: 'performance.tabs.gaming', icon: '🎮' },
    { value: 'fortnite', labelKey: 'performance.tabs.fortnite', icon: '🎯' },
    { value: 'obs', labelKey: 'performance.tabs.obs', icon: '🎥' }
  ];

  // Check if running in Electron
  useEffect(() => {
    setIsElectron(typeof window !== 'undefined' && window.electronAPI?.isElectron);
  }, []);

  // Load real system settings on mount (Electron only)
  useEffect(() => {
    if (isElectron) {
      loadAllRealStates();
    } else {
      // Not Electron, stop loading
      setIsLoadingInitialStates(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isElectron]);

  /**
   * Charge TOUS les états réels depuis Windows au démarrage
   * Utilise le nouveau système readMultipleSettings pour une lecture efficace
   */
  const loadAllRealStates = async () => {
    setIsLoadingInitialStates(true);
    
    try {
      // Use the new batch reading API if available
      if (window.electronAPI?.readMultipleSettings) {
        // Collect all setting IDs to read
        const powerIds = powerOptionsState
          .filter(opt => opt.type === 'toggle' && opt.id)
          .map(opt => opt.id);
        
        const gamingIds = gamingOptionsState
          .filter(opt => opt.id)
          .map(opt => opt.id);
        
        const allIds = [...powerIds, ...gamingIds];
        console.log('[PerformancePage] Loading all settings:', allIds);
        
        // Read all settings in one batch call
        const realStates = await window.electronAPI.readMultipleSettings(allIds);
        console.log('[PerformancePage] Real states loaded:', realStates);
        
        // Update power options
        setPowerOptionsState(prev => 
          prev.map(opt => {
            if (opt.type === 'toggle' && realStates[opt.id] !== null && realStates[opt.id] !== undefined) {
              console.log(`[PerformancePage] Setting ${opt.id} = ${realStates[opt.id]}`);
              return { ...opt, enabled: realStates[opt.id] };
            }
            return opt;
          })
        );
        
        // Update gaming options
        setGamingOptionsState(prev => 
          prev.map(opt => {
            if (realStates[opt.id] !== null && realStates[opt.id] !== undefined) {
              console.log(`[PerformancePage] Setting ${opt.id} = ${realStates[opt.id]}`);
              return { ...opt, enabled: realStates[opt.id] };
            }
            return opt;
          })
        );
        
        setSettingsDetected(true);
        setLastDetectionTime(new Date());
        console.log('[PerformancePage] ✓ All real states loaded successfully');
      } else {
        // Fallback to individual reads
        await loadRealSettingsStates();
        await loadRealSystemSettings();
      }
      
      // Also detect current power plan via PowerShell
      if (window.electronAPI?.executePowerShell) {
        const detectPowerPlanScript = `
$activePlan = powercfg /getactivescheme
if ($activePlan -match "a1841308-3541-4fab-bc81-f71556f20b4a") {
  Write-Output "economy"
} elseif ($activePlan -match "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c") {
  Write-Output "performance"
} else {
  Write-Output "normal"
}`;
        const commands = [{
          command: 'Detect Power Plan',
          script: detectPowerPlanScript,
          requireAdmin: false
        }];
        
        const results = await window.electronAPI.executePowerShell(commands);
        if (results && results[0]?.success && results[0]?.output) {
          const detectedPlan = results[0].output.trim();
          console.log('[PerformancePage] Detected power plan:', detectedPlan);
          if (['economy', 'normal', 'performance'].includes(detectedPlan)) {
            setPowerMode(detectedPlan);
          }
        }
      }
    } catch (error) {
      console.error('[PerformancePage] Error loading real states:', error);
    } finally {
      setIsLoadingInitialStates(false);
    }
  };

  /**
   * Charge l'état réel des paramètres Windows via le nouveau système readSetting
   * Lit les paramètres individuellement et met à jour le state
   */
  const loadRealSettingsStates = async () => {
    if (!window.electronAPI?.readSetting) {
      console.log('[PerformancePage] readSetting API not available');
      return;
    }

    console.log('[PerformancePage] Loading real settings states...');

    // Charger tous les powerOptions qui ont un ID
    const settingsToLoad = powerOptionsState
      .filter(opt => opt.id) // Seulement ceux qui ont un ID
      .map(opt => opt.id);

    console.log('[PerformancePage] Settings to load:', settingsToLoad);

    // Lire chaque paramètre
    for (const settingId of settingsToLoad) {
      try {
        const value = await window.electronAPI.readSetting(settingId);
        
        if (value !== null && value !== undefined) {
          console.log(`[PerformancePage] ${settingId} = ${value}`);
          
          // Mettre à jour le state
          setPowerOptionsState(prev => 
            prev.map(opt => 
              opt.id === settingId 
                ? { ...opt, enabled: value === true || value === 1 }
                : opt
            )
          );
        }
      } catch (error) {
        console.error(`[PerformancePage] Error reading ${settingId}:`, error);
      }
    }

    console.log('[PerformancePage] ✓ Real settings states loaded');
  };

  // Load Fortnite config on mount
  useEffect(() => {
    if (selectedProfile === 'fortnite') {
      loadFortniteConfig();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedProfile]);

  // Load real Windows settings via PowerShell
  const loadRealSystemSettings = async () => {
    if (!isElectron || !window.electronAPI?.executePowerShell) return;

    setIsDetectingSettings(true);
    setSettingsDetected(false);

    try {
      // Script PowerShell pour détecter l'état réel des paramètres
      const detectScript = `
$results = @{}

# ========== GAMING OPTIONS ==========

# Game Mode (game-mode)
try {
  $gameMode = Get-ItemProperty -Path "HKCU:\\Software\\Microsoft\\GameBar" -Name "AutoGameModeEnabled" -ErrorAction SilentlyContinue
  $results["game-mode"] = if ($gameMode.AutoGameModeEnabled -eq 1) { "true" } else { "false" }
} catch { $results["game-mode"] = "true" }

# Hardware-Accelerated GPU Scheduling (hardware-acceleration)
try {
  $hags = Get-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers" -Name "HwSchMode" -ErrorAction SilentlyContinue
  $results["hardware-acceleration"] = if ($hags.HwSchMode -eq 2) { "true" } else { "false" }
} catch { $results["hardware-acceleration"] = "false" }

# Game DVR (game-dvr) - Note: enabled in UI means DVR is DISABLED
try {
  $gameDVR = Get-ItemProperty -Path "HKCU:\\System\\GameConfigStore" -Name "GameDVR_Enabled" -ErrorAction SilentlyContinue
  $results["game-dvr"] = if ($gameDVR.GameDVR_Enabled -eq 0) { "true" } else { "false" }
} catch { $results["game-dvr"] = "false" }

# Fullscreen Optimization (fullscreen-optimization) - enabled means FSO is DISABLED
try {
  $fso = Get-ItemProperty -Path "HKCU:\\System\\GameConfigStore" -Name "GameDVR_FSEBehaviorMode" -ErrorAction SilentlyContinue
  $results["fullscreen-optimization"] = if ($fso.GameDVR_FSEBehaviorMode -eq 2) { "true" } else { "false" }
} catch { $results["fullscreen-optimization"] = "false" }

# GPU Timeout (gpu-timeout)
try {
  $tdr = Get-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers" -Name "TdrLevel" -ErrorAction SilentlyContinue
  $results["gpu-timeout"] = if ($tdr.TdrLevel -eq 0) { "true" } else { "false" }
} catch { $results["gpu-timeout"] = "false" }

# Mouse Acceleration (mouse-acceleration) - enabled means acceleration is DISABLED
try {
  $mouse = Get-ItemProperty -Path "HKCU:\\Control Panel\\Mouse" -Name "MouseSpeed" -ErrorAction SilentlyContinue
  $results["mouse-acceleration"] = if ($mouse.MouseSpeed -eq "0") { "true" } else { "false" }
} catch { $results["mouse-acceleration"] = "false" }

# Priority Separation (priority-separation)
try {
  $priority = Get-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\PriorityControl" -Name "Win32PrioritySeparation" -ErrorAction SilentlyContinue
  $results["priority-separation"] = if ($priority.Win32PrioritySeparation -eq 38) { "true" } else { "false" }
} catch { $results["priority-separation"] = "false" }

# Nagle Algorithm (nagle-algorithm) - Check first network adapter
try {
  $adapters = Get-ChildItem "HKLM:\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces" -ErrorAction SilentlyContinue
  $nagleDisabled = $false
  foreach ($adapter in $adapters) {
    $tcpNoDelay = Get-ItemProperty -Path $adapter.PSPath -Name "TcpNoDelay" -ErrorAction SilentlyContinue
    if ($tcpNoDelay.TcpNoDelay -eq 1) { $nagleDisabled = $true; break }
  }
  $results["nagle-algorithm"] = if ($nagleDisabled) { "true" } else { "false" }
} catch { $results["nagle-algorithm"] = "false" }

# ========== POWER OPTIONS ==========

# Hibernation (hibernate-enabled)
try {
  $hibernate = powercfg /a 2>&1
  $results["hibernate-enabled"] = if ($hibernate -match "Hibernation has not been enabled") { "false" } else { "true" }
} catch { $results["hibernate-enabled"] = "false" }

# Fast Startup (fast-startup)
try {
  $fastStartup = Get-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Power" -Name "HiberbootEnabled" -ErrorAction SilentlyContinue
  $results["fast-startup"] = if ($fastStartup.HiberbootEnabled -eq 1) { "true" } else { "false" }
} catch { $results["fast-startup"] = "true" }

# USB Selective Suspend (usb-selective-suspend)
try {
  $usbSuspend = powercfg /query scheme_current 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 2>&1
  $results["usb-selective-suspend"] = if ($usbSuspend -match "Current AC Power Setting Index:\\s*0x00000001") { "true" } else { "false" }
} catch { $results["usb-selective-suspend"] = "true" }

# Current Power Plan (power-plan)
try {
  $activePlan = powercfg /getactivescheme
  if ($activePlan -match "a1841308-3541-4fab-bc81-f71556f20b4a") {
    $results["power-plan"] = "economy"
  } elseif ($activePlan -match "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c") {
    $results["power-plan"] = "performance"
  } else {
    $results["power-plan"] = "normal"
  }
} catch { $results["power-plan"] = "normal" }

# Screen timeout in minutes (screen-timeout)
try {
  $screenTimeout = powercfg /query scheme_current sub_video VIDEOIDLE 2>&1
  if ($screenTimeout -match "Current AC Power Setting Index:\\s*0x([0-9a-fA-F]+)") {
    $seconds = [Convert]::ToInt32($Matches[1], 16)
    $results["screen-timeout"] = [math]::Round($seconds / 60)
  } else { $results["screen-timeout"] = 15 }
} catch { $results["screen-timeout"] = 15 }

# Sleep timeout in minutes (sleep-timeout)
try {
  $sleepTimeout = powercfg /query scheme_current sub_sleep STANDBYIDLE 2>&1
  if ($sleepTimeout -match "Current AC Power Setting Index:\\s*0x([0-9a-fA-F]+)") {
    $seconds = [Convert]::ToInt32($Matches[1], 16)
    $results["sleep-timeout"] = [math]::Round($seconds / 60)
  } else { $results["sleep-timeout"] = 30 }
} catch { $results["sleep-timeout"] = 30 }

# Disk timeout in minutes (disk-timeout)
try {
  $diskTimeout = powercfg /query scheme_current sub_disk DISKIDLE 2>&1
  if ($diskTimeout -match "Current AC Power Setting Index:\\s*0x([0-9a-fA-F]+)") {
    $seconds = [Convert]::ToInt32($Matches[1], 16)
    $results["disk-timeout"] = [math]::Round($seconds / 60)
  } else { $results["disk-timeout"] = 20 }
} catch { $results["disk-timeout"] = 20 }

# CPU minimum state (cpu-power-management)
try {
  $cpuMin = powercfg /query scheme_current sub_processor PROCTHROTTLEMIN 2>&1
  if ($cpuMin -match "Current AC Power Setting Index:\\s*0x([0-9a-fA-F]+)") {
    $percent = [Convert]::ToInt32($Matches[1], 16)
    $results["cpu-power-management"] = $percent.ToString()
  } else { $results["cpu-power-management"] = "5" }
} catch { $results["cpu-power-management"] = "5" }

# PCIe Power Management (pcie-power-management)
try {
  $pcie = powercfg /query scheme_current 501a4d13-42af-4429-9fd1-a8218c268e20 ee12f906-d277-404b-b6da-e5fa1a576df5 2>&1
  if ($pcie -match "Current AC Power Setting Index:\\s*0x([0-9a-fA-F]+)") {
    $results["pcie-power-management"] = [Convert]::ToInt32($Matches[1], 16).ToString()
  } else { $results["pcie-power-management"] = "0" }
} catch { $results["pcie-power-management"] = "0" }

# Output as JSON
$results | ConvertTo-Json -Compress
`;

      const commands = [{
        command: 'Detect system settings',
        script: detectScript,
        requireAdmin: false
      }];

      const results = await window.electronAPI.executePowerShell(commands);
      
      if (results && results[0] && results[0].success && results[0].output) {
        try {
          const settings = JSON.parse(results[0].output);
          console.log('Detected system settings:', settings);
          
          // Update Gaming options state
          setGamingOptionsState(prev => prev.map(opt => {
            const detectedValue = settings[opt.id];
            if (detectedValue === 'true') {
              return { ...opt, enabled: true };
            } else if (detectedValue === 'false') {
              return { ...opt, enabled: false };
            }
            return opt;
          }));

          // Update Power options state
          setPowerOptionsState(prev => prev.map(opt => {
            if (opt.type === 'toggle') {
              const detectedValue = settings[opt.id];
              if (detectedValue === 'true') {
                return { ...opt, enabled: true };
              } else if (detectedValue === 'false') {
                return { ...opt, enabled: false };
              }
            } else if (opt.type === 'time') {
              const detectedValue = settings[opt.id];
              if (detectedValue !== undefined && !isNaN(parseInt(detectedValue))) {
                return { ...opt, value: parseInt(detectedValue) };
              }
            } else if (opt.type === 'select') {
              const detectedValue = settings[opt.id];
              if (detectedValue !== undefined) {
                return { ...opt, value: detectedValue };
              }
            }
            return opt;
          }));

          // Update Power mode
          if (settings['power-plan']) {
            setPowerMode(settings['power-plan']);
          }

          setSettingsDetected(true);
          setLastDetectionTime(new Date());
          addToast(t('notifications.systemSettings.detected'), 'success');
        } catch (parseError) {
          console.error('Error parsing settings:', parseError);
          addToast(t('notifications.systemSettings.error'), 'warning');
        }
      }
    } catch (error) {
      console.error('Error detecting system settings:', error);
      addToast(t('notifications.systemSettings.detectionError'), 'error');
    } finally {
      setIsDetectingSettings(false);
    }
  };

  const [isLoadingFortniteSettings, setIsLoadingFortniteSettings] = useState(false);

  const loadFortniteConfig = async () => {
    setIsLoadingFortniteSettings(true);
    
    // Utiliser le nouveau handler identifyFortniteSettings
    if (isElectron && window.electronAPI?.identifyFortniteSettings) {
      try {
        const result = await window.electronAPI.identifyFortniteSettings();
        if (result.success && result.settings) {
          const settings = result.settings;
          setFortniteSettings({
            graphicsAPI: settings.graphicsAPI || 'DX11',
            resolutionX: settings.resolutionX || 1920,
            resolutionY: settings.resolutionY || 1080,
            frameRateLimit: settings.frameRateLimit || 240,
            textures: settings.textures || 0,
            viewDistance: settings.viewDistance || 1
          });
          addToast(t('notifications.fortnite.loaded'), 'success');
          setIsLoadingFortniteSettings(false);
          return;
        }
      } catch (error) {
        console.error('Error identifying Fortnite settings:', error);
      }
    }
    
    // Fallback: try Electron readFortniteConfig
    if (isElectron && window.electronAPI?.readFortniteConfig) {
      try {
        const result = await window.electronAPI.readFortniteConfig();
        if (result.success && result.content) {
          const config = parseFortniteIni(result.content);
          setFortniteSettings(prev => ({
            ...prev,
            ...config
          }));
          addToast(t('notifications.fortnite.configLoaded'), 'success');
          setIsLoadingFortniteSettings(false);
          return;
        }
      } catch (error) {
        console.error('Error reading Fortnite config:', error);
      }
    }

    // Fallback: try backend API
    try {
      const response = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/fortnite-config`);
      const data = await response.json();
      if (data.success && data.config) {
        setFortniteSettings({
          graphicsAPI: 'DX11',
          resolutionX: data.config.resolutionX || 1920,
          resolutionY: data.config.resolutionY || 1080,
          frameRateLimit: data.config.frameRateLimit || 240,
          textures: data.config.textures || 0,
          viewDistance: data.config.viewDistance || 1
        });
      }
    } catch (error) {
      console.error('Error loading Fortnite config:', error);
    }
    
    setIsLoadingFortniteSettings(false);
  };

  // Parse Fortnite INI file content
  const parseFortniteIni = (content) => {
    const config = {};
    const lines = content.split('\n');
    
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('[') || trimmed.startsWith(';')) continue;
      
      const [key, value] = trimmed.split('=');
      if (!key || value === undefined) continue;
      
      switch (key.trim()) {
        case 'ResolutionSizeX':
          config.resolutionX = parseInt(value) || 1920;
          break;
        case 'ResolutionSizeY':
          config.resolutionY = parseInt(value) || 1080;
          break;
        case 'FullscreenMode':
          config.windowMode = parseInt(value) || 0;
          break;
        case 'FrameRateLimit':
          config.frameRateLimit = parseFloat(value) || 120;
          break;
        case 'sg.ShadowQuality':
          config.shadows = parseInt(value) || 0;
          break;
        case 'sg.TextureQuality':
          config.textures = parseInt(value) || 0;
          break;
        case 'sg.EffectsQuality':
          config.effects = parseInt(value) || 0;
          break;
        case 'sg.AntiAliasingQuality':
          config.antiAliasing = parseInt(value) || 0;
          break;
        case 'sg.ViewDistanceQuality':
          config.viewDistance = parseInt(value) || 1;
          break;
        case 'sg.PostProcessQuality':
          config.postProcessing = parseInt(value) || 0;
          break;
      }
    }
    
    return config;
  };

  // Toggle function for power options (type: toggle)
  const togglePowerOption = async (optionId) => {
    const optionIndex = powerOptionsState.findIndex(o => o.id === optionId);
    if (optionIndex === -1) return;
    
    const option = powerOptionsState[optionIndex];
    if (option.type !== 'toggle') return;

    const newEnabled = !option.enabled;
    const command = newEnabled ? option.enableCommand : option.disableCommand;

    // Update state first for immediate UI feedback
    setPowerOptionsState(prev => {
      const newState = [...prev];
      newState[optionIndex] = { ...newState[optionIndex], enabled: newEnabled };
      return newState;
    });

    // Execute command
    await executePowerShellCommand(command);
    
    addToast(`${option.title} ${newEnabled ? t('notifications.fortnite.activated') : t('notifications.fortnite.deactivated')}`, 'success');
    
    // Re-read the real state from Windows after execution
    if (window.electronAPI?.readSetting && optionId) {
      try {
        // Wait a bit for Windows to apply the change
        setTimeout(async () => {
          const realValue = await window.electronAPI.readSetting(optionId);
          
          if (realValue !== null && realValue !== undefined) {
            console.log(`[PerformancePage] Re-read ${optionId} after toggle: ${realValue}`);
            
            // Update state with real value from Windows
            setPowerOptionsState(prev => 
              prev.map(opt => 
                opt.id === optionId 
                  ? { ...opt, enabled: realValue === true || realValue === 1 }
                  : opt
              )
            );
          }
        }, 500); // Wait 500ms for Windows to apply the change
      } catch (error) {
        console.error(`[PerformancePage] Error re-reading ${optionId}:`, error);
      }
    }
  };

  // Update time value for power options (type: time)
  const updateTimeOption = async (optionId, minutes) => {
    const option = powerOptionsState.find(o => o.id === optionId);
    if (!option || option.type !== 'time') return;

    const value = parseInt(minutes) || 0;
    const command = option.getCommand(value);

    // Execute command
    await executePowerShellCommand(command);

    // Update state
    setPowerOptionsState(prev => prev.map(opt =>
      opt.id === optionId ? { ...opt, value } : opt
    ));

    addToast(`${option.title}: ${value} ${option.unit}`, 'success');
  };

  // Update select value for power options (type: select)
  const updateSelectOption = async (optionId, value) => {
    const option = powerOptionsState.find(o => o.id === optionId);
    if (!option || option.type !== 'select') return;

    const command = option.getCommand(value);

    // Execute command
    await executePowerShellCommand(command);

    // Update state
    setPowerOptionsState(prev => prev.map(opt =>
      opt.id === optionId ? { ...opt, value } : opt
    ));

    const selectedLabel = option.options.find(o => o.value === value)?.label || value;
    addToast(`${option.title}: ${selectedLabel}`, 'success');
  };

  // Execute PowerShell command
  const executePowerShellCommand = async (script) => {
    if (isElectron && window.electronAPI?.executePowerShell) {
      try {
        // L'API attend un tableau d'objets {command, script, requireAdmin}
        const commands = [{
          command: script,
          script: script,
          requireAdmin: true
        }];
        const results = await window.electronAPI.executePowerShell(commands);
        
        // Vérifier le résultat
        if (results && results[0] && !results[0].success) {
          console.error('Erreur PowerShell:', results[0].error);
          addToast(t('notifications.generic.error') + ': ' + (results[0].error || t('notifications.generic.commandFailed')), 'error');
        }
        return results;
      } catch (error) {
        console.error('Erreur exécution commande:', error);
        addToast(t('notifications.generic.executionError'), 'error');
      }
    } else {
      // Mode web: copier dans le presse-papier
      try {
        await navigator.clipboard.writeText(script);
        addToast(t('notifications.generic.commandCopied'), 'info');
      } catch (err) {
        console.error('Erreur copie presse-papier:', err);
      }
    }
  };

  // Toggle function for gaming options
  const toggleGamingOption = async (optionId) => {
    const optionIndex = gamingOptionsState.findIndex(o => o.id === optionId);
    if (optionIndex === -1) return;
    
    const option = gamingOptionsState[optionIndex];
    const newEnabled = !option.enabled;
    const commands = newEnabled ? option.enableCommands : option.disableCommands;

    // Update state first for immediate UI feedback
    setGamingOptionsState(prev => {
      const newState = [...prev];
      newState[optionIndex] = { ...newState[optionIndex], enabled: newEnabled };
      return newState;
    });

    // Execute commands
    if (commands?.powershell) {
      for (const cmd of commands.powershell) {
        await executePowerShellCommand(cmd.script);
      }
    }

    addToast(`${option.title} ${newEnabled ? t('notifications.fortnite.activated') : t('notifications.fortnite.deactivated')}`, 'success');
  };

  // Execute commands for an option (legacy - pour compatibilité)
  const executeOptionCommands = async (option, isEnabled) => {
    const commands = isEnabled ? option.enableCommands : option.disableCommands;
    
    if (!commands || !commands.powershell) return;

    for (const cmd of commands.powershell) {
      await executePowerShellCommand(cmd.script);
    }
  };

  // Execute power mode change
  const executePowerModeChange = async (mode) => {
    const selectedMode = powerModes.find(m => m.value === mode);
    if (!selectedMode?.commands?.powershell) return;

    await executePowerShellCommand(selectedMode.commands.powershell[0].script);
  };

  // Handle GPU selection
  const handleGpuSelection = (gpuType) => {
    setSelectedGpu(gpuType);
    addToast(t('notifications.obs.gpuSelected').replace('{{gpu}}', gpuType.toUpperCase()), 'success');
  };

  // OBS config files content
  const obsConfigFiles = {
    nvidia: {
      'basic.ini': `[General]
Name=nvidia

[Output]
Mode=Advanced
FilenameFormatting=%CCYY-%MM-%DD %hh-%mm-%ss

[AdvOut]
ApplyServiceSettings=true
Encoder=obs_nvenc_h264_tex
RecType=Standard
RecFilePath=C:%USERPROFILE%\\Videos
RecFormat2=hybrid_mp4
RecTracks=1
AudioEncoder=ffmpeg_aac
RecAudioEncoder=ffmpeg_aac

[Video]
BaseCX=1920
BaseCY=1080
OutputCX=1920
OutputCY=1080
FPSCommon=60
ScaleType=bicubic
ColorFormat=NV12
ColorSpace=709
ColorRange=Partial

[Audio]
SampleRate=48000
ChannelSetup=Stereo`,
      'recordEncoder.json': JSON.stringify({
        "encoder": "jim_nvenc",
        "rate_control": "CBR",
        "bitrate": 6000,
        "preset": "p5",
        "profile": "high",
        "gpu": 0,
        "bf": 2,
        "psycho_aq": true,
        "lookahead": false,
        "repeat_headers": true
      }, null, 2),
      'streamEncoder.json': JSON.stringify({
        "encoder": "jim_nvenc",
        "rate_control": "CBR",
        "bitrate": 6000,
        "preset": "p5",
        "profile": "high",
        "gpu": 0,
        "bf": 2,
        "psycho_aq": true,
        "lookahead": false,
        "keyint_sec": 2,
        "repeat_headers": true
      }, null, 2)
    },
    amd: {
      'basic.ini': `[General]
Name=amd

[Output]
Mode=Advanced
FilenameFormatting=%CCYY-%MM-%DD %hh-%mm-%ss

[AdvOut]
ApplyServiceSettings=true
Encoder=amd_amf_h264
RecType=Standard
RecFilePath=C:%USERPROFILE%\\Videos
RecFormat2=hybrid_mp4
RecTracks=1
AudioEncoder=ffmpeg_aac
RecAudioEncoder=ffmpeg_aac

[Video]
BaseCX=1920
BaseCY=1080
OutputCX=1920
OutputCY=1080
FPSCommon=60
ScaleType=bicubic
ColorFormat=NV12
ColorSpace=709
ColorRange=Partial

[Audio]
SampleRate=48000
ChannelSetup=Stereo`,
      'recordEncoder.json': JSON.stringify({
        "encoder": "amd_amf_h264",
        "rate_control": "CBR",
        "bitrate": 6000,
        "preset": "quality",
        "profile": "high",
        "bf": 0,
        "qvbr_quality_level": 0,
        "filler_data": false,
        "vbaq": true,
        "enforce_hrd": false
      }, null, 2),
      'streamEncoder.json': JSON.stringify({
        "encoder": "amd_amf_h264",
        "rate_control": "CBR",
        "bitrate": 6000,
        "preset": "quality",
        "profile": "high",
        "bf": 0,
        "qvbr_quality_level": 0,
        "keyint_sec": 2,
        "vbaq": true,
        "enforce_hrd": false
      }, null, 2)
    }
  };

  // Apply OBS profile
  const applyObsProfile = async () => {
    if (!selectedGpu) {
      addToast(t('notifications.obs.selectGpu'), 'error');
      return;
    }

    try {
      // Option 1: Si Electron est disponible, utiliser l'API Electron
      if (isElectron && window.electronAPI?.applyObsProfile) {
        const result = await window.electronAPI.applyObsProfile(selectedGpu.toUpperCase());
        
        if (result.success) {
          // Afficher un seul message de succès avec toutes les infos
          const filesInfo = result.filesCreated && result.filesCreated.length > 0 
            ? `\n📁 ${result.filesCreated.length} fichiers copiés\n🎥 Ouvrez OBS et sélectionnez "BabaTool"`
            : '\n🎥 Ouvrez OBS et sélectionnez "BabaTool"';
          addToast(`✅ ${result.message}${filesInfo}`, 'success');
        } else {
          addToast(`❌ ${result.error}`, 'error');
        }
        return;
      }

      // Option 2: Fallback vers l'API backend (mode web)
      const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
      const response = await fetch(`${BACKEND_URL}/api/apply-obs-profile`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gpuType: selectedGpu.toUpperCase() })
      });
      
      const result = await response.json();
      
      if (result.success) {
        // Afficher un seul message de succès avec toutes les infos
        const filesInfo = result.files_copied && result.files_copied.length > 0 
          ? `\n📁 ${result.files_copied.length} fichiers copiés\n🎥 Ouvrez OBS et sélectionnez "BabaTool"`
          : '\n🎥 Ouvrez OBS et sélectionnez "BabaTool"';
        addToast(`✅ Profil OBS ${selectedGpu.toUpperCase()} appliqué!${filesInfo}`, 'success');
      } else {
        addToast(`❌ ${result.message}`, 'error');
      }
    } catch (error) {
      console.error('Erreur lors de l\'application du profil OBS:', error);
      addToast(`❌ Erreur: ${error.message}`, 'error');
    }
  };

  // Fallback: Download as ZIP
  const downloadObsProfileAsZip = async () => {
    if (!selectedGpu) return;

    try {
      const JSZip = (await import('jszip')).default;
      const zip = new JSZip();

      const files = obsConfigFiles[selectedGpu];
      Object.entries(files).forEach(([filename, content]) => {
        zip.file(filename, content);
      });

      const zipBlob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(zipBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `BabaToolbox_${selectedGpu.toUpperCase()}_Profile.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      addToast(`📥 Profil OBS téléchargé (3 fichiers)`, 'success');
      addToast('📂 Extrayez dans: %APPDATA%\\obs-studio\\basic\\profiles\\', 'info');
    } catch (error) {
      console.error('Erreur création ZIP:', error);
      addToast(`❌ Erreur: ${error.message}`, 'error');
    }
  };

  // Handle Fortnite setting change
  const handleFortniteSettingChange = (key, value) => {
    setFortniteSettings(prev => ({ ...prev, [key]: value }));
  };

  // Handle custom resolution change
  const handleCustomResolutionChange = (value) => {
    setFortniteSettings(prev => ({ ...prev, customResolution: value }));
    
    // Parse resolution if valid format
    const match = value.match(/^(\d+)x(\d+)$/);
    if (match) {
      setFortniteSettings(prev => ({
        ...prev,
        resolutionX: parseInt(match[1]),
        resolutionY: parseInt(match[2])
      }));
    }
  };

  // Generate Fortnite config content - Full GameUserSettings.ini
  const generateFortniteConfigContent = () => {
    return `[/Script/FortniteGame.FortGameUserSettings]
FullscreenMode=${fortniteSettings.windowMode}
bMotionBlur=False
bShowGrass=False
bShowFPS=True
bUseVSync=False
bUseDynamicResolution=False
ResolutionSizeX=${fortniteSettings.resolutionX}
ResolutionSizeY=${fortniteSettings.resolutionY}
LastUserConfirmedResolutionSizeX=${fortniteSettings.resolutionX}
LastUserConfirmedResolutionSizeY=${fortniteSettings.resolutionY}
LastConfirmedFullscreenMode=${fortniteSettings.windowMode}
PreferredFullscreenMode=${fortniteSettings.windowMode}
FrameRateLimit=${fortniteSettings.frameRateLimit.toFixed(6)}
FrontendFrameRateLimit=120.000000
LowInputLatencyModeIsEnabled=True
bDisableMouseAcceleration=True
bUseHDRDisplayOutput=False
AudioQualityLevel=1
LastConfirmedAudioQualityLevel=1
DesiredScreenWidth=${fortniteSettings.resolutionX}
DesiredScreenHeight=${fortniteSettings.resolutionY}
LastUserConfirmedDesiredScreenWidth=${fortniteSettings.resolutionX}
LastUserConfirmedDesiredScreenHeight=${fortniteSettings.resolutionY}

[ScalabilityGroups]
sg.ResolutionQuality=100
sg.ViewDistanceQuality=${fortniteSettings.viewDistance}
sg.AntiAliasingQuality=${fortniteSettings.antiAliasing}
sg.ShadowQuality=${fortniteSettings.shadows}
sg.GlobalIlluminationQuality=0
sg.ReflectionQuality=0
sg.PostProcessQuality=${fortniteSettings.postProcessing}
sg.TextureQuality=${fortniteSettings.textures}
sg.EffectsQuality=${fortniteSettings.effects}
sg.FoliageQuality=0
sg.ShadingQuality=0
sg.LandscapeQuality=0

[D3DRHIPreference]
PreferredRHI=dx11
PreferredFeatureLevel=es31
`;
  };

  // Read and merge with existing Fortnite config
  const readAndMergeFortniteConfig = async () => {
    if (isElectron && window.electronAPI?.readFortniteConfig) {
      try {
        const result = await window.electronAPI.readFortniteConfig();
        if (result.success && result.content) {
          // Parse existing config and merge with new settings
          const existingContent = result.content;
          return mergeIniContent(existingContent, generateFortniteConfigContent());
        }
      } catch (error) {
        console.error('Error reading existing config:', error);
      }
    }
    return generateFortniteConfigContent();
  };

  // Merge two INI contents, preferring new values for matching keys
  const mergeIniContent = (existingContent, newContent) => {
    const existingLines = existingContent.split('\n');
    const newLines = newContent.split('\n');
    
    // Parse new content into sections and key-value pairs
    const newSections = {};
    let currentSection = '';
    
    for (const line of newLines) {
      const trimmed = line.trim();
      if (trimmed.startsWith('[') && trimmed.endsWith(']')) {
        currentSection = trimmed;
        if (!newSections[currentSection]) newSections[currentSection] = {};
      } else if (trimmed && trimmed.includes('=')) {
        const [key] = trimmed.split('=');
        newSections[currentSection] = newSections[currentSection] || {};
        newSections[currentSection][key] = trimmed;
      }
    }
    
    // Merge with existing content
    const result = [];
    currentSection = '';
    const processedKeys = new Set();
    
    for (const line of existingLines) {
      const trimmed = line.trim();
      
      if (trimmed.startsWith('[') && trimmed.endsWith(']')) {
        // Before switching sections, add any new keys for current section
        if (currentSection && newSections[currentSection]) {
          for (const [key, value] of Object.entries(newSections[currentSection])) {
            if (!processedKeys.has(`${currentSection}:${key}`)) {
              result.push(value);
            }
          }
        }
        
        currentSection = trimmed;
        processedKeys.clear();
        result.push(line);
      } else if (trimmed && trimmed.includes('=')) {
        const [key] = trimmed.split('=');
        
        // Check if we have a new value for this key
        if (newSections[currentSection] && newSections[currentSection][key]) {
          result.push(newSections[currentSection][key]);
          processedKeys.add(`${currentSection}:${key}`);
        } else {
          result.push(line);
        }
      } else {
        result.push(line);
      }
    }
    
    // Add any remaining new sections not in existing content
    for (const [section, keys] of Object.entries(newSections)) {
      if (!existingLines.some(l => l.trim() === section)) {
        result.push('');
        result.push(section);
        for (const value of Object.values(keys)) {
          result.push(value);
        }
      }
    }
    
    return result.join('\n');
  };

  // Apply Fortnite config
  const applyFortniteConfig = async () => {
    // Option 1: Electron avec PowerShell (PRIORITAIRE)
    if (isElectron && window.electronAPI?.applyFortniteConfigPS) {
      try {
        // Préparer les paramètres pour le script PowerShell Fotnite.ps1
        const params = {};
        
        // GraphicsAPI (DX11, DX12, Performance, OldPerformance)
        if (fortniteSettings.graphicsAPI) {
          params.graphicsAPI = fortniteSettings.graphicsAPI;
        }
        
        // Resolution
        if (fortniteSettings.resolutionX) {
          params.resolutionX = fortniteSettings.resolutionX;
        }
        if (fortniteSettings.resolutionY) {
          params.resolutionY = fortniteSettings.resolutionY;
        }
        
        // FPS Limit
        if (fortniteSettings.frameRateLimit !== undefined) {
          params.fpsLimit = fortniteSettings.frameRateLimit;
        }
        
        // Textures (0-3 -> Low/Medium/High/Epic)
        if (fortniteSettings.textures !== undefined) {
          const textureMap = ['Low', 'Medium', 'High', 'Epic'];
          params.textures = textureMap[fortniteSettings.textures] || 'Low';
        }
        
        // ViewDistance (0-3 -> Low/Medium/High/Epic)
        if (fortniteSettings.viewDistance !== undefined) {
          const viewMap = ['Low', 'Medium', 'High', 'Epic'];
          params.viewDistance = viewMap[fortniteSettings.viewDistance] || 'Low';
        }
        
        // Appeler le script PowerShell
        const result = await window.electronAPI.applyFortniteConfigPS(params);
        
        if (result.success) {
          addToast('✅ Configuration Fortnite appliquée avec succès!', 'success');
          if (result.output) {
            console.log('PowerShell output:', result.output);
          }
          return;
        } else {
          addToast(`❌ Erreur: ${result.error}`, 'error');
          if (result.output) {
            console.error('PowerShell output:', result.output);
          }
        }
      } catch (error) {
        console.error('Electron PowerShell error:', error);
        addToast(`❌ Erreur: ${error.message}`, 'error');
      }
    } 
    // Option 2: Electron avec ancien système (FALLBACK)
    else if (isElectron && window.electronAPI?.applyFortniteConfig) {
      try {
        // First try to read and merge with existing config
        let configContent;
        if (window.electronAPI?.readFortniteConfig) {
          const existingResult = await window.electronAPI.readFortniteConfig();
          if (existingResult.success && existingResult.content) {
            // Merge with existing config to preserve user settings
            configContent = mergeIniContent(existingResult.content, generateFortniteConfigContent());
            addToast('📖 Configuration existante lue et fusionnée', 'info');
          } else {
            // No existing config, use generated one
            configContent = generateFortniteConfigContent();
          }
        } else {
          configContent = generateFortniteConfigContent();
        }

        const result = await window.electronAPI.applyFortniteConfig({ configContent });
        if (result.success) {
          addToast(`✅ ${result.message}`, 'success');
          if (result.fortniteConfigFile) {
            addToast(`🎯 Fichier: ${result.fortniteConfigFile}`, 'success');
          }
          return;
        } else {
          addToast(`❌ ${result.error}`, 'error');
        }
      } catch (error) {
        console.error('Electron API error:', error);
        addToast(`❌ Erreur: ${error.message}`, 'error');
      }
    } 
    // Option 3: Mode Web - Backend API (DERNIER RECOURS)
    else {
      await saveToAppConfig();
      addToast('📂 Configuration sauvegardée dans l\'application', 'success');
      addToast('⚠️ Copiez manuellement vers le dossier Fortnite', 'info');
    }
  };

  // Save config to app's folder via backend
  const saveToAppConfig = async () => {
    try {
      await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/apply-fortnite-config`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          resolutionX: fortniteSettings.resolutionX,
          resolutionY: fortniteSettings.resolutionY,
          windowMode: fortniteSettings.windowMode,
          frameRateLimit: fortniteSettings.frameRateLimit,
          shadows: fortniteSettings.shadows,
          textures: fortniteSettings.textures,
          effects: fortniteSettings.effects,
          antiAliasing: fortniteSettings.antiAliasing,
          viewDistance: fortniteSettings.viewDistance,
          postProcessing: fortniteSettings.postProcessing
        })
      });
    } catch (error) {
      console.error('Backend API error:', error);
    }
  };

  // Quality options for selects
  const qualityOptions = [
    { value: 0, label: 'Désactivé / Faible' },
    { value: 1, label: 'Moyen' },
    { value: 2, label: 'Élevé' },
    { value: 3, label: 'Épique' }
  ];

  const windowModeOptions = [
    { value: 0, label: 'Plein écran' },
    { value: 1, label: 'Fenêtré' },
    { value: 2, label: 'Fenêtré sans bordure' }
  ];

  const presetResolutions = [
    '1280x720',
    '1600x900',
    '1920x1080',
    '2560x1440',
    '3840x2160'
  ];

  return (
    <div className="space-y-6 exm-fade-in">
      {/* Loading state for initial settings load */}
      {isLoadingInitialStates && isElectron && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="bg-[#1a1a1a] border border-white/10 rounded-xl p-6 flex flex-col items-center gap-4">
            <Loader2 className="w-8 h-8 text-[#ff3333] animate-spin" />
            <div className="text-center">
              <p className="text-white font-medium">{t('common.loadingWindowsSettings')}</p>
              <p className="text-[#666] text-sm mt-1">{t('common.readingSystemState')}</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="exm-section-title">{t('performance.title')}</h1>
          <p className="exm-section-subtitle">{t('performance.subtitle')}</p>
        </div>
        {/* Refresh button and detection status - Only show in Electron */}
        {isElectron && (
          <div className="flex items-center gap-3">
            {/* Detection status badge */}
            {settingsDetected && !isLoadingInitialStates && (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-green-500/10 border border-green-500/20 rounded-lg">
                <CheckCircle2 className="w-4 h-4 text-green-500" />
                <span className="text-green-500 text-xs font-medium">{t('common.windowsStatesDetected')}</span>
              </div>
            )}
            <button
              onClick={loadAllRealStates}
              disabled={isDetectingSettings || isLoadingInitialStates}
              data-testid="refresh-settings-btn"
              className="exm-btn-secondary flex items-center gap-2 disabled:opacity-50"
              title={t('common.detectSettings')}
            >
              {isDetectingSettings || isLoadingInitialStates ? (
                <Loader2 className="w-4 h-4 animate-spin" strokeWidth={1.5} />
              ) : (
                <RefreshCw className="w-4 h-4" strokeWidth={1.5} />
              )}
              <span>{isDetectingSettings || isLoadingInitialStates ? t('common.detecting') : t('common.detectSettings')}</span>
            </button>
          </div>
        )}
      </div>

      {/* Info banner when settings detected */}
      {isElectron && settingsDetected && (
        <div className="bg-blue-500/5 border border-blue-500/20 rounded-xl p-4">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-blue-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-blue-400 text-sm font-medium">Synchronisation avec Windows</p>
              <p className="text-[#666] text-xs mt-1">
                Les paramètres affichés correspondent à l'état actuel de votre système Windows. 
                Modifiez-les ici ou dans les paramètres Windows, puis cliquez sur "Détecter les paramètres" pour synchroniser.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tabs - EXM Style */}
      <div className="exm-tabs">
        {profiles.map(profile => (
          <button
            key={profile.value}
            onClick={() => setSelectedProfile(profile.value)}
            data-testid={`profile-btn-${profile.value}`}
            className={`exm-tab ${selectedProfile === profile.value ? 'active' : ''}`}
          >
            {t(profile.labelKey)}
          </button>
        ))}
      </div>

      {/* Search and Filter Bar */}
      <div className="flex items-center gap-3">
        <div className="exm-search flex-1">
          <Search className="w-4 h-4" strokeWidth={1.5} />
          <input type="text" placeholder={t('common.search') + '...'} />
        </div>
        <button className="exm-btn-secondary flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4" strokeWidth={1.5} />
          <span>{t('common.filter')}</span>
        </button>
        <button className="exm-btn-secondary flex items-center gap-2">
          <ArrowUpDown className="w-4 h-4" strokeWidth={1.5} />
          <span>{t('common.sort')}</span>
        </button>
      </div>

      {/* Power Plan Section */}
      {selectedProfile === 'power' && (
        <div className="space-y-6">
          {/* Power Mode Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {powerModes.map(mode => (
              <div
                key={mode.value}
                onClick={() => {
                  setPowerMode(mode.value);
                  addToast(`Mode ${t(mode.labelKey)} ${t('common.enabled').toLowerCase()}`, 'success');
                  executePowerModeChange(mode.value);
                }}
                data-testid={`power-mode-${mode.value}`}
                className={`exm-card cursor-pointer ${
                  powerMode === mode.value ? 'border-[#ff3333] glow-pink' : ''
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{mode.icon}</span>
                    <h4 className={`font-semibold ${powerMode === mode.value ? 'text-[#ff3333]' : 'text-white'}`}>
                      {t(mode.labelKey)}
                    </h4>
                  </div>
                  {powerMode === mode.value && (
                    <span className="exm-badge exm-badge-warning">{t('common.active')}</span>
                  )}
                </div>
                <p className="text-[#666] text-sm mb-4">{t(mode.descriptionKey)}</p>
                <button className={`exm-btn-primary ${powerMode === mode.value ? '' : 'opacity-50'}`}>
                  {powerMode === mode.value ? t('common.enabled') : t('common.apply')}
                </button>
              </div>
            ))}
          </div>

          {/* Power Options - Only Hibernation and Fast Startup */}
          <div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {powerOptionsState.map(option => (
                <div key={option.id} className="exm-card">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h5 className="text-white font-medium text-sm">{t(option.titleKey)}</h5>
                        {option.requireAdmin && <span className="exm-badge exm-badge-warning">{t('common.admin')}</span>}
                        {settingsDetected && (
                          <span className="px-1.5 py-0.5 bg-green-500/10 text-green-500 text-[10px] rounded">
                            Windows
                          </span>
                        )}
                      </div>
                      <p className="text-[#555] text-xs">{t(option.descriptionKey)}</p>
                    </div>
                    
                    {/* Type: Toggle */}
                    {option.type === 'toggle' && (
                      <div
                        onClick={() => togglePowerOption(option.id)}
                        data-testid={`toggle-power-${option.id}`}
                        className={`exm-toggle ${option.enabled ? 'active' : ''}`}
                      >
                        <span className="thumb" />
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Gaming Section */}
      {selectedProfile === 'gaming' && (
        <div className="space-y-6 exm-fade-in">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-semibold flex items-center gap-2">
                <Gamepad2 className="w-5 h-5 text-[#ff3333]" strokeWidth={1.5} />
                {t('performance.gaming.title')}
              </h3>
              {settingsDetected && (
                <div className="flex items-center gap-2 text-xs text-green-500">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{t('common.windowsStatesDetected')}</span>
                </div>
              )}
            </div>
            
            {[...new Set(gamingOptionsState.map(o => t(o.categoryKey)))].map(category => (
              <div key={category} className="mb-6">
                <div className="text-xs font-medium tracking-wider uppercase text-[#666] mb-3">{category}</div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {gamingOptionsState.filter(o => t(o.categoryKey) === category).map(option => (
                    <div key={option.id} className={`exm-card ${settingsDetected ? 'border-green-500/10' : ''}`}>
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h5 className="text-white font-medium text-sm">{t(option.titleKey)}</h5>
                            {option.enableCommands?.powershell?.[0]?.requireAdmin && (
                              <span className="exm-badge exm-badge-warning">{t('common.admin')}</span>
                            )}
                            {settingsDetected && (
                              <span className="px-1.5 py-0.5 bg-green-500/10 text-green-500 text-[10px] rounded">
                                Windows
                              </span>
                            )}
                          </div>
                          <p className="text-[#555] text-xs">{t(option.descriptionKey)}</p>
                          {/* Status indicator */}
                          <div className="flex items-center gap-2 mt-2">
                            <span className={`text-xs font-medium ${option.enabled ? 'text-green-500' : 'text-red-400'}`}>
                              {option.enabled ? `● ${t('common.enabled')}` : `○ ${t('common.disabled')}`}
                            </span>
                            {settingsDetected && (
                              <span className="text-[#444] text-[10px]">Windows</span>
                            )}
                          </div>
                        </div>
                        <div
                          onClick={() => toggleGamingOption(option.id)}
                          data-testid={`toggle-gaming-${option.id}`}
                          className={`exm-toggle ${option.enabled ? 'active' : ''}`}
                        >
                          <span className="thumb" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Fortnite Section */}
      {selectedProfile === 'fortnite' && (
        <LockedFeature
          requiredLicense={LICENSE_TYPES.PREMIUM}
          isLocked={!checkFeatureAccess(FEATURE_CATEGORIES.PERFORMANCE_FORTNITE)}
          title="🎯 Configuration Fortnite - Premium"
          description="Optimisez automatiquement vos paramètres Fortnite pour des performances maximales. Disponible avec la licence Premium."
        >
        <div className="space-y-6 exm-fade-in">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-semibold flex items-center gap-2">
                <img src={`${process.env.PUBLIC_URL}/fortnite-icon.jpg`} alt="Fortnite" className="w-5 h-5 rounded" />
                {t('performance.fortnite.title')}
              </h3>
              <button
                onClick={loadFortniteConfig}
                disabled={isLoadingFortniteSettings}
                className="flex items-center gap-2 px-3 py-1.5 bg-[#1a1a1a] hover:bg-[#252525] border border-white/10 rounded-lg text-sm text-[#888] hover:text-white transition-all disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${isLoadingFortniteSettings ? 'animate-spin' : ''}`} />
                {isLoadingFortniteSettings ? t('performance.fortnite.loading') : t('performance.fortnite.refresh')}
              </button>
            </div>
            
            {/* Current Settings Display */}
            <div className="bg-[#0d0d0d] border border-white/5 rounded-xl p-4 mb-4">
              <div className="text-xs font-medium tracking-wider uppercase text-[#666] mb-3">{t('performance.fortnite.currentSettings')}</div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-[#666]">{t('performance.fortnite.api')}:</span>
                  <span className="text-white font-medium">{fortniteSettings.graphicsAPI}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#666]">{t('performance.fortnite.resolution')}:</span>
                  <span className="text-white font-medium">{fortniteSettings.resolutionX}×{fortniteSettings.resolutionY}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#666]">{t('performance.fortnite.fps')}:</span>
                  <span className="text-white font-medium">{fortniteSettings.frameRateLimit}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#666]">{t('performance.fortnite.textures')}:</span>
                  <span className="text-white font-medium">{[t('performance.fortnite.qualityLevels.low'), t('performance.fortnite.qualityLevels.medium'), t('performance.fortnite.qualityLevels.high'), t('performance.fortnite.qualityLevels.epic')][fortniteSettings.textures] || t('performance.fortnite.qualityLevels.low')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#666]">{t('performance.fortnite.distance')}:</span>
                  <span className="text-white font-medium">{[t('performance.fortnite.qualityLevels.low'), t('performance.fortnite.qualityLevels.medium'), t('performance.fortnite.qualityLevels.high'), t('performance.fortnite.qualityLevels.epic')][fortniteSettings.viewDistance] || t('performance.fortnite.qualityLevels.low')}</span>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* GraphicsAPI */}
              <div className="exm-card">
                <label className="exm-label">{t('performance.fortnite.graphicsMode')}</label>
                <CustomSelect
                  value={fortniteSettings.graphicsAPI || 'DX11'}
                  onChange={(value) => handleFortniteSettingChange('graphicsAPI', value)}
                  options={[
                    { value: 'DX11', label: t('performance.fortnite.graphicsApi.dx11') },
                    { value: 'DX12', label: t('performance.fortnite.graphicsApi.dx12') },
                    { value: 'Performance', label: t('performance.fortnite.graphicsApi.performance') },
                    { value: 'OldPerformance', label: t('performance.fortnite.graphicsApi.oldPerformance') }
                  ]}
                  className="w-full"
                />
              </div>
              
              {/* FPS Limit */}
              <div className="exm-card">
                <label className="exm-label">{t('performance.fortnite.fpsLimit')}</label>
                <input
                  type="number"
                  value={fortniteSettings.frameRateLimit}
                  onChange={(e) => handleFortniteSettingChange('frameRateLimit', parseInt(e.target.value) || 0)}
                  className="exm-input w-full"
                  min="0"
                  max="360"
                />
                <span className="text-[#666] text-xs mt-1 block">0 = {t('performance.fortnite.unlimited')}</span>
              </div>
              
              {/* Resolution - Manual Input */}
              <div className="exm-card">
                <label className="exm-label">{t('performance.fortnite.resolution')}</label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    value={fortniteSettings.resolutionX}
                    onChange={(e) => handleFortniteSettingChange('resolutionX', parseInt(e.target.value) || 1920)}
                    className="exm-input flex-1 text-center"
                    min="640"
                    max="7680"
                    placeholder="1920"
                  />
                  <span className="text-[#666] font-bold">×</span>
                  <input
                    type="number"
                    value={fortniteSettings.resolutionY}
                    onChange={(e) => handleFortniteSettingChange('resolutionY', parseInt(e.target.value) || 1080)}
                    className="exm-input flex-1 text-center"
                    min="360"
                    max="4320"
                    placeholder="1080"
                  />
                </div>
                <span className="text-[#666] text-xs mt-1 block">Ex: 1920×1080, 1600×900</span>
              </div>
              
              {/* Textures */}
              <div className="exm-card">
                <label className="exm-label">Textures</label>
                <CustomSelect
                  value={fortniteSettings.textures}
                  onChange={(value) => handleFortniteSettingChange('textures', parseInt(value))}
                  options={[
                    { value: 0, label: 'Low' },
                    { value: 1, label: 'Medium' },
                    { value: 2, label: 'High' },
                    { value: 3, label: 'Epic' }
                  ]}
                  className="w-full"
                />
              </div>
              
              {/* View Distance */}
              <div className="exm-card">
                <label className="exm-label">Distance de vue</label>
                <CustomSelect
                  value={fortniteSettings.viewDistance}
                  onChange={(value) => handleFortniteSettingChange('viewDistance', parseInt(value))}
                  options={[
                    { value: 0, label: 'Low' },
                    { value: 1, label: 'Medium' },
                    { value: 2, label: 'High' },
                    { value: 3, label: 'Epic' }
                  ]}
                  className="w-full"
                />
              </div>
            </div>
            
            {/* Apply Button */}
            <div className="mt-6">
              <button
                onClick={applyFortniteConfig}
                className="exm-btn-primary flex items-center justify-center gap-2"
              >
                <span>{t('performance.fortnite.applyConfig')}</span>
              </button>
            </div>
          </div>
        </div>
        </LockedFeature>
      )}

      {/* OBS Section */}
      {selectedProfile === 'obs' && (
        <LockedFeature
          requiredLicense={LICENSE_TYPES.PREMIUM}
          isLocked={!checkFeatureAccess(FEATURE_CATEGORIES.PERFORMANCE_OBS)}
          title="🎥 Configuration OBS - Premium"
          description="Appliquez automatiquement les meilleurs paramètres OBS selon votre GPU. Disponible avec la licence Premium."
        >
        <div className="space-y-6 exm-fade-in">
          <div>
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
              <img src={`${process.env.PUBLIC_URL}/obs-icon.png`} alt="OBS" className="w-5 h-5" />
              {t('performance.obs.title')}
            </h3>
            
            {/* GPU Selection */}
            <div className="text-xs font-medium tracking-wider uppercase text-[#666] mb-3">{t('performance.obs.selectGpu')}</div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              {obsGpuTypes.map(gpu => (
                <div
                  key={gpu.value}
                  onClick={() => handleGpuSelection(gpu.value)}
                  data-testid={`gpu-select-${gpu.value}`}
                  className={`exm-card cursor-pointer ${
                    selectedGpu === gpu.value ? 'border-[#ff3333] glow-pink' : ''
                  }`}
                >
                  <div className="flex items-center gap-4 mb-3">
                    {gpu.icon.startsWith('/') ? (
                      <img src={`${process.env.PUBLIC_URL}${gpu.icon}`} alt={gpu.label} className="w-12 h-12 object-contain" />
                    ) : (
                      <span className="text-3xl">{gpu.icon}</span>
                    )}
                    <div>
                      <h4 className={`font-semibold ${selectedGpu === gpu.value ? 'text-[#ff3333]' : 'text-white'}`}>
                        {gpu.label}
                      </h4>
                      <p className="text-[#666] text-sm">{gpu.description}</p>
                    </div>
                  </div>
                  <button className={`exm-btn-primary ${selectedGpu === gpu.value ? '' : 'opacity-50'}`}>
                    {selectedGpu === gpu.value ? t('performance.obs.selected') : t('performance.obs.select')}
                  </button>
                </div>
              ))}
            </div>
            
            {/* Apply Profile Button */}
            {selectedGpu && (
              <div>
                <div className="text-xs font-medium tracking-wider uppercase text-[#666] mb-3">{t('performance.obs.applyProfile')}</div>
                <div className="exm-card">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 rounded-lg bg-[#1a1a1a] flex items-center justify-center">
                      <span className="text-2xl">⚙️</span>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-white font-medium mb-1">{t('performance.obs.optimizedProfile')}</h4>
                      <p className="text-[#666] text-sm">
                        {t('performance.obs.configFor')} {selectedGpu === 'nvidia' ? 'NVIDIA' : 'AMD'} {t('performance.obs.gpu')}
                      </p>
                      <p className="text-[#888] text-xs mt-1">
                        {t('performance.obs.installPath')}: <code className="bg-white/5 px-1 rounded">%APPDATA%\obs-studio\basic\profiles\BabaTool</code>
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={applyObsProfile}
                    data-testid="apply-obs-profile-btn"
                    disabled={!selectedGpu}
                    className="exm-btn-primary w-full"
                  >
                    <span className="text-lg mr-2">🚀</span>
                    {t('performance.obs.applyButton')}
                  </button>
                </div>
                
                {/* Instructions */}
                <div className="exm-card mt-4 border-blue-500/20">
                  <div className="flex items-start gap-3">
                    <span className="text-blue-400">ℹ️</span>
                    <div>
                      <p className="text-blue-400 text-sm font-medium">{t('performance.obs.instructions')}</p>
                      <p className="text-[#666] text-xs mt-1">
                        1. {t('performance.obs.step1')}<br/>
                        2. {t('performance.obs.step2')}<br/>
                        3. {t('performance.obs.step3')}<br/>
                        4. {t('performance.obs.step4')}<br/>
                        5. {t('performance.obs.step5')}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        </LockedFeature>
      )}
    </div>
  );
};

export default PerformancePage;
