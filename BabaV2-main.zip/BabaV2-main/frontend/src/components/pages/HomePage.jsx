import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  Monitor,
  Cpu,
  MemoryStick,
  HardDrive,
  Clock,
  CheckCircle2,
  Sparkles,
  Laptop,
  Server,
  Gauge,
  Shield,
  Trash2,
  Settings,
  Download,
  ArrowRight,
  Palette
} from 'lucide-react';
import { useSettings } from '../../context/SettingsContext';

// Format bytes to human readable
const formatBytes = (bytes) => {
  if (!bytes) return 'N/A';
  const gb = bytes / (1024 * 1024 * 1024);
  return `${gb.toFixed(1)} GB`;
};

// Format uptime to human readable
const formatUptime = (seconds, t) => {
  if (!seconds) return 'N/A';
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  
  if (days > 0) {
    return `${days}${t('home.time.days')} ${hours}${t('home.time.hours')} ${minutes}${t('home.time.minutes')}`;
  } else if (hours > 0) {
    return `${hours}${t('home.time.hours')} ${minutes}${t('home.time.minutes')}`;
  }
  return `${minutes} ${t('home.time.minutesFull')}`;
};

const HomePage = ({ setActiveSection }) => {
  const { t } = useTranslation();
  const { isElectron } = useSettings();
  const [systemInfo, setSystemInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [licenseType, setLicenseType] = useState('Standard');

  // Raccourcis vers les onglets
  const shortcuts = [
    { id: 'performance', labelKey: 'nav.performance', icon: Gauge, descKey: 'home.shortcuts.performance', premium: false },
    { id: 'privacy', labelKey: 'nav.privacy', icon: Shield, descKey: 'home.shortcuts.privacy', premium: false },
    { id: 'interface', labelKey: 'nav.interface', icon: Palette, descKey: 'home.shortcuts.interface', premium: false },
    { id: 'bloatware', labelKey: 'nav.debloat', icon: Trash2, descKey: 'home.shortcuts.debloat', premium: false },
    { id: 'clean', labelKey: 'nav.clean', icon: Sparkles, descKey: 'home.shortcuts.clean', premium: false },
    { id: 'drivers', labelKey: 'nav.hardware', icon: HardDrive, descKey: 'home.shortcuts.hardware', premium: false },
    { id: 'updates', labelKey: 'nav.updates', icon: Download, descKey: 'home.shortcuts.updates', premium: false },
  ];

  useEffect(() => {
    const fetchSystemInfo = async () => {
      if (window.electronAPI?.getSystemInfo) {
        try {
          const info = await window.electronAPI.getSystemInfo();
          setSystemInfo(info);
        } catch (err) {
          console.error('Error fetching system info:', err);
        }
      }
      setLoading(false);
    };

    // Function to load license from localStorage
    const loadLicenseInfo = () => {
      const storedLicense = localStorage.getItem('babatool_license');
      if (storedLicense) {
        try {
          const licenseData = JSON.parse(storedLicense);
          const planLabels = { 'lifetime': 'Lifetime', 'standard': 'Standard', 'trial': 'Trial', 'premium': 'Premium' };
          setLicenseType(planLabels[licenseData.plan] || 'Standard');
        } catch (e) {}
      }
    };

    // Load license on mount
    loadLicenseInfo();
    fetchSystemInfo();
    
    // Listen for license updates
    const handleLicenseUpdate = () => {
      loadLicenseInfo();
    };
    window.addEventListener('license-updated', handleLicenseUpdate);
    
    return () => {
      window.removeEventListener('license-updated', handleLicenseUpdate);
    };
  }, []);

  // Données par défaut pour le mode web
  const defaultInfo = {
    hostname: 'WEB-MODE',
    osVersion: t('home.webMode.notAvailable'),
    cpuName: t('home.webMode.notAvailable'),
    cpuCores: '-',
    gpuName: t('home.webMode.notAvailable'),
    totalMemory: 0,
    freeMemory: 0,
    storage: t('home.webMode.notAvailable'),
    uptime: 0,
    arch: '-',
    isAdmin: false,
    appVersion: '1.6.6'
  };

  const info = systemInfo || defaultInfo;

  return (
    <div className="space-y-6 exm-fade-in">
      {/* Header */}
      <div>
        <h1 className="exm-section-title">{t('nav.home')}</h1>
        <p className="exm-section-subtitle">{t('home.subtitle')}</p>
      </div>

      {/* License Status Card */}
      <div className="exm-card">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center overflow-hidden bg-[#1a1a1a] border border-[#2a2a2a]">
              <img src={process.env.PUBLIC_URL + "/logo.png"} alt="BaBaTool" className="w-8 h-8 object-contain" />
            </div>
            <div>
              <h2 className="text-white font-semibold">BaBaTool v{info.appVersion || '1.6.6'}</h2>
              <div className="flex items-center gap-2 mt-1">
                <Sparkles className="w-4 h-4 text-[#ff3333]" />
                <span className="text-[#ff3333] text-sm font-medium">{t('sidebar.license')} {licenseType}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-[#ff3333]/10 rounded-lg border border-[#ff3333]/20">
            <CheckCircle2 className="w-4 h-4 text-[#ff3333]" />
            <span className="text-[#ff3333] text-sm font-medium">
              {isElectron ? (info.isAdmin ? t('common.admin') : t('home.user')) : t('home.webMode.label')}
            </span>
          </div>
        </div>
      </div>

      {/* System Info Grid */}
      <div>
        <div className="text-xs font-medium tracking-wider uppercase text-[#666] mb-3">{t('home.systemInfo')}</div>
        
        {loading ? (
          <div className="exm-card flex items-center justify-center py-8">
            <div className="w-6 h-6 border-2 border-[#ff3333] border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {/* OS */}
            <div className="exm-card">
              <div className="flex items-center gap-2 text-[#666] mb-2">
                <Monitor className="w-4 h-4" />
                <span className="text-xs">OS</span>
              </div>
              <p className="text-white text-sm font-medium truncate">{info.osVersion || 'Unknown'}</p>
            </div>
            
            {/* CPU */}
            <div className="exm-card">
              <div className="flex items-center gap-2 text-[#666] mb-2">
                <Cpu className="w-4 h-4" />
                <span className="text-xs">CPU</span>
              </div>
              <p className="text-white text-sm font-medium truncate">{info.cpuName || 'Unknown'}</p>
            </div>
            
            {/* RAM */}
            <div className="exm-card">
              <div className="flex items-center gap-2 text-[#666] mb-2">
                <MemoryStick className="w-4 h-4" />
                <span className="text-xs">RAM</span>
              </div>
              <p className="text-white text-sm font-medium">{info.totalMemory ? formatBytes(info.totalMemory) : 'N/A'}</p>
            </div>
            
            {/* GPU */}
            <div className="exm-card">
              <div className="flex items-center gap-2 text-[#666] mb-2">
                <Monitor className="w-4 h-4" />
                <span className="text-xs">GPU</span>
              </div>
              <p className="text-white text-sm font-medium truncate">{info.gpuName || 'Unknown'}</p>
            </div>
            
            {/* Storage */}
            <div className="exm-card">
              <div className="flex items-center gap-2 text-[#666] mb-2">
                <HardDrive className="w-4 h-4" />
                <span className="text-xs">{t('home.storage')}</span>
              </div>
              <p className="text-white text-sm font-medium truncate">{info.storage || 'Unknown'}</p>
            </div>
            
            {/* Uptime */}
            <div className="exm-card">
              <div className="flex items-center gap-2 text-[#666] mb-2">
                <Clock className="w-4 h-4" />
                <span className="text-xs">{t('home.uptime')}</span>
              </div>
              <p className="text-white text-sm font-medium">{info.uptime ? formatUptime(info.uptime, t) : 'N/A'}</p>
            </div>
            
            {/* Architecture */}
            <div className="exm-card">
              <div className="flex items-center gap-2 text-[#666] mb-2">
                <Cpu className="w-4 h-4" />
                <span className="text-xs">{t('home.architecture')}</span>
              </div>
              <p className="text-white text-sm font-medium">{info.arch || '-'} • {info.cpuCores || '-'} cores</p>
            </div>
            
            {/* Hostname */}
            <div className="exm-card">
              <div className="flex items-center gap-2 text-[#666] mb-2">
                <Server className="w-4 h-4" />
                <span className="text-xs">{t('home.hostname')}</span>
              </div>
              <p className="text-white text-sm font-medium">{info.hostname || 'Unknown'}</p>
            </div>
          </div>
        )}
      </div>

      {/* Quick Navigation */}
      <div>
        <div className="text-xs font-medium tracking-wider uppercase text-[#666] mb-3">{t('home.quickNav')}</div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {shortcuts.map((shortcut) => {
            const Icon = shortcut.icon;
            return (
              <div
                key={shortcut.id}
                onClick={() => setActiveSection && setActiveSection(shortcut.id)}
                className="exm-card cursor-pointer group"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-[#1a1a1a]">
                    <Icon className="w-5 h-5 text-white" strokeWidth={1.5} />
                  </div>
                  {shortcut.premium && (
                    <Sparkles className="w-4 h-4 text-[#ff3333]" />
                  )}
                </div>
                <h3 className="text-white font-medium text-sm mb-1">{t(shortcut.labelKey)}</h3>
                <p className="text-[#555] text-xs">{t(shortcut.descKey)}</p>
                <button className="exm-btn-primary mt-4 flex items-center justify-center gap-2">
                  <span>{t('home.open')}</span>
                  <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default HomePage;
