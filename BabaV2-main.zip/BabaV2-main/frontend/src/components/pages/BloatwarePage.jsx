import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  Trash2, 
  Search, 
  Package,
  CheckSquare,
  Square,
  Play,
  Power,
  Rocket,
  Settings,
  RefreshCw,
  Loader2,
  Monitor,
  Box,
  AlertTriangle,
  Scan,
  Gamepad2,
  Music,
  Mail,
  Globe,
  Smartphone,
  ShieldCheck
} from 'lucide-react';
import { Input } from '../ui/input';
import { Button } from '../ui/button';
import { useSettings } from '../../context/SettingsContext';
import LockedFeature from '../ui/LockedFeature';
import { useLicense } from '../../hooks/useLicense';
import { FEATURE_CATEGORIES, LICENSE_TYPES } from '../../utils/licenseConfig';

// ============================================================================
// CATEGORY ICONS
// ============================================================================
const categoryIcons = {
  'Gaming': Gamepad2,
  'Media': Music,
  'Communication': Mail,
  'Bing Services': Globe,
  'Office': Package,
  'Third-Party': Smartphone,
  'Application': Box
};

const categoryColors = {
  'Gaming': 'from-purple-500 to-indigo-500',
  'Media': 'from-pink-500 to-rose-500',
  'Communication': 'from-blue-500 to-cyan-500',
  'Bing Services': 'from-teal-500 to-green-500',
  'Office': 'from-orange-500 to-amber-500',
  'Third-Party': 'from-red-500 to-pink-500',
  'Application': 'from-gray-500 to-slate-500'
};

// ============================================================================
// MAIN COMPONENT
// ============================================================================
const BloatwarePage = () => {
  const { t } = useTranslation();
  const { isElectron, addToast } = useSettings();
  const { checkFeatureAccess } = useLicense();
  const [activeTab, setActiveTab] = useState('apps');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedApps, setSelectedApps] = useState(new Set());
  const [isUninstalling, setIsUninstalling] = useState(false);
  const [uninstallProgress, setUninstallProgress] = useState({ current: 0, total: 0, name: '' });
  
  // Bloatwares détectés
  const [bloatwares, setBloatwares] = useState([]);
  const [isScanning, setIsScanning] = useState(false);
  const [hasScanned, setHasScanned] = useState(false);
  
  // Autoruns
  const [autoruns, setAutoruns] = useState([]);
  const [loadingAutoruns, setLoadingAutoruns] = useState(false);
  const [hasLoadedAutoruns, setHasLoadedAutoruns] = useState(false);

  // Scanner les bloatwares Windows
  const scanBloatwares = async () => {
    setIsScanning(true);
    setBloatwares([]);
    
    if (isElectron && window.electronAPI?.getInstalledApps) {
      try {
        console.log('Starting bloatware scan...');
        const result = await window.electronAPI.getInstalledApps();
        console.log('Scan result:', result);
        
        if (result.success && result.apps?.length > 0) {
          setBloatwares(result.apps);
          if (addToast) addToast(t('notifications.bloatware.detected').replace('{{count}}', result.apps.length), 'success');
        } else if (result.error) {
          console.error('Scan error:', result.error);
          if (addToast) addToast(`${t('notifications.generic.error')}: ${result.error}`, 'error');
        } else {
          if (addToast) addToast(t('notifications.bloatware.noneDetected'), 'info');
        }
      } catch (error) {
        console.error('Scan exception:', error);
        if (addToast) addToast(`${t('notifications.generic.error')}: ${error.message}`, 'error');
      }
    } else {
      // Mode démo - simuler le scan
      await new Promise(r => setTimeout(r, 2000));
      const demoBloatwares = [
        { name: "Xbox Game Bar", fullName: "Microsoft.XboxGamingOverlay", packageName: "Microsoft.XboxGamingOverlay_5.823.1002.0_x64__8wekyb3d8bbwe", type: "UWP", isBloatware: true, publisher: "Microsoft", version: "5.823.1002.0", category: "Gaming" },
        { name: "Xbox App", fullName: "Microsoft.GamingApp", packageName: "Microsoft.GamingApp_2311.1001.5.0_x64__8wekyb3d8bbwe", type: "UWP", isBloatware: true, publisher: "Microsoft", version: "2311.1001.5.0", category: "Gaming" },
        { name: "Cortana", fullName: "Microsoft.549981C3F5F10", packageName: "Microsoft.549981C3F5F10_4.2308.1005.0_x64__8wekyb3d8bbwe", type: "UWP", isBloatware: true, publisher: "Microsoft", version: "4.2308.1005.0", category: "Application" },
        { name: "Get Help", fullName: "Microsoft.GetHelp", packageName: "Microsoft.GetHelp_10.2311.12842.0_x64__8wekyb3d8bbwe", type: "UWP", isBloatware: true, publisher: "Microsoft", version: "10.2311.12842.0", category: "Application" },
        { name: "Microsoft Tips", fullName: "Microsoft.Getstarted", packageName: "Microsoft.Getstarted_10.2310.1.0_x64__8wekyb3d8bbwe", type: "UWP", isBloatware: true, publisher: "Microsoft", version: "10.2310.1.0", category: "Application" },
        { name: "Mail and Calendar", fullName: "microsoft.windowscommunicationsapps", packageName: "microsoft.windowscommunicationsapps_16005.14326.21738.0_x64__8wekyb3d8bbwe", type: "UWP", isBloatware: true, publisher: "Microsoft", version: "16005.14326.21738.0", category: "Communication" },
        { name: "Maps", fullName: "Microsoft.WindowsMaps", packageName: "Microsoft.WindowsMaps_11.2311.1.0_x64__8wekyb3d8bbwe", type: "UWP", isBloatware: true, publisher: "Microsoft", version: "11.2311.1.0", category: "Application" },
        { name: "People", fullName: "Microsoft.People", packageName: "Microsoft.People_10.2201.1.0_x64__8wekyb3d8bbwe", type: "UWP", isBloatware: true, publisher: "Microsoft", version: "10.2201.1.0", category: "Communication" },
        { name: "Solitaire Collection", fullName: "Microsoft.MicrosoftSolitaireCollection", packageName: "Microsoft.MicrosoftSolitaireCollection_4.18.12061.0_x64__8wekyb3d8bbwe", type: "UWP", isBloatware: true, publisher: "Microsoft", version: "4.18.12061.0", category: "Gaming" },
        { name: "Feedback Hub", fullName: "Microsoft.WindowsFeedbackHub", packageName: "Microsoft.WindowsFeedbackHub_1.2311.1091.0_x64__8wekyb3d8bbwe", type: "UWP", isBloatware: true, publisher: "Microsoft", version: "1.2311.1091.0", category: "Application" },
        { name: "Your Phone", fullName: "Microsoft.YourPhone", packageName: "Microsoft.YourPhone_1.23112.89.0_x64__8wekyb3d8bbwe", type: "UWP", isBloatware: true, publisher: "Microsoft", version: "1.23112.89.0", category: "Communication" },
        { name: "Mixed Reality Portal", fullName: "Microsoft.MixedReality.Portal", packageName: "Microsoft.MixedReality.Portal_2000.21051.1282.0_x64__8wekyb3d8bbwe", type: "UWP", isBloatware: true, publisher: "Microsoft", version: "2000.21051.1282.0", category: "Application" },
        { name: "Groove Music", fullName: "Microsoft.ZuneMusic", packageName: "Microsoft.ZuneMusic_11.2311.1.0_x64__8wekyb3d8bbwe", type: "UWP", isBloatware: true, publisher: "Microsoft", version: "11.2311.1.0", category: "Media" },
        { name: "Movies & TV", fullName: "Microsoft.ZuneVideo", packageName: "Microsoft.ZuneVideo_10.22091.10.0_x64__8wekyb3d8bbwe", type: "UWP", isBloatware: true, publisher: "Microsoft", version: "10.22091.10.0", category: "Media" },
        { name: "Bing Weather", fullName: "Microsoft.BingWeather", packageName: "Microsoft.BingWeather_4.53.51321.0_x64__8wekyb3d8bbwe", type: "UWP", isBloatware: true, publisher: "Microsoft", version: "4.53.51321.0", category: "Bing Services" },
        { name: "Bing News", fullName: "Microsoft.BingNews", packageName: "Microsoft.BingNews_4.53.51321.0_x64__8wekyb3d8bbwe", type: "UWP", isBloatware: true, publisher: "Microsoft", version: "4.53.51321.0", category: "Bing Services" },
        { name: "Clipchamp", fullName: "Clipchamp.Clipchamp", packageName: "Clipchamp.Clipchamp_2.9.1.0_x64__yxz26nhyzhsrt", type: "UWP", isBloatware: true, publisher: "Microsoft", version: "2.9.1.0", category: "Media" },
        { name: "Microsoft Teams", fullName: "MicrosoftTeams", packageName: "MicrosoftTeams_23320.3027.2591.1505_x64__8wekyb3d8bbwe", type: "UWP", isBloatware: true, publisher: "Microsoft", version: "23320.3027.2591.1505", category: "Communication" },
      ];
      setBloatwares(demoBloatwares);
      if (addToast) addToast(t('notifications.generic.scanComplete'), 'success');
    }
    
    setIsScanning(false);
    setHasScanned(true);
  };

  // Charger les autoruns via Electron
  const loadAutoruns = async () => {
    setLoadingAutoruns(true);
    
    if (isElectron && window.electronAPI?.getAutoruns) {
      try {
        console.log('Loading autoruns...');
        const result = await window.electronAPI.getAutoruns();
        console.log('Autoruns result:', result);
        
        if (result.success && result.autoruns?.length > 0) {
          setAutoruns(result.autoruns);
          if (addToast) addToast(t('notifications.autoruns.detected').replace('{{count}}', result.autoruns.length), 'success');
        } else if (result.error) {
          console.error('Autoruns error:', result.error);
          if (addToast) addToast(`${t('notifications.generic.error')}: ${result.error}`, 'error');
        } else {
          if (addToast) addToast(t('notifications.autoruns.noneDetected'), 'info');
        }
      } catch (error) {
        console.error('Autoruns exception:', error);
        if (addToast) addToast(`${t('notifications.generic.error')}: ${error.message}`, 'error');
      }
    } else {
      // Mode démo
      await new Promise(r => setTimeout(r, 1000));
      const demoAutoruns = [
        { name: "Discord", command: "C:\\Users\\AppData\\Local\\Discord\\Update.exe --processStart Discord.exe", location: "HKCU\\Run", enabled: true, type: "Registry" },
        { name: "Steam", command: "\"C:\\Program Files (x86)\\Steam\\steam.exe\" -silent", location: "HKCU\\Run", enabled: true, type: "Registry" },
        { name: "Spotify", command: "\"C:\\Users\\AppData\\Roaming\\Spotify\\Spotify.exe\" /minimized", location: "HKCU\\Run", enabled: false, type: "Registry" },
        { name: "OneDrive", command: "\"C:\\Program Files\\Microsoft OneDrive\\OneDrive.exe\" /background", location: "HKCU\\Run", enabled: true, type: "Registry" },
        { name: "Microsoft Teams", command: "\"C:\\Users\\AppData\\Local\\Microsoft\\Teams\\Update.exe\"", location: "HKCU\\Run", enabled: false, type: "Registry" },
        { name: "SecurityHealth", command: "\"C:\\Windows\\System32\\SecurityHealthSystray.exe\"", location: "HKLM\\Run", enabled: true, type: "Registry" },
        { name: "NvContainer", command: "C:\\Program Files\\NVIDIA Corporation\\NvContainer\\nvcontainer.exe", location: "HKLM\\Run", enabled: true, type: "Registry" },
        { name: "NVIDIA Share", command: "C:\\Program Files\\NVIDIA Corporation\\NVIDIA GeForce Experience\\NVIDIA Share.exe", location: "HKLM\\Run", enabled: false, type: "Registry" },
        { name: "Logitech G HUB", command: "\"C:\\Program Files\\LGHUB\\lghub.exe\" --background", location: "HKCU\\Run", enabled: true, type: "Registry" },
        { name: "EpicGamesLauncher", command: "\"C:\\Program Files (x86)\\Epic Games\\Launcher\\EpicGamesLauncher.exe\"", location: "HKCU\\Run", enabled: false, type: "Registry" },
        { name: "Adobe Updater", command: "C:\\Program Files (x86)\\Common Files\\Adobe\\OOBE\\PDApp\\UWA\\UpdaterStartupUtility.exe", location: "HKLM\\Run", enabled: false, type: "Registry" },
        { name: "Razer Synapse", command: "\"C:\\Program Files (x86)\\Razer\\Synapse3\\Razer Synapse 3.exe\"", location: "HKCU\\Run", enabled: true, type: "Registry" },
      ];
      setAutoruns(demoAutoruns);
      if (addToast) addToast(t('notifications.generic.loaded'), 'info');
    }
    
    setLoadingAutoruns(false);
    setHasLoadedAutoruns(true);
  };

  // Charger les autoruns quand on switch sur l'onglet
  useEffect(() => {
    if (activeTab === 'autoruns' && !hasLoadedAutoruns && !loadingAutoruns) {
      loadAutoruns();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, hasLoadedAutoruns, loadingAutoruns]);

  // Filtrer les bloatwares
  const filteredBloatwares = bloatwares.filter(app => 
    (app.name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (app.fullName || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (app.category || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Grouper par catégorie
  const bloatwaresByCategory = filteredBloatwares.reduce((acc, app) => {
    const cat = app.category || 'Application';
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(app);
    return acc;
  }, {});

  // Filtrer les autoruns
  const filteredAutoruns = autoruns.filter(a =>
    (a.name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (a.command || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Grouper les autoruns par location
  const autorunsByLocation = filteredAutoruns.reduce((acc, ar) => {
    const loc = ar.location || 'Autre';
    if (!acc[loc]) acc[loc] = [];
    acc[loc].push(ar);
    return acc;
  }, {});

  const toggleSelection = (packageName) => {
    const newSelected = new Set(selectedApps);
    if (newSelected.has(packageName)) newSelected.delete(packageName);
    else newSelected.add(packageName);
    setSelectedApps(newSelected);
  };

  const selectAll = () => {
    const allPackages = filteredBloatwares.map(a => a.packageName);
    setSelectedApps(new Set(allPackages));
  };

  const deselectAll = () => setSelectedApps(new Set());

  const uninstallSelected = async () => {
    if (selectedApps.size === 0) return;
    setIsUninstalling(true);
    
    const appsToUninstall = bloatwares.filter(app => selectedApps.has(app.packageName));
    let successCount = 0;
    
    for (let i = 0; i < appsToUninstall.length; i++) {
      const app = appsToUninstall[i];
      setUninstallProgress({ current: i + 1, total: appsToUninstall.length, name: app.name });
      
      if (isElectron && window.electronAPI?.uninstallUwpApp) {
        try {
          const result = await window.electronAPI.uninstallUwpApp(app.packageName);
          if (result.success) {
            successCount++;
          }
        } catch (error) {
          console.error(`Error uninstalling ${app.name}:`, error);
        }
      } else {
        // Mode démo - simuler la désinstallation
        await new Promise(r => setTimeout(r, 500));
        successCount++;
      }
    }
    
    // Mettre à jour la liste
    setBloatwares(prev => prev.filter(app => !selectedApps.has(app.packageName)));
    
    if (addToast) {
      addToast(
        t('notifications.bloatware.removed')
          .replace('{{successCount}}', successCount)
          .replace('{{total}}', appsToUninstall.length), 
        successCount === appsToUninstall.length ? 'success' : 'warning'
      );
    }
    
    setSelectedApps(new Set());
    setIsUninstalling(false);
    setUninstallProgress({ current: 0, total: 0, name: '' });
  };

  const toggleAutorun = async (autorun) => {
    const newEnabled = !autorun.enabled;
    
    // Mettre à jour l'UI immédiatement
    setAutoruns(prev => prev.map(ar => 
      ar.name === autorun.name && ar.location === autorun.location
        ? { ...ar, enabled: newEnabled }
        : ar
    ));
    
    if (isElectron && window.electronAPI?.toggleAutorun) {
      try {
        const result = await window.electronAPI.toggleAutorun(autorun.name, autorun.location, autorun.enabled, autorun.command);
        
        if (!result.success) {
          // Rétablir l'état précédent en cas d'erreur
          setAutoruns(prev => prev.map(ar => 
            ar.name === autorun.name && ar.location === autorun.location
              ? { ...ar, enabled: autorun.enabled }
              : ar
          ));
          if (addToast) addToast(t('notifications.autoruns.modificationError'), 'error');
          return;
        }
        
        if (addToast) addToast(`${autorun.name} ${newEnabled ? t('notifications.fortnite.activated') : t('notifications.fortnite.deactivated')}`, 'success');
        
      } catch (error) {
        // Rétablir l'état précédent
        setAutoruns(prev => prev.map(ar => 
          ar.name === autorun.name && ar.location === autorun.location
            ? { ...ar, enabled: autorun.enabled }
            : ar
        ));
        if (addToast) addToast(`${t('notifications.generic.error')}: ${error.message}`, 'error');
      }
    } else {
      // Mode démo
      if (addToast) addToast(`${autorun.name} ${newEnabled ? t('notifications.fortnite.activated') : t('notifications.fortnite.deactivated')} (démo)`, 'info');
    }
  };

  const enabledAutoruns = autoruns.filter(a => a.enabled).length;
  const disabledAutoruns = autoruns.filter(a => !a.enabled).length;

  return (
    <LockedFeature
      requiredLicense={LICENSE_TYPES.PREMIUM}
      isLocked={!checkFeatureAccess(FEATURE_CATEGORIES.BLOATWARE)}
      title="🔒 Débloquer - Premium"
      description="Supprimez les applications préinstallées et gérez les programmes au démarrage. Disponible avec la licence Premium."
    >
    <div className="space-y-6 exm-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="exm-section-title">{t('debloat.title')}</h1>
          <p className="exm-section-subtitle">
            {activeTab === 'apps' 
              ? t('debloat.subtitleApps')
              : t('debloat.subtitleAutoruns')
            }
          </p>
        </div>
        
        {/* Stats */}
        <div className="flex items-center gap-3">
          {activeTab === 'apps' ? (
            hasScanned && (
              <div className="flex items-center gap-2 px-4 py-2 bg-[#ff3333]/10 rounded-lg border border-[#ff3333]/20">
                <AlertTriangle className="w-4 h-4 text-[#ff3333]" />
                <span className="text-[#ff3333] text-sm font-medium">{bloatwares.length} {t('debloat.detected')}</span>
              </div>
            )
          ) : (
            <>
              <div className="flex items-center gap-2 px-4 py-2 bg-green-500/10 rounded-lg border border-green-500/20">
                <Play className="w-4 h-4 text-green-400" />
                <span className="text-green-400 text-sm font-medium">{enabledAutoruns} {t('debloat.enabled')}</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-red-500/10 rounded-lg border border-red-500/20">
                <Power className="w-4 h-4 text-red-400" />
                <span className="text-red-400 text-sm font-medium">{disabledAutoruns} {t('debloat.disabled')}</span>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Tabs */}
      {/* Tabs - EXM Style */}
      <div className="exm-tabs">
        <button
          onClick={() => { setActiveTab('apps'); setSearchQuery(''); setSelectedApps(new Set()); }}
          data-testid="tab-apps"
          className={`exm-tab ${activeTab === 'apps' ? 'active' : ''}`}
        >
          {t('debloat.tabs.apps')} {hasScanned && `(${bloatwares.length})`}
        </button>
        <button
          onClick={() => { setActiveTab('autoruns'); setSearchQuery(''); }}
          data-testid="tab-autoruns"
          className={`exm-tab ${activeTab === 'autoruns' ? 'active' : ''}`}
        >
          {t('debloat.tabs.autoruns')} {hasLoadedAutoruns && `(${autoruns.length})`}
        </button>
      </div>

      {/* Demo Banner */}
      {!isElectron && (
        <div className="exm-card border-blue-500/20">
          <div className="flex items-center gap-4">
            <Monitor className="w-5 h-5 text-blue-400" />
            <p className="text-blue-400 text-sm">
              <strong>{t('debloat.demoMode')}</strong> - {t('debloat.demoModeDesc')}
            </p>
          </div>
        </div>
      )}

      {/* APPS TAB - Bloatwares */}
      {activeTab === 'apps' && (
        <>
          {/* Scan Button - Before scanning */}
          {!hasScanned && !isScanning && (
            <div className="flex flex-col items-center justify-center py-16 exm-card text-center">
              <div className="w-16 h-16 bg-[#ff3333]/10 rounded-xl flex items-center justify-center mb-6 border border-[#ff3333]/30">
                <Scan className="w-8 h-8 text-[#ff3333]" />
              </div>
              <h2 className="text-lg font-semibold text-white mb-2">{t('debloat.scan.title')}</h2>
              <p className="text-[#666] text-sm mb-6 max-w-md">
                {t('debloat.scan.description')}
              </p>
              <button
                onClick={scanBloatwares}
                data-testid="scan-bloatwares-btn"
                className="exm-btn-primary px-8 py-3"
              >
                <Scan className="w-4 h-4 mr-2 inline" />
                {t('debloat.scan.button')}
              </button>
            </div>
          )}

          {/* Scanning Animation */}
          {isScanning && (
            <div className="flex flex-col items-center justify-center py-20 exm-card">
              <div className="relative">
                <div className="w-16 h-16 border-4 border-[#ff3333]/20 rounded-full"></div>
                <div className="absolute inset-0 w-16 h-16 border-4 border-[#ff3333] border-t-transparent rounded-full animate-spin"></div>
                <Scan className="absolute inset-0 m-auto w-8 h-8 text-orange-400" />
              </div>
              <p className="text-white font-medium mt-6">{t('debloat.scan.scanning')}</p>
              <p className="text-[#666] text-sm mt-2">{t('debloat.scan.scanningDesc')}</p>
            </div>
          )}

          {/* Uninstalling Progress */}
          {isUninstalling && (
            <div className="bg-gradient-to-r from-pink-500/10 to-rose-500/10 border border-pink-500/20 rounded-2xl p-6">
              <div className="flex items-center gap-4">
                <Loader2 className="w-6 h-6 text-pink-500 animate-spin" />
                <div className="flex-1">
                  <p className="text-white font-medium">{t('debloat.uninstalling')}</p>
                  <p className="text-[#888] text-sm mt-1">
                    {uninstallProgress.current}/{uninstallProgress.total} - {uninstallProgress.name}
                  </p>
                  <div className="mt-3 h-2 bg-[#1a1a1a] rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-pink-500 to-rose-500 transition-all duration-300"
                      style={{ width: `${(uninstallProgress.current / uninstallProgress.total) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Results - After scanning */}
          {hasScanned && !isScanning && !isUninstalling && (
            <>
              {/* Search & Actions */}
              <div className="bg-gradient-to-r from-[#151515] to-[#1a1a1a] rounded-2xl p-4 border border-white/5">
                <div className="flex items-center justify-between gap-4">
                  <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#666]" />
                    <Input
                      placeholder={t('debloat.searchPlaceholder')}
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      data-testid="search-bloatwares"
                      className="pl-11 h-11 bg-[#0d0d0d] border-white/10 text-white placeholder:text-[#555] rounded-xl"
                    />
                  </div>

                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" onClick={scanBloatwares} className="text-[#888] hover:text-white">
                      <RefreshCw className="w-4 h-4 mr-2" />
                      {t('debloat.rescan')}
                    </Button>
                    <Button variant="ghost" size="sm" onClick={selectAll} className="text-[#888] hover:text-white">
                      <CheckSquare className="w-4 h-4 mr-2" />
                      {t('debloat.selectAll')}
                    </Button>
                    <Button variant="ghost" size="sm" onClick={deselectAll} className="text-[#888] hover:text-white">
                      <Square className="w-4 h-4 mr-2" />
                      {t('debloat.unselectAll')}
                    </Button>
                  </div>

                  <Button
                    onClick={uninstallSelected}
                    disabled={selectedApps.size === 0 || isUninstalling}
                    data-testid="uninstall-selected-btn"
                    className={`px-6 h-11 rounded-xl font-semibold ${
                      selectedApps.size > 0 
                        ? 'bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-600 hover:to-rose-700 text-white' 
                        : 'bg-[#2a2a2a] text-[#666] cursor-not-allowed'
                    }`}
                  >
                    {isUninstalling ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Trash2 className="w-4 h-4 mr-2" />}
                    {t('debloat.removeSelected')} ({selectedApps.size})
                  </Button>
                </div>
              </div>

              {/* Bloatwares List by Category */}
              {filteredBloatwares.length === 0 ? (
                <div className="text-center py-16">
                  <Package className="w-12 h-12 text-[#333] mx-auto mb-4" />
                  <p className="text-[#666]">{t('debloat.noBloatware')}</p>
                </div>
              ) : (
                <div className="space-y-6">
                  {Object.keys(bloatwaresByCategory).map(category => {
                    const CategoryIcon = categoryIcons[category] || Box;
                    const colorClass = categoryColors[category] || 'from-gray-500 to-slate-500';
                    
                    return (
                      <div key={category} className="space-y-3">
                        <h2 className="text-white font-semibold flex items-center gap-3">
                          <span className={`w-8 h-8 rounded-lg bg-gradient-to-r ${colorClass} flex items-center justify-center`}>
                            <CategoryIcon className="w-4 h-4 text-white" />
                          </span>
                          {category}
                          <span className="text-[#666] text-sm font-normal">({bloatwaresByCategory[category].length})</span>
                        </h2>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                          {bloatwaresByCategory[category].map((app, idx) => {
                            const isSelected = selectedApps.has(app.packageName);
                            return (
                              <div
                                key={`${app.packageName}-${idx}`}
                                onClick={() => toggleSelection(app.packageName)}
                                data-testid={`bloatware-item-${app.fullName}`}
                                className={`relative p-4 rounded-xl border cursor-pointer transition-all ${
                                  isSelected
                                    ? 'bg-pink-500/10 border-pink-500/30'
                                    : 'bg-gradient-to-br from-[#151515] to-[#111] border-white/5 hover:border-white/10'
                                }`}
                              >
                                <div className="flex items-start gap-3">
                                  <div className={`w-5 h-5 rounded-md flex items-center justify-center flex-shrink-0 mt-0.5 ${
                                    isSelected ? 'bg-pink-500' : 'bg-[#0d0d0d] border border-white/10'
                                  }`}>
                                    {isSelected && <CheckSquare className="w-3 h-3 text-white" />}
                                  </div>
                                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 bg-gradient-to-br ${colorClass} bg-opacity-20`}>
                                    <CategoryIcon className="w-5 h-5 text-white/80" />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2">
                                      <h3 className="text-sm font-semibold text-white truncate">{app.name}</h3>
                                      <span className="px-1.5 py-0.5 bg-orange-500/20 text-orange-400 text-[9px] font-bold rounded">BLOAT</span>
                                    </div>
                                    <p className="text-[#666] text-xs mt-0.5">{app.publisher} • v{app.version}</p>
                                    <p className="text-[#444] text-[10px] mt-1 font-mono truncate">{app.fullName}</p>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}
        </>
      )}

      {/* AUTORUNS TAB */}
      {activeTab === 'autoruns' && (
        <>
          {!hasLoadedAutoruns && !loadingAutoruns ? (
            <div className="flex flex-col items-center justify-center py-16 bg-gradient-to-br from-[#151515] to-[#0d0d0d] rounded-2xl border border-white/5">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-2xl flex items-center justify-center mb-6 border border-blue-500/30">
                <Rocket className="w-10 h-10 text-blue-400" />
              </div>
              <h2 className="text-xl font-bold text-white mb-2">Analyser les Autoruns</h2>
              <p className="text-[#666] text-sm mb-6 text-center max-w-md">
                Scannez le registre Windows pour détecter les programmes au démarrage
              </p>
              <Button
                onClick={loadAutoruns}
                data-testid="scan-autoruns-btn"
                className="px-8 py-6 h-auto bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white rounded-xl font-semibold text-lg shadow-lg shadow-blue-500/20"
              >
                <Rocket className="w-5 h-5 mr-3" />
                Scanner Autoruns
              </Button>
            </div>
          ) : loadingAutoruns ? (
            <div className="flex flex-col items-center justify-center py-20">
              <Loader2 className="w-12 h-12 text-blue-500 animate-spin mb-4" />
              <p className="text-white font-medium">Lecture du registre Windows...</p>
              <p className="text-[#666] text-sm mt-2">HKLM\Run • HKCU\Run • Startup Folder</p>
            </div>
          ) : (
            <>
              {/* Info Banner */}
              <div className="bg-gradient-to-r from-blue-500/10 to-blue-500/5 border border-blue-500/20 rounded-2xl p-4 flex items-center gap-4">
                <ShieldCheck className="w-5 h-5 text-blue-400" />
                <div>
                  <p className="text-blue-400 text-sm font-medium">{t('debloat.autoruns.sources')}</p>
                  <p className="text-[#666] text-xs mt-0.5">
                    HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run • HKCU\...\Run • Startup Folder
                  </p>
                </div>
              </div>

              {/* Search */}
              <div className="bg-gradient-to-r from-[#151515] to-[#1a1a1a] rounded-2xl p-4 border border-white/5">
                <div className="flex items-center justify-between gap-4">
                  <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#666]" />
                    <Input
                      placeholder={t('debloat.autoruns.searchPlaceholder')}
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      data-testid="search-autoruns"
                      className="pl-11 h-11 bg-[#0d0d0d] border-white/10 text-white placeholder:text-[#555] rounded-xl"
                    />
                  </div>
                  <Button variant="ghost" size="sm" onClick={loadAutoruns} disabled={loadingAutoruns} className="text-[#888] hover:text-white">
                    <RefreshCw className={`w-4 h-4 mr-2 ${loadingAutoruns ? 'animate-spin' : ''}`} />
                    Actualiser
                  </Button>
                </div>
              </div>

              {/* Autoruns List */}
              {filteredAutoruns.length === 0 ? (
                <div className="text-center py-16">
                  <Rocket className="w-12 h-12 text-[#333] mx-auto mb-4" />
                  <p className="text-[#666]">Aucun programme au démarrage détecté</p>
                </div>
              ) : (
                <>
                  {Object.keys(autorunsByLocation).map(location => (
                    <div key={location} className="space-y-3">
                      <h2 className="text-white font-semibold flex items-center gap-3">
                        <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                        {location}
                        <span className="text-[#666] text-sm font-normal">({autorunsByLocation[location].length})</span>
                      </h2>

                      <div className="space-y-2">
                        {autorunsByLocation[location].map((autorun, idx) => (
                          <div
                            key={`${autorun.name}-${idx}`}
                            data-testid={`autorun-item-${autorun.name}`}
                            className="bg-gradient-to-br from-[#151515] to-[#111] border border-white/5 rounded-xl p-4 hover:border-white/10 transition-all"
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-4 flex-1 min-w-0">
                                <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
                                  autorun.enabled ? 'bg-green-500/20' : 'bg-red-500/10'
                                }`}>
                                  {autorun.enabled ? <Play className="w-6 h-6 text-green-400" /> : <Power className="w-6 h-6 text-red-400" />}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-2">
                                    <h3 className="text-white font-semibold truncate">{autorun.name}</h3>
                                    <span className={`text-[10px] px-2 py-0.5 rounded font-medium ${
                                      autorun.enabled ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                                    }`}>
                                      {autorun.enabled ? t('debloat.autoruns.enabled') : t('debloat.autoruns.disabled')}
                                    </span>
                                  </div>
                                  <p className="text-[#444] text-xs mt-1 font-mono truncate">{autorun.command}</p>
                                </div>
                              </div>
                              
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  toggleAutorun(autorun);
                                }}
                                data-testid={`toggle-autorun-${autorun.name}`}
                                className={`relative w-14 h-8 rounded-full transition-all duration-300 flex-shrink-0 ml-4 cursor-pointer ${
                                  autorun.enabled 
                                    ? 'bg-gradient-to-r from-green-500 to-green-600 shadow-lg shadow-green-500/30' 
                                    : 'bg-[#333] hover:bg-[#444]'
                                }`}
                              >
                                <span className={`absolute top-1.5 w-5 h-5 bg-white rounded-full shadow-md transition-all duration-300 ${
                                  autorun.enabled ? 'left-8' : 'left-1'
                                }`} />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}

                  {/* Quick Actions */}
                  <div className="bg-gradient-to-br from-[#151515] to-[#0d0d0d] rounded-2xl p-6 border border-white/5">
                    <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                      <Settings className="w-4 h-4 text-blue-400" />
                      {t('debloat.autoruns.quickActions')}
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <Button
                        variant="outline"
                        onClick={async () => {
                          const toDisable = autoruns.filter(ar => ar.enabled);
                          if (toDisable.length === 0) return;
                          
                          for (const ar of toDisable) {
                            if (isElectron && window.electronAPI?.toggleAutorun) {
                              await window.electronAPI.toggleAutorun(ar.name, ar.location, true, ar.command);
                            }
                            setAutoruns(prev => prev.map(a => 
                              a.name === ar.name && a.location === ar.location ? { ...a, enabled: false } : a
                            ));
                          }
                          if (addToast) addToast(`${toDisable.length} ${t('debloat.autoruns.programsDisabled')}`, 'success');
                        }}
                        data-testid="disable-all-autoruns"
                        className="justify-start h-12 border-white/10 text-white hover:bg-red-500/10 hover:border-red-500/30 rounded-xl"
                      >
                        <Power className="w-4 h-4 mr-3 text-red-400" />
                        {t('debloat.autoruns.disableAll')}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={async () => {
                          const toEnable = autoruns.filter(ar => !ar.enabled);
                          if (toEnable.length === 0) return;
                          
                          for (const ar of toEnable) {
                            if (isElectron && window.electronAPI?.toggleAutorun) {
                              await window.electronAPI.toggleAutorun(ar.name, ar.location, false, ar.command);
                            }
                            setAutoruns(prev => prev.map(a => 
                              a.name === ar.name && a.location === ar.location ? { ...a, enabled: true } : a
                            ));
                          }
                          if (addToast) addToast(`${toEnable.length} ${t('debloat.autoruns.programsEnabled')}`, 'success');
                        }}
                        data-testid="enable-all-autoruns"
                        className="justify-start h-12 border-white/10 text-white hover:bg-green-500/10 hover:border-green-500/30 rounded-xl"
                      >
                        <Play className="w-4 h-4 mr-3 text-green-400" />
                        {t('debloat.autoruns.enableAll')}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={loadAutoruns}
                        className="justify-start h-12 border-white/10 text-white hover:bg-blue-500/10 hover:border-blue-500/30 rounded-xl"
                      >
                        <RefreshCw className="w-4 h-4 mr-3 text-blue-400" />
                        {t('debloat.autoruns.refresh')}
                      </Button>
                    </div>
                  </div>
                </>
              )}
            </>
          )}
        </>
      )}
    </div>
    </LockedFeature>
  );
};

export default BloatwarePage;
