import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  HardDrive, 
  ExternalLink,
  Download,
  Info,
  Loader2,
  Settings
} from 'lucide-react';
import { Button } from '../ui/button';
import { useSettings } from '../../context/SettingsContext';
import CustomSelect from '../ui/CustomSelect';
import LockedFeature from '../ui/LockedFeature';
import { useLicense } from '../../hooks/useLicense';
import { FEATURE_CATEGORIES, LICENSE_TYPES } from '../../utils/licenseConfig';
import fortniteIcon from '../../assets/images/fortnite-icon.jpg';
import callofdutyIcon from '../../assets/images/callofduty-icon.png';

const DriversPage = () => {
  const { t } = useTranslation();
  const { isElectron, addToast } = useSettings();
  const { userLicense, checkFeatureAccess } = useLicense();
  const [isInstallingNVClean, setIsInstallingNVClean] = useState(false);
  const [isApplyingNPI, setIsApplyingNPI] = useState(false);
  const [installProgress, setInstallProgress] = useState('');
  const [selectedGame, setSelectedGame] = useState('fortnite'); // 'fortnite' ou 'callofduty'

  const handleInstallNvidiaSetup = async () => {
    setIsInstallingNVClean(true);
    const gameName = selectedGame === 'fortnite' ? 'Fortnite' : 'Call of Duty';
    setInstallProgress(t('hardware.nvidia.preparing') + ` ${gameName}...`);
    
    try {
      if (isElectron && window.electronAPI?.runNvidiaScript) {
        setInstallProgress(t('hardware.nvidia.downloading'));
        
        const gameParam = selectedGame === 'fortnite' ? '-nvidia' : '-callofduty';
        const result = await window.electronAPI.runNvidiaScript(gameParam);
        
        if (result.success) {
          if (addToast) {
            addToast(`✅ Setup ${gameName} lancé avec succès!`, 'success');
          }
        } else {
          if (addToast) {
            addToast(`❌ Erreur: ${result.error}`, 'error');
          }
        }
        return;
      }
      
      if (addToast) {
        addToast(t('hardware.electronRequired'), 'warning');
      }
      
    } catch (error) {
      console.error('Erreur lors de l\'installation NVIDIA:', error);
      if (addToast) {
        addToast('Erreur lors du téléchargement. Veuillez réessayer.', 'error');
      }
    } finally {
      setTimeout(() => {
        setIsInstallingNVClean(false);
        setInstallProgress('');
      }, 2000);
    }
  };

  const handleApplyNPI = async () => {
    setIsApplyingNPI(true);
    setInstallProgress('Application des paramètres NVIDIA...');
    
    try {
      if (isElectron && window.electronAPI?.runNPIScript) {
        setInstallProgress('Téléchargement de NVIDIA Profile Inspector...');
        
        const result = await window.electronAPI.runNPIScript();
        
        if (result.success) {
          if (addToast) {
            addToast('✅ Paramètres NVIDIA appliqués avec succès!', 'success');
          }
        } else {
          if (addToast) {
            addToast(`❌ Erreur: ${result.error}`, 'error');
          }
        }
        return;
      }
      
      if (addToast) {
        addToast('Cette fonctionnalité nécessite l\'application Electron', 'warning');
      }
      
    } catch (error) {
      console.error('Erreur lors de l\'application NPI:', error);
      if (addToast) {
        addToast('Erreur. Veuillez réessayer.', 'error');
      }
    } finally {
      setTimeout(() => {
        setIsApplyingNPI(false);
        setInstallProgress('');
      }, 2000);
    }
  };

  const handleOpenAMDDrivers = () => {
    const url = 'https://www.amd.com/en/support';
    if (isElectron && window.electronAPI?.openExternal) {
      window.electronAPI.openExternal(url);
    } else {
      window.open(url, '_blank');
    }
  };

  return (
    <LockedFeature
      requiredLicense={LICENSE_TYPES.LIFETIME}
      isLocked={!checkFeatureAccess(FEATURE_CATEGORIES.DRIVERS)}
      title={`👑 ${t('hardware.locked.title')}`}
      description={t('hardware.locked.description')}
    >
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-gradient-to-br from-[#ff3333]/20 to-[#ff3333]/5 rounded-2xl flex items-center justify-center border border-[#ff3333]/20">
            <HardDrive className="w-6 h-6 text-[#ff3333]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">{t('hardware.title')}</h1>
            <p className="text-[#666] text-sm">{t('hardware.subtitle')}</p>
          </div>
        </div>
      </div>

      {/* Section Pilotes GPU */}
      <div>
        <h2 className="text-white font-semibold mb-4 flex items-center gap-3">
          <span className="w-1 h-5 rounded-full bg-[#ff3333]"></span>
          {t('hardware.graphicsDrivers')}
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* NVIDIA */}
          <div className="bg-gradient-to-br from-[#151515] to-[#0d0d0d] border border-white/5 rounded-2xl p-6 hover:border-[#76b900]/30 transition-all duration-300 group">
            <div className="flex items-start gap-4 mb-4">
              <div className="w-14 h-14 bg-black rounded-2xl flex items-center justify-center border border-[#76b900]/20 overflow-hidden">
                <img 
                  src={process.env.PUBLIC_URL + "/nvidia-logo.jpg"} 
                  alt="NVIDIA" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1">
                <h3 className="text-white font-semibold text-lg">{t('hardware.nvidia.title')}</h3>
                <p className="text-[#666] text-sm mt-1">
                  {t('hardware.nvidia.subtitle')}
                </p>
              </div>
            </div>
            
            {/* Dropdown sélection du jeu */}
            <div className="mb-4">
              <label className="exm-label">{t('hardware.nvidia.selectGame')}</label>
              <CustomSelect
                value={selectedGame}
                onChange={(value) => setSelectedGame(value)}
                options={[
                  { 
                    value: 'fortnite', 
                    label: 'Fortnite',
                    iconUrl: fortniteIcon
                  },
                  { 
                    value: 'callofduty', 
                    label: 'Call of Duty',
                    iconUrl: callofdutyIcon
                  }
                ]}
                variant="nvidia-green"
                className="w-full"
              />
            </div>
            
            <div className="bg-[#76b900]/5 border border-[#76b900]/20 rounded-xl p-4 mb-4">
              <div className="flex items-start gap-3">
                <Info className="w-4 h-4 text-[#76b900] mt-0.5 flex-shrink-0" />
                <p className="text-[#888] text-xs">
                  {selectedGame === 'fortnite' 
                    ? t('hardware.nvidia.infoFortnite')
                    : t('hardware.nvidia.infoCallOfDuty')
                  }
                </p>
              </div>
            </div>
            
            <Button
              onClick={handleInstallNvidiaSetup}
              disabled={isInstallingNVClean}
              className="w-full bg-[#76b900] hover:bg-[#8bc34a] text-white rounded-xl py-3 font-medium transition-all disabled:opacity-50"
            >
              {isInstallingNVClean ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  {installProgress || t('hardware.nvidia.downloading')}
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 mr-2" />
                  {t('hardware.nvidia.installSetup')} {selectedGame === 'fortnite' ? 'Fortnite' : 'Call of Duty'}
                </>
              )}
            </Button>
          </div>

          {/* AMD */}
          <div className="bg-gradient-to-br from-[#151515] to-[#0d0d0d] border border-white/5 rounded-2xl p-6 hover:border-[#ed1c24]/30 transition-all duration-300 group">
            <div className="flex items-start gap-4 mb-4">
              <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center border border-[#ed1c24]/20 overflow-hidden p-1">
                <img 
                  src={process.env.PUBLIC_URL + "/amd-logo.png"} 
                  alt="AMD" 
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="flex-1">
                <h3 className="text-white font-semibold text-lg">{t('hardware.amd.title')}</h3>
                <p className="text-[#666] text-sm mt-1">
                  {t('hardware.amd.subtitle')}
                </p>
              </div>
            </div>
            
            <div className="bg-[#ed1c24]/5 border border-[#ed1c24]/20 rounded-xl p-4 mb-4">
              <div className="flex items-start gap-3">
                <Info className="w-4 h-4 text-[#ed1c24] mt-0.5 flex-shrink-0" />
                <p className="text-[#888] text-xs">
                  {t('hardware.amd.info')}
                </p>
              </div>
            </div>
            
            <Button
              onClick={handleOpenAMDDrivers}
              className="w-full bg-[#ed1c24] hover:bg-[#ff3333] text-white rounded-xl py-3 font-medium transition-all"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              {t('hardware.amd.openSupport')}
            </Button>
          </div>
        </div>
      </div>

      {/* Section NVIDIA Profile Inspector */}
      <div>
        <h2 className="text-white font-semibold mb-4 flex items-center gap-3">
          <span className="w-1 h-5 rounded-full bg-[#ff3333]"></span>
          {t('hardware.npi.title')}
        </h2>
        
        <div className="bg-gradient-to-br from-[#151515] to-[#0d0d0d] border border-white/5 rounded-2xl p-6">
          <div className="flex items-start gap-4 mb-4">
            <div className="w-14 h-14 bg-gradient-to-br from-[#76b900]/20 to-[#76b900]/5 rounded-2xl flex items-center justify-center border border-[#76b900]/20">
              <Settings className="w-7 h-7 text-[#76b900]" />
            </div>
            <div className="flex-1">
              <h3 className="text-white font-semibold text-lg">{t('hardware.npi.subtitle')}</h3>
              <p className="text-[#666] text-sm mt-1">
                {t('hardware.npi.description')}
              </p>
            </div>
          </div>
          
          <div className="bg-[#76b900]/5 border border-[#76b900]/20 rounded-xl p-4 mb-4">
            <div className="flex items-start gap-3">
              <Info className="w-4 h-4 text-[#76b900] mt-0.5 flex-shrink-0" />
              <div className="text-[#888] text-xs">
                <p className="mb-2">{t('hardware.npi.infoTitle')}</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>{t('hardware.npi.infoStep1')}</li>
                  <li>{t('hardware.npi.infoStep2')}</li>
                  <li>{t('hardware.npi.infoStep3')}</li>
                </ul>
              </div>
            </div>
          </div>
          
          <Button
            onClick={handleApplyNPI}
            disabled={isApplyingNPI}
            className="w-full bg-[#76b900] hover:bg-[#8bc34a] text-white rounded-xl py-3 font-medium transition-all disabled:opacity-50"
          >
            {isApplyingNPI ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                {installProgress || t('hardware.npi.applying')}
              </>
            ) : (
              <>
                <Settings className="w-4 h-4 mr-2" />
                {t('hardware.npi.applySettings')}
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
    </LockedFeature>
  );
};

export default DriversPage;
