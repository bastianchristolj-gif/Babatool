import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { CheckCircle2, AlertCircle } from 'lucide-react';
import { useSettings } from '../../context/SettingsContext';
import LockedFeature from '../ui/LockedFeature';
import { useLicense } from '../../hooks/useLicense';
import { FEATURE_CATEGORIES, LICENSE_TYPES } from '../../utils/licenseConfig';

const PrivacyPage = () => {
  const { t } = useTranslation();
  const { addToast } = useSettings();
  const { checkFeatureAccess } = useLicense();
  const [isApplying, setIsApplying] = useState(false);

  const applyOOSU10Profile = async () => {
    setIsApplying(true);
    
    try {
      // Check if we're in Electron
      if (window.electronAPI && window.electronAPI.executeOOSU10) {
        console.log('[OOSU10] Executing via Electron IPC...');
        const result = await window.electronAPI.executeOOSU10();
        
        if (result.success) {
          addToast(`✅ ${t('privacy.oosu10.successMessage')}`, 'success');
          if (result.output) {
            console.log('[OOSU10] Output:', result.output);
          }
        } else {
          addToast(`❌ ${result.message}`, 'error');
          if (result.output) {
            console.error('[OOSU10] Error output:', result.output);
          }
        }
      } else {
        // Fallback to backend API if not in Electron
        console.log('[OOSU10] Electron API not available, this feature requires Electron');
        addToast(`❌ ${t('privacy.oosu10.electronRequired')}`, 'error');
      }
    } catch (error) {
      console.error('[OOSU10] Error:', error);
      addToast(`❌ ${t('privacy.oosu10.errorMessage')}`, 'error');
    } finally {
      setIsApplying(false);
    }
  };

  return (
    <LockedFeature
      requiredLicense={LICENSE_TYPES.PREMIUM}
      isLocked={!checkFeatureAccess(FEATURE_CATEGORIES.PRIVACY)}
      title="🔒 Confidentialité - Premium"
      description="Protégez votre vie privée en désactivant la télémétrie et le suivi Windows. Disponible avec la licence Premium."
    >
    <div className="space-y-6 exm-fade-in">
      {/* Header */}
      <div>
        <h1 className="exm-section-title">{t('nav.privacy')}</h1>
        <p className="exm-section-subtitle">{t('privacy.subtitle')}</p>
      </div>

      {/* Main Card */}
      <div className="exm-card max-w-3xl mx-auto">
        <div className="flex items-start gap-4 mb-6">
          <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center flex-shrink-0">
            <img src={`${process.env.PUBLIC_URL}/oosu10-icon.jpg`} alt="OOSU10" className="w-12 h-12 object-contain" />
          </div>
          <div>
            <h2 className="text-white text-xl font-semibold mb-2">{t('privacy.oosu10.title')}</h2>
            <p className="text-[#888] text-sm leading-relaxed">
              {t('privacy.oosu10.description')}
            </p>
          </div>
        </div>

        {/* Features List */}
        <div className="space-y-3 mb-6">
          <div className="flex items-start gap-3 text-sm">
            <CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
            <span className="text-[#888]">{t('privacy.oosu10.feature1')}</span>
          </div>
          <div className="flex items-start gap-3 text-sm">
            <CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
            <span className="text-[#888]">{t('privacy.oosu10.feature2')}</span>
          </div>
          <div className="flex items-start gap-3 text-sm">
            <CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
            <span className="text-[#888]">{t('privacy.oosu10.feature3')}</span>
          </div>
          <div className="flex items-start gap-3 text-sm">
            <CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
            <span className="text-[#888]">{t('privacy.oosu10.feature4')}</span>
          </div>
        </div>

        {/* Warning */}
        <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-4 mb-6">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-amber-400 text-sm font-medium mb-1">{t('privacy.oosu10.warningTitle')}</p>
              <p className="text-[#888] text-xs leading-relaxed">
                {t('privacy.oosu10.warningDesc')}
              </p>
            </div>
          </div>
        </div>

        {/* Apply Button */}
        <button
          onClick={applyOOSU10Profile}
          disabled={isApplying}
          className="exm-btn-primary w-full flex items-center justify-center gap-2 disabled:opacity-50"
          data-testid="apply-oosu10-btn"
        >
          {isApplying ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>{t('privacy.oosu10.applying')}</span>
            </>
          ) : (
            <span>{t('privacy.oosu10.applyButton')}</span>
          )}
        </button>
      </div>

      {/* Info Card */}
      <div className="exm-card max-w-3xl mx-auto border-blue-500/20">
        <div className="flex items-start gap-3">
          <span className="text-blue-400 text-xl">ℹ️</span>
          <div>
            <p className="text-blue-400 text-sm font-medium mb-2">{t('privacy.oosu10.infoTitle')}</p>
            <p className="text-[#666] text-xs leading-relaxed">
              {t('privacy.oosu10.infoDesc')}
            </p>
          </div>
        </div>
      </div>
    </div>
    </LockedFeature>
  );
};

export default PrivacyPage;
