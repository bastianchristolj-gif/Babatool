import React, { useState, useEffect, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { Download, CheckCircle2, AlertCircle, RefreshCw, ArrowRight } from 'lucide-react';
import { APP_VERSION, APP_TYPE } from '../../lib/version';
import { callEdgeFunction } from '../../lib/supabase';

const UpdatesPage = () => {
  const { t } = useTranslation();
  const [updateInfo, setUpdateInfo] = useState(null);
  const [checking, setChecking] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [downloadStatus, setDownloadStatus] = useState('');
  const [error, setError] = useState(null);
  const [lastChecked, setLastChecked] = useState(null);

  const isElectron = typeof window !== 'undefined' && window.electronAPI?.isElectron;

  // Comparaison de versions
  const compareVersions = (current, latest) => {
    const currentParts = current.split('.').map(Number);
    const latestParts = latest.split('.').map(Number);
    
    for (let i = 0; i < Math.max(currentParts.length, latestParts.length); i++) {
      const a = currentParts[i] || 0;
      const b = latestParts[i] || 0;
      if (b > a) return true;
      if (a > b) return false;
    }
    return false;
  };

  // Vérifier les mises à jour
  const checkForUpdates = useCallback(async () => {
    setChecking(true);
    setError(null);
    
    try {
      const result = await callEdgeFunction('get-update-info', { app_type: APP_TYPE });
      
      if (result.success && result.update_available && result.version) {
        const latestVersion = result.version.version;
        if (compareVersions(APP_VERSION, latestVersion)) {
          setUpdateInfo(result.version);
        } else {
          setUpdateInfo(null);
        }
      } else {
        setUpdateInfo(null);
      }
      setLastChecked(new Date());
    } catch (err) {
      console.error('Update check failed:', err);
      setError('Impossible de vérifier les mises à jour');
    } finally {
      setChecking(false);
    }
  }, []);

  useEffect(() => {
    checkForUpdates();
  }, [checkForUpdates]);

  // Écouter le progrès du téléchargement
  useEffect(() => {
    if (!isElectron) return;

    const handleProgress = (data) => {
      setDownloadProgress(data.percentage || 0);
      setDownloadStatus(data.status || 'downloading');
    };

    if (window.electronAPI?.onDownloadProgress) {
      window.electronAPI.onDownloadProgress(handleProgress);
    }
    
    return () => {
      if (window.electronAPI?.removeDownloadProgressListener) {
        window.electronAPI.removeDownloadProgressListener();
      }
    };
  }, [isElectron]);

  // Télécharger et installer la mise à jour
  const handleUpdate = async () => {
    if (!updateInfo?.download_url) return;

    if (isElectron) {
      setDownloading(true);
      setError(null);
      setDownloadProgress(0);
      setDownloadStatus('Démarrage du téléchargement...');

      try {
        const result = await window.electronAPI.downloadUpdate(
          updateInfo.download_url,
          updateInfo.version
        );

        if (result.success && result.filePath) {
          setDownloadStatus('Installation en cours... L\'application va redémarrer automatiquement.');
          setDownloadProgress(100);
          await window.electronAPI.runSilentInstaller(result.filePath);
          // L'app va se fermer et la nouvelle version va se lancer automatiquement
        } else {
          setError(result.error || 'Échec du téléchargement');
          setDownloading(false);
        }
      } catch (err) {
        setError(err.message);
        setDownloading(false);
      }
    } else {
      window.open(updateInfo.download_url, '_blank');
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center gap-4">
        <div className="w-14 h-14 bg-gradient-to-br from-[#ff3333] to-[#cc0000] rounded-2xl flex items-center justify-center shadow-lg shadow-[#ff3333]/20">
          <Download className="w-7 h-7 text-white" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-white">{t('updates.title')}</h1>
          <p className="text-[#666] mt-1">{t('updates.subtitle')}</p>
        </div>
      </div>

      {/* Current Version Card */}
      <div className="bg-gradient-to-br from-[#151515] to-[#0d0d0d] rounded-3xl p-6 border border-white/5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl overflow-hidden">
              <img src={process.env.PUBLIC_URL + "/logo.png"} alt="BaBaTool" className="w-full h-full object-contain" />
            </div>
            <div>
              <h2 className="text-white font-semibold text-lg">BaBaTool</h2>
              <p className="text-[#666] text-sm">{t('updates.installedVersion')}: <span className="text-[#ff3333] font-mono">{APP_VERSION}</span></p>
            </div>
          </div>
          
          <button
            onClick={checkForUpdates}
            disabled={checking}
            className="flex items-center gap-2 px-5 py-3 bg-[#ff3333]/10 hover:bg-[#ff3333]/20 text-[#ff3333] rounded-xl font-medium transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${checking ? 'animate-spin' : ''}`} />
            {checking ? t('updates.checking') : t('updates.checkUpdates')}
          </button>
        </div>
        
        {lastChecked && (
          <p className="text-[#555] text-xs mt-4">
            {t('updates.lastChecked')}: {lastChecked.toLocaleString()}
          </p>
        )}
      </div>

      {/* Error */}
      {error && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-4 flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-red-400" />
          <p className="text-red-400">{error}</p>
        </div>
      )}

      {/* Update Available */}
      {updateInfo ? (
        <div className="bg-gradient-to-br from-[#ff3333]/10 to-[#ff3333]/5 rounded-3xl p-6 border border-[#ff3333]/20">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-12 h-12 bg-[#ff3333]/20 rounded-xl flex items-center justify-center">
              <Download className="w-6 h-6 text-[#ff3333]" />
            </div>
            <div className="flex-1">
              <h3 className="text-white font-semibold text-xl">{t('updates.updateAvailable')}</h3>
              <div className="flex items-center gap-2 mt-2">
                <span className="text-[#666] font-mono">{APP_VERSION}</span>
                <ArrowRight className="w-4 h-4 text-[#ff3333]" />
                <span className="text-[#ff3333] font-mono font-semibold">{updateInfo.version}</span>
              </div>
            </div>
          </div>

          {/* Patch Notes */}
          {updateInfo.patch_notes && (
            <div className="bg-[#0d0d0d] rounded-xl p-4 mb-6 border border-white/5">
              <h4 className="text-[#888] text-xs font-semibold uppercase mb-3">{t('updates.patchNotes')}</h4>
              <p className="text-gray-300 text-sm whitespace-pre-wrap">{updateInfo.patch_notes}</p>
            </div>
          )}

          {/* Download Progress */}
          {downloading && (
            <div className="mb-6">
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-400">{downloadStatus}</span>
                <span className="text-[#ff3333]">{downloadProgress}%</span>
              </div>
              <div className="h-2 bg-[#1a1a1a] rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-[#ff3333] to-[#ff6666] transition-all duration-300"
                  style={{ width: `${downloadProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Update Button */}
          <button
            onClick={handleUpdate}
            disabled={downloading}
            className="w-full py-4 bg-gradient-to-r from-[#ff3333] to-[#cc0000] hover:from-[#ff4444] hover:to-[#dd0000] text-white rounded-xl font-semibold transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {downloading ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                {t('updates.downloading')}
              </>
            ) : (
              <>
                <Download className="w-5 h-5" />
                {t('updates.downloadInstall')}
              </>
            )}
          </button>
        </div>
      ) : !checking && (
        <div className="bg-gradient-to-br from-[#ff3333]/10 to-[#ff3333]/5 rounded-3xl p-6 border border-[#ff3333]/20">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-[#ff3333]/20 rounded-xl flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6 text-[#ff6666]" />
            </div>
            <div>
              <h3 className="text-white font-semibold text-lg">{t('updates.upToDate')}</h3>
              <p className="text-[#666] text-sm">BaBaTool {APP_VERSION} {t('updates.upToDateDesc')}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UpdatesPage;
