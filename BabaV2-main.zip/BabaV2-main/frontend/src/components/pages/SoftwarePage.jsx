import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Globe, Rocket, Code, Sliders, Film, Download, Package, RefreshCw, CheckCircle, Loader2, AlertCircle } from 'lucide-react';

const SoftwarePage = () => {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState('browser');
  const [installing, setInstalling] = useState(null);
  const [chocoInstalling, setChocoInstalling] = useState(false);
  const [upgrading, setUpgrading] = useState(false);
  const [installResult, setInstallResult] = useState(null);

  const tabs = [
    { id: 'browser', labelKey: 'software.tabs.browser' },
    { id: 'launcher', labelKey: 'software.tabs.launcher' },
    { id: 'code', labelKey: 'software.tabs.code' },
    { id: 'customize', labelKey: 'software.tabs.customize' },
    { id: 'multimedia', labelKey: 'software.tabs.multimedia' },
  ];

  const softwareData = {
    browser: {
      icon: Globe,
      items: [
        { name: 'Google Chrome', descKey: 'software.apps.chrome.desc', icon: '🌐', chocoKey: 'chrome' },
        { name: 'Mozilla Firefox', descKey: 'software.apps.firefox.desc', icon: '🦊', chocoKey: 'firefox' },
        { name: 'Brave', descKey: 'software.apps.brave.desc', icon: '🦁', chocoKey: 'brave' },
        { name: 'Microsoft Edge', descKey: 'software.apps.edge.desc', icon: '📘', chocoKey: 'edge' },
        { name: 'Opera GX', descKey: 'software.apps.operagx.desc', icon: '🎮', chocoKey: 'operagx' },
      ]
    },
    launcher: {
      icon: Rocket,
      items: [
        { name: 'Steam', descKey: 'software.apps.steam.desc', icon: '🎮', chocoKey: 'steam' },
        { name: 'Epic Games', descKey: 'software.apps.epic.desc', icon: '🏰', chocoKey: 'epic' },
        { name: 'Minecraft', descKey: 'software.apps.minecraft.desc', icon: '⛏️', chocoKey: 'minecraft' },
      ]
    },
    code: {
      icon: Code,
      items: [
        { name: 'Visual Studio Code', descKey: 'software.apps.vscode.desc', icon: '💻', chocoKey: 'vscode' },
        { name: 'PyCharm', descKey: 'software.apps.pycharm.desc', icon: '🐍', chocoKey: 'pycharm' },
        { name: 'Notepad++', descKey: 'software.apps.notepadpp.desc', icon: '📝', chocoKey: 'notepadpp' },
        { name: 'Python', descKey: 'software.apps.python.desc', icon: '🐍', chocoKey: 'python' },
        { name: 'Node.js', descKey: 'software.apps.nodejs.desc', icon: '🟢', chocoKey: 'nodejs' },
        { name: 'Git', descKey: 'software.apps.git.desc', icon: '🔀', chocoKey: 'git' },
        { name: 'PowerShell', descKey: 'software.apps.powershell.desc', icon: '⚡', chocoKey: 'powershell' },
        { name: 'Windows Terminal', descKey: 'software.apps.terminal.desc', icon: '🖥️', chocoKey: 'terminal' },
      ]
    },
    customize: {
      icon: Sliders,
      items: [
        { name: 'StartAllBack', descKey: 'software.apps.startallback.desc', icon: '🪟', chocoKey: 'startallback' },
        { name: 'Windhawk', descKey: 'software.apps.windhawk.desc', icon: '🦅', chocoKey: 'windhawk' },
        { name: 'Rainmeter', descKey: 'software.apps.rainmeter.desc', icon: '🎨', chocoKey: 'rainmeter' },
        { name: 'Lively Wallpaper', descKey: 'software.apps.lively.desc', icon: '✨', chocoKey: 'lively' },
        { name: '7-Zip', descKey: 'software.apps.7zip.desc', icon: '📦', chocoKey: '7zip' },
      ]
    },
    multimedia: {
      icon: Film,
      items: [
        { name: 'Discord', descKey: 'software.apps.discord.desc', icon: '💬', chocoKey: 'discord' },
        { name: 'VLC Media Player', descKey: 'software.apps.vlc.desc', icon: '🎬', chocoKey: 'vlc' },
        { name: 'Spotify', descKey: 'software.apps.spotify.desc', icon: '🎵', chocoKey: 'spotify' },
        { name: 'OBS Studio', descKey: 'software.apps.obs.desc', icon: '📹', chocoKey: 'obs' },
      ]
    }
  };

  const currentData = softwareData[activeTab];

  // Vérifier si on est dans Electron
  const isElectron = window.electronAPI && typeof window.electronAPI.chocoInstallApp === 'function';

  // Installer Chocolatey
  const installChocolatey = async () => {
    setChocoInstalling(true);
    setInstallResult(null);
    
    try {
      if (isElectron) {
        const result = await window.electronAPI.installChocolatey();
        setInstallResult({
          success: result.success,
          message: result.success ? t('software.chocoInstalled') : result.error
        });
      } else {
        // Mode web - afficher un message
        setInstallResult({
          success: false,
          message: t('software.electronRequired')
        });
      }
    } catch (e) {
      console.error('Error installing Chocolatey:', e);
      setInstallResult({ success: false, message: e.message });
    }
    
    setChocoInstalling(false);
  };

  // Upgrade toutes les apps
  const upgradeAllApps = async () => {
    setUpgrading(true);
    setInstallResult(null);
    
    try {
      if (isElectron) {
        const result = await window.electronAPI.chocoUpgradeAll();
        setInstallResult({
          success: result.success,
          message: result.success ? t('software.allUpgraded') : result.error
        });
      } else {
        setInstallResult({
          success: false,
          message: t('software.electronRequired')
        });
      }
    } catch (e) {
      console.error('Error upgrading apps:', e);
      setInstallResult({ success: false, message: e.message });
    }
    
    setUpgrading(false);
  };

  // Installer une app
  const installApp = async (item) => {
    setInstalling(item.chocoKey);
    setInstallResult(null);
    
    try {
      if (isElectron) {
        const result = await window.electronAPI.chocoInstallApp(item.chocoKey);
        setInstallResult({
          success: result.success,
          message: result.success ? `${item.name} ${t('software.installed')}` : result.error
        });
      } else {
        setInstallResult({
          success: false,
          message: t('software.electronRequired')
        });
      }
    } catch (e) {
      console.error('Error installing app:', e);
      setInstallResult({ success: false, message: e.message });
    }
    
    setInstalling(null);
  };

  return (
    <div className="space-y-6">
      {/* Header avec boutons Chocolatey */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#ff3333]/10 flex items-center justify-center">
            <Package className="w-6 h-6 text-[#ff3333]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Software</h1>
            <p className="text-[#666] text-sm">{t('software.subtitle')}</p>
          </div>
        </div>

        {/* Boutons Chocolatey */}
        <div className="flex items-center gap-3">
          <button
            onClick={installChocolatey}
            disabled={chocoInstalling}
            data-testid="install-choco-btn"
            className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 bg-[#1e1e1e] text-[#ff3333] hover:bg-[#ff3333] hover:text-white disabled:opacity-50"
          >
            {chocoInstalling ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Download className="w-4 h-4" />
            )}
            {t('software.installChoco')}
          </button>
          <button
            onClick={upgradeAllApps}
            disabled={upgrading}
            data-testid="upgrade-all-btn"
            className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 bg-[#ff3333] text-white hover:bg-[#ff4444] disabled:opacity-50"
          >
            {upgrading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <RefreshCw className="w-4 h-4" />
            )}
            {t('software.upgradeAll')}
          </button>
        </div>
      </div>

      {/* Résultat de l'installation */}
      {installResult && (
        <div 
          className={`p-4 rounded-xl flex items-center gap-3 ${
            installResult.success 
              ? 'bg-green-500/10 border border-green-500/20' 
              : 'bg-red-500/10 border border-red-500/20'
          }`}
        >
          {installResult.success ? (
            <CheckCircle className="w-5 h-5 text-green-500" />
          ) : (
            <AlertCircle className="w-5 h-5 text-red-500" />
          )}
          <span className={installResult.success ? 'text-green-400' : 'text-red-400'}>
            {installResult.message}
          </span>
        </div>
      )}

      {/* Tabs Navigation */}
      <div className="relative">
        <div className="flex gap-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              data-testid={`tab-${tab.id}`}
              className={`relative pb-3 text-sm font-medium transition-all duration-300 ${
                activeTab === tab.id
                  ? 'text-white'
                  : 'text-[#555] hover:text-[#888]'
              }`}
            >
              {t(tab.labelKey)}
              {activeTab === tab.id && (
                <div className="absolute bottom-0 left-0 right-0 h-[3px] bg-white rounded-full" />
              )}
            </button>
          ))}
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-[#1e1e1e]" />
      </div>

      {/* Software Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
        {currentData.items.map((item, index) => (
          <div
            key={index}
            className="group p-4 rounded-xl transition-all duration-200 hover:scale-[1.02] hover:border-[#ff3333]/30"
            style={{ background: '#141414', border: '1px solid #1e1e1e' }}
          >
            <div className="flex items-start gap-3">
              <span className="text-2xl">{item.icon}</span>
              <div className="flex-1 min-w-0">
                <h3 className="text-white font-medium text-sm">{item.name}</h3>
                <p className="text-[#666] text-xs mt-0.5">{t(item.descKey)}</p>
              </div>
            </div>
            <button
              onClick={() => installApp(item)}
              disabled={installing === item.chocoKey}
              data-testid={`install-${item.chocoKey}`}
              className="w-full mt-4 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 bg-[#1e1e1e] text-[#ff3333] hover:bg-[#ff3333] hover:text-white disabled:opacity-50"
            >
              {installing === item.chocoKey ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Download className="w-4 h-4" />
              )}
              {t('software.install')}
            </button>
          </div>
        ))}
      </div>

      {/* Info Card */}
      <div 
        className="p-4 rounded-xl mt-6"
        style={{ background: 'rgba(255, 51, 51, 0.05)', border: '1px solid rgba(255, 51, 51, 0.1)' }}
      >
        <p className="text-[#888] text-sm">
          💡 {t('software.info')}
        </p>
      </div>
    </div>
  );
};

export default SoftwarePage;
