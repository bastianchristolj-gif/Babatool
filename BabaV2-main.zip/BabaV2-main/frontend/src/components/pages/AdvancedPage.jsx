import React, { useState, useEffect, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { Zap, Search, AlertTriangle, RefreshCw, Loader2, CheckCircle2 } from 'lucide-react';
import { Input } from '../ui/input';
import SettingsCard from '../SettingsCard';
import { useSettings } from '../../context/SettingsContext';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '../ui/alert-dialog';

const AdvancedPage = () => {
  const { t } = useTranslation();
  const { advancedSettings, toggleAdvanced, setAdvancedSettings } = useSettings();
  const [searchQuery, setSearchQuery] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [pendingToggle, setPendingToggle] = useState(null);
  const [isElectron, setIsElectron] = useState(false);
  const [isLoadingStates, setIsLoadingStates] = useState(true);
  const [statesDetected, setStatesDetected] = useState(false);

  // Check if running in Electron
  useEffect(() => {
    setIsElectron(typeof window !== 'undefined' && window.electronAPI?.isElectron);
  }, []);

  // Load real system states on mount
  useEffect(() => {
    if (isElectron) {
      loadRealStates();
    } else {
      setIsLoadingStates(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isElectron]);

  /**
   * Load real Windows states for all advanced settings
   */
  const loadRealStates = useCallback(async () => {
    setIsLoadingStates(true);
    try {
      if (window.electronAPI?.readMultipleSettings) {
        const settingIds = advancedSettings.map(s => s.id);
        console.log('[AdvancedPage] Loading real states for:', settingIds);
        
        const realStates = await window.electronAPI.readMultipleSettings(settingIds);
        console.log('[AdvancedPage] Real states loaded:', realStates);
        
        // Update settings with real states
        const updatedSettings = advancedSettings.map(setting => {
          if (realStates[setting.id] !== null && realStates[setting.id] !== undefined) {
            return { ...setting, enabled: realStates[setting.id] };
          }
          return setting;
        });
        
        setAdvancedSettings(updatedSettings);
        setStatesDetected(true);
        console.log('[AdvancedPage] ✓ Real states applied');
      }
    } catch (error) {
      console.error('[AdvancedPage] Error loading real states:', error);
    } finally {
      setIsLoadingStates(false);
    }
  }, [advancedSettings, setAdvancedSettings]);

  const handleToggle = (id) => {
    const setting = advancedSettings.find(s => s.id === id);
    if (setting?.warning && setting.enabled) {
      setPendingToggle(id);
      setDialogOpen(true);
    } else {
      toggleAdvanced(id);
    }
  };

  const confirmToggle = () => {
    if (pendingToggle) {
      toggleAdvanced(pendingToggle);
    }
    setDialogOpen(false);
    setPendingToggle(null);
  };

  const filteredSettings = advancedSettings.filter(s => 
    t(s.titleKey).toLowerCase().includes(searchQuery.toLowerCase()) ||
    t(s.descriptionKey).toLowerCase().includes(searchQuery.toLowerCase())
  );

  const categories = [...new Set(filteredSettings.map(s => t(s.categoryKey)))];

  return (
    <div className="space-y-6">
      {/* Loading overlay */}
      {isLoadingStates && isElectron && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="bg-[#1a1a1a] border border-white/10 rounded-xl p-6 flex flex-col items-center gap-4">
            <Loader2 className="w-8 h-8 text-[#ff3333] animate-spin" />
            <div className="text-center">
              <p className="text-white font-medium">{t('common.loadingWindowsSettings')}</p>
              <p className="text-[#666] text-sm mt-1">{t('advanced.readingAdvancedSettings')}</p>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-gradient-to-br from-[#ff3333]/20 to-[#ff3333]/5 rounded-2xl flex items-center justify-center border border-[#ff3333]/20">
            <Zap className="w-6 h-6 text-[#ff3333]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">{t('advanced.title')}</h1>
            <p className="text-[#666] text-sm">{t('advanced.subtitle')}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {/* Detection status badge */}
          {statesDetected && !isLoadingStates && isElectron && (
            <div className="flex items-center gap-2 px-3 py-1.5 bg-green-500/10 border border-green-500/20 rounded-lg">
              <CheckCircle2 className="w-4 h-4 text-green-500" />
              <span className="text-green-500 text-xs font-medium">{t('common.windowsStatesDetected')}</span>
            </div>
          )}
          {isElectron && (
            <button 
              onClick={loadRealStates}
              disabled={isLoadingStates}
              className="px-4 py-2 bg-[#1a1a1a] border border-white/10 rounded-xl text-white text-sm flex items-center gap-2 hover:bg-[#222] transition-colors disabled:opacity-50"
            >
              {isLoadingStates ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <RefreshCw className="w-4 h-4" />
              )}
              <span>{isLoadingStates ? t('common.detecting') : t('common.refresh')}</span>
            </button>
          )}
        </div>
      </div>

      {/* Warning Banner */}
      <div className="bg-gradient-to-r from-[#ff3333]/10 to-[#ff3333]/5 border border-[#ff3333]/20 rounded-2xl p-5 flex items-start gap-4">
        <div className="w-10 h-10 bg-[#ff3333]/20 rounded-xl flex items-center justify-center flex-shrink-0">
          <AlertTriangle className="w-5 h-5 text-[#ff6666]" />
        </div>
        <div>
          <h3 className="text-[#ff6666] font-semibold text-sm">{t('advanced.warningBanner.title')}</h3>
          <p className="text-[#888] text-sm mt-1">
            {t('advanced.warningBanner.description')}
          </p>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#666]" />
        <Input
          placeholder={t('advanced.searchPlaceholder')}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-11 h-12 bg-[#111] border-white/10 text-white placeholder:text-[#555] focus:border-[#ff3333]/50 focus:ring-[#ff3333]/20 rounded-xl"
        />
      </div>

      {/* Settings by Category */}
      {categories.map(category => (
        <div key={category}>
          <h2 className="text-white font-semibold mb-4 flex items-center gap-3">
            <span className="w-2 h-2 rounded-full bg-[#ff3333]"></span>
            {category}
          </h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filteredSettings
              .filter(s => t(s.categoryKey) === category)
              .map(setting => (
                <SettingsCard 
                  key={setting.id} 
                  setting={{
                    ...setting,
                    title: t(setting.titleKey),
                    description: t(setting.descriptionKey),
                    category: t(setting.categoryKey)
                  }} 
                  onToggle={handleToggle}
                  accentColor="#ff3333"
                />
              ))}
          </div>
        </div>
      ))}

      {filteredSettings.length === 0 && (
        <div className="text-center py-12">
          <p className="text-[#666]">{t('advanced.noResults')} "{searchQuery}"</p>
        </div>
      )}

      {/* Confirmation Dialog */}
      <AlertDialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <AlertDialogContent className="bg-[#151515] border-white/10">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-[#ff3333]" />
              {t('advanced.confirmDialog.title')}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[#888]">
              {t('advanced.confirmDialog.description')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-[#1a1a1a] border-white/10 text-white hover:bg-[#222]">
              {t('advanced.confirmDialog.cancel')}
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmToggle}
              className="bg-[#ff3333] hover:bg-[#cc0000] text-white"
            >
              {t('advanced.confirmDialog.confirm')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default AdvancedPage;
