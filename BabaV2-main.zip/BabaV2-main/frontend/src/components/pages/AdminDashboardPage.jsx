import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import AdminVersionsPanel from '../AdminVersionsPanel';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const AdminDashboardPage = () => {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [licenses, setLicenses] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedLicense, setSelectedLicense] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterPlan, setFilterPlan] = useState('all');
  const [openMenuId, setOpenMenuId] = useState(null);
  const navigate = useNavigate();

  const getAuthHeaders = () => {
    const token = localStorage.getItem('admin_token');
    if (!token) {
      navigate('/admin/login');
      return null;
    }
    return { Authorization: `Bearer ${token}` };
  };

  const fetchData = async () => {
    const headers = getAuthHeaders();
    if (!headers) return;

    try {
      const [licensesRes, statsRes] = await Promise.all([
        axios.get(`${BACKEND_URL}/api/admin/licenses`, { headers }),
        axios.get(`${BACKEND_URL}/api/admin/stats`, { headers })
      ]);
      setLicenses(licensesRes.data);
      setStats(statsRes.data);
    } catch (err) {
      if (err.response?.status === 401) {
        localStorage.removeItem('admin_token');
        navigate('/admin/login');
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('admin_token');
    navigate('/admin/login');
  };

  const handleCreateLicense = async (formData) => {
    const headers = getAuthHeaders();
    if (!headers) return;

    try {
      await axios.post(
        `${BACKEND_URL}/api/admin/licenses`,
        formData,
        { headers }
      );
      setShowCreateModal(false);
      fetchData();
    } catch (err) {
      alert('Error creating license');
    }
  };

  const handleUpdateLicense = async (licenseId, formData) => {
    const headers = getAuthHeaders();
    if (!headers) return;

    try {
      await axios.put(
        `${BACKEND_URL}/api/admin/licenses/${licenseId}`,
        formData,
        { headers }
      );
      setShowEditModal(false);
      setSelectedLicense(null);
      fetchData();
    } catch (err) {
      alert('Error updating license');
    }
  };

  const handleDeleteLicense = async (licenseId) => {
    if (!window.confirm('Êtes-vous sûr de vouloir supprimer cette licence ?')) return;

    const headers = getAuthHeaders();
    if (!headers) return;

    try {
      await axios.delete(
        `${BACKEND_URL}/api/admin/licenses/${licenseId}`,
        { headers }
      );
      setOpenMenuId(null);
      fetchData();
    } catch (err) {
      alert('Error deleting license');
    }
  };

  const handleCopyKey = (key) => {
    try {
      navigator.clipboard.writeText(key);
    } catch (err) {
      // Fallback for browsers without clipboard permission
      const textArea = document.createElement('textarea');
      textArea.value = key;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
    }
    setOpenMenuId(null);
  };

  const handleResetHWID = async (licenseId) => {
    if (!window.confirm('Réinitialiser le HWID pour cette licence ?')) return;

    const headers = getAuthHeaders();
    if (!headers) return;

    try {
      await axios.put(
        `${BACKEND_URL}/api/admin/licenses/${licenseId}`,
        { hwid_hash: null },
        { headers }
      );
      setOpenMenuId(null);
      fetchData();
    } catch (err) {
      alert('Error resetting HWID');
    }
  };

  const handleBanLicense = async (licenseId) => {
    const headers = getAuthHeaders();
    if (!headers) return;

    try {
      await axios.put(
        `${BACKEND_URL}/api/admin/licenses/${licenseId}`,
        { status: 'suspended' },
        { headers }
      );
      setOpenMenuId(null);
      fetchData();
    } catch (err) {
      alert('Error banning license');
    }
  };

  const handleUnbanLicense = async (licenseId) => {
    const headers = getAuthHeaders();
    if (!headers) return;

    try {
      await axios.put(
        `${BACKEND_URL}/api/admin/licenses/${licenseId}`,
        { status: 'active' },
        { headers }
      );
      setOpenMenuId(null);
      fetchData();
    } catch (err) {
      alert('Error unbanning license');
    }
  };

  const filteredLicenses = licenses.filter(lic => {
    const matchesSearch = lic.license_key.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (lic.hwid_hash && lic.hwid_hash.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (lic.pseudo && lic.pseudo.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesStatus = filterStatus === 'all' || lic.status === filterStatus;
    const matchesPlan = filterPlan === 'all' || 
      (filterPlan === 'lifetime' && !lic.expires_at && lic.plan === 'lifetime') ||
      (filterPlan === 'premium' && lic.plan === 'premium') ||
      (filterPlan === 'trial' && lic.plan === 'trial');
    return matchesSearch && matchesStatus && matchesPlan;
  });

  // Calculate stats from licenses
  const calcStats = {
    total: licenses.length,
    active: licenses.filter(l => l.status === 'active').length,
    inactive: licenses.filter(l => !l.hwid_hash && l.status === 'active').length,
    banned: licenses.filter(l => l.status === 'suspended').length,
    expired: licenses.filter(l => l.status === 'expired').length,
    lifetime: licenses.filter(l => l.plan === 'lifetime').length,
    premium: licenses.filter(l => l.plan === 'premium').length,
    trial: licenses.filter(l => l.plan === 'trial').length
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="text-white">Chargement...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white flex" data-testid="admin-dashboard">
      {/* Sidebar */}
      <aside className="w-64 bg-[#0a0a0a] border-r border-gray-800 flex flex-col">
        {/* Logo */}
        <div className="p-6 border-b border-gray-800">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center overflow-hidden">
              <img src={process.env.PUBLIC_URL + "/logo.png"} alt="BaBaTool" className="w-full h-full object-contain" />
            </div>
            <span className="text-lg font-semibold text-[#ff3333]">BaBaTool</span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-1">
          <button
            onClick={() => setCurrentPage('dashboard')}
            data-testid="nav-dashboard"
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition ${
              currentPage === 'dashboard' 
                ? 'bg-[#ff3333]/20 text-[#ff3333] border-l-4 border-[#ff3333]' 
                : 'text-gray-400 hover:bg-gray-800/50'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
            </svg>
            <span>Dashboard</span>
            {currentPage === 'dashboard' && <span className="ml-auto">›</span>}
          </button>

          <button
            onClick={() => setCurrentPage('licenses')}
            data-testid="nav-licenses"
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition ${
              currentPage === 'licenses' 
                ? 'bg-[#ff3333]/20 text-[#ff3333] border-l-4 border-[#ff3333]' 
                : 'text-gray-400 hover:bg-gray-800/50'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
            </svg>
            <span>Licenses</span>
          </button>

          <button
            onClick={() => setCurrentPage('versions')}
            data-testid="nav-versions"
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition ${
              currentPage === 'versions' 
                ? 'bg-[#ff3333]/20 text-[#ff3333] border-l-4 border-[#ff3333]' 
                : 'text-gray-400 hover:bg-gray-800/50'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            <span>Versions</span>
          </button>
        </nav>

        {/* Logout */}
        <div className="p-4 border-t border-gray-800">
          <button
            onClick={handleLogout}
            data-testid="logout-btn"
            className="w-full flex items-center gap-3 px-4 py-3 text-gray-400 hover:text-red-400 hover:bg-[#ff3333]/10 rounded-lg transition"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
            </svg>
            <span>Déconnexion</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {currentPage === 'dashboard' ? (
          <DashboardView stats={calcStats} licenses={licenses} />
        ) : currentPage === 'versions' ? (
          <AdminVersionsPanel />
        ) : (
          <LicensesView
            licenses={filteredLicenses}
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            filterStatus={filterStatus}
            setFilterStatus={setFilterStatus}
            filterPlan={filterPlan}
            setFilterPlan={setFilterPlan}
            openMenuId={openMenuId}
            setOpenMenuId={setOpenMenuId}
            onCreateClick={() => setShowCreateModal(true)}
            onEdit={(lic) => {
              setSelectedLicense(lic);
              setShowEditModal(true);
              setOpenMenuId(null);
            }}
            onCopyKey={handleCopyKey}
            onResetHWID={handleResetHWID}
            onBan={handleBanLicense}
            onUnban={handleUnbanLicense}
            onDelete={handleDeleteLicense}
          />
        )}
      </main>

      {/* Modals */}
      {showCreateModal && (
        <CreateLicenseModal 
          onClose={() => setShowCreateModal(false)} 
          onCreate={handleCreateLicense} 
        />
      )}

      {showEditModal && selectedLicense && (
        <EditLicenseModal
          license={selectedLicense}
          onClose={() => {
            setShowEditModal(false);
            setSelectedLicense(null);
          }}
          onUpdate={handleUpdateLicense}
        />
      )}
    </div>
  );
};

// ============================================================================
// Dashboard View
// ============================================================================
const DashboardView = ({ stats, licenses }) => {
  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white">Dashboard</h1>
          <p className="text-gray-500 text-sm mt-1">License management overview</p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 bg-green-500/20 text-green-400 rounded-full text-sm">
          <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
          System Online
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-5 gap-4 mb-8">
        <StatCard 
          label="Total Licenses" 
          value={stats.total} 
          icon={<KeyIcon className="text-[#ff3333]" />}
          bgColor="bg-[#ff3333]/10"
        />
        <StatCard 
          label="Active" 
          value={stats.active} 
          icon={<CheckCircleIcon className="text-green-400" />}
          bgColor="bg-green-500/10"
        />
        <StatCard 
          label="Inactive" 
          value={stats.inactive} 
          icon={<XCircleIcon className="text-gray-400" />}
          bgColor="bg-gray-500/10"
        />
        <StatCard 
          label="Banned" 
          value={stats.banned} 
          icon={<BanIcon className="text-red-400" />}
          bgColor="bg-[#ff3333]/10"
        />
        <StatCard 
          label="Expired" 
          value={stats.expired} 
          icon={<ClockIcon className="text-yellow-400" />}
          bgColor="bg-yellow-500/10"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-3 gap-6 mb-8">
        {/* Status Distribution */}
        <div className="bg-[#111] border border-gray-800 rounded-xl p-6">
          <h3 className="text-white font-semibold mb-6">Status Distribution</h3>
          <div className="flex justify-center">
            <DonutChart 
              data={[
                { value: stats.active, color: '#22c55e', label: 'Active' },
                { value: stats.inactive, color: '#6b7280', label: 'Inactive' },
                { value: stats.banned, color: '#ef4444', label: 'Banned' },
                { value: stats.expired, color: '#f59e0b', label: 'Expired' }
              ]} 
            />
          </div>
          <div className="flex justify-center gap-6 mt-4">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 bg-gray-500 rounded"></span>
              <span className="text-gray-400 text-sm">Inactive</span>
            </div>
          </div>
        </div>

        {/* Plan Distribution */}
        <div className="bg-[#111] border border-gray-800 rounded-xl p-6">
          <h3 className="text-white font-semibold mb-6">Plan Distribution</h3>
          <div className="flex justify-center">
            <DonutChart 
              data={[
                { value: stats.lifetime, color: '#76b900', label: 'Lifetime' },
                { value: stats.premium, color: '#ff3333', label: 'Premium' },
                { value: stats.trial, color: '#666666', label: 'Trial' }
              ]} 
              color="#76b900"
            />
          </div>
          <div className="flex justify-center gap-6 mt-4">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 bg-[#76b900] rounded"></span>
              <span className="text-gray-400 text-sm">Lifetime</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 bg-[#ff3333] rounded"></span>
              <span className="text-gray-400 text-sm">Premium</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 bg-[#666666] rounded"></span>
              <span className="text-gray-400 text-sm">Trial</span>
            </div>
          </div>
        </div>

        {/* Plans Overview */}
        <div className="bg-[#111] border border-gray-800 rounded-xl p-6">
          <h3 className="text-white font-semibold mb-6">Plans Overview</h3>
          <div className="space-y-4">
            <PlanOverviewItem 
              icon={<LightningIcon className="text-[#666666]" />}
              label="Trial"
              count={stats.trial}
              bgColor="bg-[#666666]/20"
            />
            <PlanOverviewItem 
              icon={<StarIcon className="text-[#ff3333]" />}
              label="Premium"
              count={stats.premium}
              bgColor="bg-[#ff3333]/20"
            />
            <PlanOverviewItem 
              icon={<CrownIcon className="text-[#76b900]" />}
              label="Lifetime"
              count={stats.lifetime}
              bgColor="bg-[#76b900]/20"
            />
          </div>
        </div>
      </div>

      {/* Admin Credentials - Removed as per user request */}
    </div>
  );
};

// ============================================================================
// Licenses View
// ============================================================================
const LicensesView = ({ 
  licenses, 
  searchTerm, 
  setSearchTerm, 
  filterStatus, 
  setFilterStatus, 
  filterPlan, 
  setFilterPlan,
  openMenuId,
  setOpenMenuId,
  onCreateClick, 
  onEdit, 
  onCopyKey, 
  onResetHWID, 
  onBan,
  onUnban, 
  onDelete 
}) => {
  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white">Licenses</h1>
          <p className="text-gray-500 text-sm mt-1">Manage your license keys</p>
        </div>
        <button
          onClick={onCreateClick}
          data-testid="create-license-btn"
          className="px-5 py-2.5 bg-[#ff3333] hover:bg-[#cc0000] rounded-lg font-medium transition flex items-center gap-2"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          Create License
        </button>
      </div>

      {/* Search and Filters */}
      <div className="bg-[#111] border border-gray-800 rounded-xl p-4 mb-6">
        <div className="flex gap-4">
          <div className="flex-1 relative">
            <svg className="w-5 h-5 text-gray-500 absolute left-3 top-1/2 -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by key or HWID..."
              data-testid="search-input"
              className="w-full bg-[#0a0a0a] border border-gray-800 rounded-lg pl-10 pr-4 py-2.5 text-white placeholder-gray-600 focus:outline-none focus:border-gray-600 transition"
            />
          </div>
          <div className="flex gap-3">
            <div className="relative">
              <svg className="w-4 h-4 text-gray-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
              </svg>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                data-testid="filter-status"
                className="bg-[#0a0a0a] border border-gray-800 rounded-lg pl-9 pr-8 py-2.5 text-white focus:outline-none focus:border-gray-600 transition appearance-none cursor-pointer"
              >
                <option value="all">All Status</option>
                <option value="active">Active</option>
                <option value="suspended">Banned</option>
                <option value="expired">Expired</option>
              </select>
              <svg className="w-4 h-4 text-gray-500 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </div>
            <div className="relative">
              <select
                value={filterPlan}
                onChange={(e) => setFilterPlan(e.target.value)}
                data-testid="filter-plan"
                className="bg-[#0a0a0a] border border-gray-800 rounded-lg pl-4 pr-8 py-2.5 text-white focus:outline-none focus:border-gray-600 transition appearance-none cursor-pointer"
              >
                <option value="all">All Plans</option>
                <option value="trial">Trial</option>
                <option value="premium">Premium</option>
                <option value="lifetime">Lifetime</option>
              </select>
              <svg className="w-4 h-4 text-gray-500 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-[#111] border border-gray-800 rounded-xl">
        <div className="max-h-[600px] overflow-y-auto">
          <table className="w-full">
          <thead className="bg-[#111]">
            <tr className="border-b border-gray-800">
              <th className="text-left py-4 px-6 text-gray-500 font-normal text-sm">License Key</th>
              <th className="text-left py-4 px-6 text-gray-500 font-normal text-sm">Status</th>
              <th className="text-left py-4 px-6 text-gray-500 font-normal text-sm">Plan</th>
              <th className="text-left py-4 px-6 text-gray-500 font-normal text-sm">HWID</th>
              <th className="text-left py-4 px-6 text-gray-500 font-normal text-sm">Created</th>
              <th className="text-left py-4 px-6 text-gray-500 font-normal text-sm">Actions</th>
            </tr>
          </thead>
          <tbody>
            {licenses.map((lic) => (
              <tr key={lic.id} className="border-b border-gray-800/50 hover:bg-white/[0.02] transition" data-testid={`license-row-${lic.id}`}>
                <td className="py-4 px-6">
                  <div className="flex items-center gap-2">
                    <code className="text-gray-300 text-sm font-mono">{lic.license_key.substring(0, 14)}...</code>
                    <button
                      onClick={() => onCopyKey(lic.license_key)}
                    className="text-gray-600 hover:text-gray-300 transition p-1"
                    data-testid={`copy-key-${lic.id}`}
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                    </svg>
                  </button>
                </div>
              </td>
              <td className="py-4 px-6">
                <StatusBadge status={lic.status} />
              </td>
              <td className="py-4 px-6">
                <PlanBadge expiresAt={lic.expires_at} plan={lic.plan} />
              </td>
              <td className="py-4 px-6">
                <code className="text-gray-500 text-xs">
                  {lic.hwid_hash ? lic.hwid_hash.substring(0, 16) + '...' : '-'}
                </code>
              </td>
              <td className="py-4 px-6">
                <span className="text-gray-400 text-sm">
                  {new Date(lic.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                </span>
              </td>
              <td className="py-4 px-6">
                <ActionsMenu
                  license={lic}
                  isOpen={openMenuId === lic.id}
                  onToggle={() => setOpenMenuId(openMenuId === lic.id ? null : lic.id)}
                  onEdit={() => onEdit(lic)}
                  onCopyKey={() => onCopyKey(lic.license_key)}
                  onResetHWID={() => onResetHWID(lic.id)}
                  onBan={() => onBan(lic.id)}
                  onUnban={() => onUnban(lic.id)}
                  onDelete={() => onDelete(lic.id)}
                  onClose={() => setOpenMenuId(null)}
                />
              </td>
            </tr>
          ))}
        </tbody>
        </table>
        </div>
        {licenses.length === 0 && (
          <div className="text-center py-16 text-gray-600">
            <p>Aucune licence trouvée</p>
          </div>
        )}
      </div>
    </div>
  );
};

// ============================================================================
// Components
// ============================================================================

const StatCard = ({ label, value, icon, bgColor }) => (
  <div className={`${bgColor} border border-gray-800 rounded-xl p-5`}>
    <div className="flex items-center justify-between">
      <div>
        <p className="text-gray-500 text-sm">{label}</p>
        <p className="text-3xl font-bold text-white mt-1">{value}</p>
      </div>
      <div className="text-2xl">{icon}</div>
    </div>
  </div>
);

const PlanOverviewItem = ({ icon, label, count, bgColor }) => (
  <div className={`flex items-center justify-between ${bgColor} rounded-lg px-4 py-3`}>
    <div className="flex items-center gap-3">
      {icon}
      <span className="text-gray-300">{label}</span>
    </div>
    <span className="text-white font-semibold">{count}</span>
  </div>
);

const DonutChart = ({ data }) => {
  const total = data.reduce((sum, item) => sum + item.value, 0);
  if (total === 0) {
    return (
      <div className="w-40 h-40 rounded-full border-[20px] border-gray-700 flex items-center justify-center">
        <span className="text-gray-500 text-sm">No data</span>
      </div>
    );
  }
  
  let currentAngle = 0;
  const segments = data.filter(d => d.value > 0).map(item => {
    const angle = (item.value / total) * 360;
    const segment = { ...item, startAngle: currentAngle, endAngle: currentAngle + angle };
    currentAngle += angle;
    return segment;
  });

  // Simple arc visualization
  const primaryColor = segments[0]?.color || '#6b7280';
  
  return (
    <div className="relative w-40 h-40">
      <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
        <circle cx="50" cy="50" r="40" fill="none" stroke="#1f2937" strokeWidth="20" />
        {segments.map((seg, i) => {
          const circumference = 2 * Math.PI * 40;
          const dashLength = (seg.endAngle - seg.startAngle) / 360 * circumference;
          const dashOffset = (seg.startAngle / 360) * circumference;
          return (
            <circle
              key={i}
              cx="50"
              cy="50"
              r="40"
              fill="none"
              stroke={seg.color}
              strokeWidth="20"
              strokeDasharray={`${dashLength} ${circumference - dashLength}`}
              strokeDashoffset={-dashOffset}
            />
          );
        })}
      </svg>
    </div>
  );
};

const StatusBadge = ({ status }) => {
  const config = {
    active: { bg: 'bg-green-500/20 border-green-500/30', text: 'text-green-400', label: 'ACTIVE' },
    expired: { bg: 'bg-orange-500/20 border-orange-500/30', text: 'text-orange-400', label: 'EXPIRED' },
    suspended: { bg: 'bg-[#ff3333]/20 border-[#ff3333]/30', text: 'text-red-400', label: 'BANNED' },
  };

  const { bg, text, label } = config[status] || { bg: 'bg-gray-500/20 border-gray-500/30', text: 'text-gray-400', label: 'INACTIVE' };

  return (
    <span className={`px-3 py-1 ${bg} ${text} border rounded text-xs font-bold uppercase`}>
      {label}
    </span>
  );
};

const PlanBadge = ({ expiresAt, plan }) => {
  if (plan === 'trial') {
    return <span className="px-3 py-1 bg-[#666666]/20 border border-[#666666]/30 text-[#999999] rounded text-xs font-bold uppercase">TRIAL</span>;
  }
  if (plan === 'premium') {
    return <span className="px-3 py-1 bg-[#ff3333]/20 border border-[#ff3333]/30 text-[#ff3333] rounded text-xs font-bold uppercase">PREMIUM</span>;
  }
  if (plan === 'lifetime') {
    return <span className="px-3 py-1 bg-[#76b900]/20 border border-[#76b900]/30 text-[#76b900] rounded text-xs font-bold uppercase">LIFETIME</span>;
  }
  // Fallback pour anciennes licences
  return <span className="px-3 py-1 bg-gray-500/20 border border-gray-500/30 text-gray-400 rounded text-xs font-bold uppercase">{plan || 'UNKNOWN'}</span>;
};

const ActionsMenu = ({ license, isOpen, onToggle, onEdit, onCopyKey, onResetHWID, onBan, onUnban, onDelete, onClose }) => {
  const menuRef = useRef(null);
  const buttonRef = useRef(null);
  const [menuPosition, setMenuPosition] = useState('bottom');
  
  const isBanned = license.status === 'suspended';

  useEffect(() => {
    if (!isOpen) return;

    const handleClickOutside = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target) && 
          buttonRef.current && !buttonRef.current.contains(e.target)) {
        onClose();
      }
    };

    // Check if menu should appear above or below
    if (buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      const spaceBelow = window.innerHeight - rect.bottom;
      setMenuPosition(spaceBelow < 300 ? 'top' : 'bottom');
    }

    const timer = setTimeout(() => {
      document.addEventListener('click', handleClickOutside);
    }, 10);

    return () => {
      clearTimeout(timer);
      document.removeEventListener('click', handleClickOutside);
    };
  }, [isOpen, onClose]);

  return (
    <div className="relative">
      <button
        ref={buttonRef}
        onClick={(e) => {
          e.stopPropagation();
          onToggle();
        }}
        data-testid={`actions-menu-${license.id}`}
        className="p-2 hover:bg-gray-800 rounded-lg transition text-gray-400 hover:text-white"
      >
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <circle cx="12" cy="5" r="2"/>
          <circle cx="12" cy="12" r="2"/>
          <circle cx="12" cy="19" r="2"/>
        </svg>
      </button>
      
      {isOpen && (
        <div 
          ref={menuRef}
          className={`absolute right-0 w-48 bg-[#151515] border border-gray-800 rounded-xl shadow-2xl z-[9999] py-2 ${menuPosition === 'top' ? 'bottom-full mb-2' : 'top-full mt-2'}`}
        >
          <button 
            onClick={onEdit} 
            data-testid={`edit-${license.id}`}
            className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-white/5 transition text-gray-300 text-sm"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
            </svg>
            Edit
          </button>
          
          <button 
            onClick={onCopyKey} 
            data-testid={`copy-${license.id}`}
            className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-white/5 transition text-gray-300 text-sm"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
            Copy Key
          </button>

          <div className="border-t border-gray-800 my-2"></div>
          
          <button 
            onClick={onResetHWID} 
            data-testid={`reset-hwid-${license.id}`}
            className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-white/5 transition text-gray-300 text-sm"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
            Reset HWID
          </button>
          
          {isBanned ? (
            <button 
              onClick={onUnban} 
              data-testid={`unban-${license.id}`}
              className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-green-500/10 transition text-green-400 text-sm"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Unban
            </button>
          ) : (
            <button 
              onClick={onBan} 
              data-testid={`ban-${license.id}`}
              className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-white/5 transition text-gray-300 text-sm"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
              </svg>
              Ban
            </button>
          )}

          <div className="border-t border-gray-800 my-2"></div>
          
          <button 
            onClick={onDelete} 
            data-testid={`delete-${license.id}`}
            className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-[#ff3333]/10 transition text-red-400 text-sm"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
            Delete
          </button>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// Modals
// ============================================================================

const CreateLicenseModal = ({ onClose, onCreate }) => {
  const [pseudo, setPseudo] = useState('');
  const [plan, setPlan] = useState('lifetime');
  const [maxDevices, setMaxDevices] = useState(1);
  const [notes, setNotes] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    
    let durationDays = 0;
    if (plan === 'trial') durationDays = 7;
    else if (plan === 'premium') durationDays = 365;
    
    onCreate({
      pseudo: pseudo || null,
      duration_days: durationDays,
      max_devices: parseInt(maxDevices),
      notes: notes || null,
      plan: plan
    });
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50" data-testid="create-license-modal">
      <div className="bg-[#111] border border-gray-800 rounded-xl p-8 w-full max-w-md">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white">Create License</h2>
            <p className="text-gray-500 text-sm mt-1">Generate a new license key</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition p-1">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-gray-400 text-sm mb-2">Pseudo</label>
            <input
              type="text"
              value={pseudo}
              onChange={(e) => setPseudo(e.target.value)}
              placeholder="Username"
              data-testid="pseudo-input"
              className="w-full bg-[#0a0a0a] border border-gray-800 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-gray-600 transition"
            />
          </div>

          <div>
            <label className="block text-gray-400 text-sm mb-2">Plan</label>
            <select
              value={plan}
              onChange={(e) => setPlan(e.target.value)}
              data-testid="plan-select"
              className="w-full bg-[#0a0a0a] border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gray-600 transition"
            >
              <option value="trial">Trial (7 jours)</option>
              <option value="premium">Premium (1 an)</option>
              <option value="lifetime">Lifetime (Permanent)</option>
            </select>
          </div>

          <div>
            <label className="block text-gray-400 text-sm mb-2">Max Activations</label>
            <input
              type="number"
              value={maxDevices}
              onChange={(e) => setMaxDevices(e.target.value)}
              data-testid="max-devices-input"
              className="w-full bg-[#0a0a0a] border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gray-600 transition"
              min="1"
            />
          </div>

          <div>
            <label className="block text-gray-400 text-sm mb-2">Notes (optional)</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Additional notes"
              data-testid="notes-input"
              className="w-full bg-[#0a0a0a] border border-gray-800 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-gray-600 transition resize-none"
              rows="3"
            />
          </div>

          <div className="flex gap-3 pt-4">
            <button 
              type="button" 
              onClick={onClose} 
              className="flex-1 px-4 py-3 text-gray-400 hover:text-white border border-gray-800 rounded-lg transition"
            >
              Cancel
            </button>
            <button 
              type="submit" 
              data-testid="submit-create-license"
              className="flex-1 px-4 py-3 bg-[#ff3333] hover:bg-[#cc0000] text-white rounded-lg font-medium transition"
            >
              Create
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

const EditLicenseModal = ({ license, onClose, onUpdate }) => {
  const [pseudo, setPseudo] = useState(license.pseudo || '');
  const [status, setStatus] = useState(license.status);
  const [plan, setPlan] = useState(license.plan || 'trial');
  const [notes, setNotes] = useState(license.notes || '');

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Calculer la nouvelle durée si le plan change
    let updateData = {
      pseudo: pseudo || null,
      status,
      notes: notes || null,
      plan: plan
    };
    
    // Si le plan change, recalculer la date d'expiration
    if (plan !== license.plan) {
      if (plan === 'lifetime') {
        updateData.expires_at = null; // Pas d'expiration
      } else if (plan === 'trial') {
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 7);
        updateData.expires_at = expiresAt.toISOString();
      } else if (plan === 'premium') {
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 365);
        updateData.expires_at = expiresAt.toISOString();
      }
    }
    
    onUpdate(license.id, updateData);
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50" data-testid="edit-license-modal">
      <div className="bg-[#111] border border-gray-800 rounded-xl p-8 w-full max-w-md">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white">Edit License</h2>
            <p className="text-gray-500 text-sm mt-1 font-mono">{license.license_key.substring(0, 14)}...</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition p-1">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-gray-400 text-sm mb-2">Pseudo</label>
            <input
              type="text"
              value={pseudo}
              onChange={(e) => setPseudo(e.target.value)}
              placeholder="Username"
              data-testid="edit-pseudo-input"
              className="w-full bg-[#0a0a0a] border border-gray-800 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-gray-600 transition"
            />
          </div>

          <div>
            <label className="block text-gray-400 text-sm mb-2">Status</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              data-testid="edit-status-select"
              className="w-full bg-[#0a0a0a] border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gray-600 transition"
            >
              <option value="active">Active</option>
              <option value="suspended">Banned</option>
              <option value="expired">Expired</option>
            </select>
          </div>

          <div>
            <label className="block text-gray-400 text-sm mb-2">Plan</label>
            <select
              value={plan}
              onChange={(e) => setPlan(e.target.value)}
              data-testid="edit-plan-select"
              className="w-full bg-[#0a0a0a] border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gray-600 transition"
            >
              <option value="trial">Trial (7 jours)</option>
              <option value="premium">Premium (1 an)</option>
              <option value="lifetime">Lifetime (Permanent)</option>
            </select>
            {plan !== license.plan && (
              <p className="text-yellow-500 text-xs mt-2">⚠️ La date d'expiration sera recalculée</p>
            )}
          </div>

          <div>
            <label className="block text-gray-400 text-sm mb-2">Notes</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Additional notes"
              data-testid="edit-notes-input"
              className="w-full bg-[#0a0a0a] border border-gray-800 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-gray-600 transition resize-none"
              rows="3"
            />
          </div>

          <div className="flex gap-3 pt-4">
            <button 
              type="button" 
              onClick={onClose} 
              className="flex-1 px-4 py-3 text-gray-400 hover:text-white border border-gray-800 rounded-lg transition"
            >
              Cancel
            </button>
            <button 
              type="submit" 
              data-testid="submit-edit-license"
              className="flex-1 px-4 py-3 bg-[#ff3333] hover:bg-[#cc0000] text-white rounded-lg font-medium transition"
            >
              Save Changes
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// ============================================================================
// Icons
// ============================================================================

const KeyIcon = ({ className }) => (
  <svg className={`w-6 h-6 ${className}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
  </svg>
);

const CheckCircleIcon = ({ className }) => (
  <svg className={`w-6 h-6 ${className}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const XCircleIcon = ({ className }) => (
  <svg className={`w-6 h-6 ${className}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const BanIcon = ({ className }) => (
  <svg className={`w-6 h-6 ${className}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
  </svg>
);

const ClockIcon = ({ className }) => (
  <svg className={`w-6 h-6 ${className}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const LightningIcon = ({ className }) => (
  <svg className={`w-5 h-5 ${className}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
  </svg>
);

const StarIcon = ({ className }) => (
  <svg className={`w-5 h-5 ${className}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
  </svg>
);

const CrownIcon = ({ className }) => (
  <svg className={`w-5 h-5 ${className}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3l3.5 7L12 7l3.5 3L19 3M5 21h14M5 17h14M5 13h14" />
  </svg>
);

export default AdminDashboardPage;
