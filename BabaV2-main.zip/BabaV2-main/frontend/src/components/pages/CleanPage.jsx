import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Loader2, CheckCircle2, AlertCircle } from 'lucide-react';
import { useSettings } from '../../context/SettingsContext';

const CleanPage = () => {
  const { t } = useTranslation();
  const { isElectron, addToast } = useSettings();
  
  const [isCleaning, setIsCleaning] = useState(false);
  const [cleaningProgress, setCleaningProgress] = useState(0);
  const [cleaningStatus, setCleaningStatus] = useState('');
  const [spaceFreed, setSpaceFreed] = useState(0);
  const [lastCleanResult, setLastCleanResult] = useState(null);

  // Écouter les mises à jour de progression depuis Electron
  useEffect(() => {
    if (isElectron && window.electronAPI) {
      const handleProgress = (progressData) => {
        console.log('Progress received:', progressData);
        setCleaningProgress(progressData.percentage);
        setCleaningStatus(progressData.status);
      };

      // S'abonner aux événements de progression
      if (window.electronAPI.onCleanProgress) {
        window.electronAPI.onCleanProgress(handleProgress);
      }

      // Nettoyage lors du démontage
      return () => {
        if (window.electronAPI.removeCleanProgressListener) {
          window.electronAPI.removeCleanProgressListener();
        }
      };
    }
  }, [isElectron]);

  // Nettoyer tous les fichiers
  const handleCleanAll = async () => {
    setIsCleaning(true);
    setCleaningProgress(0);
    setCleaningStatus('');
    setSpaceFreed(0);
    
    if (addToast) addToast(t('clean.notifications.analyzing'), 'info');

    try {
      if (isElectron && window.electronAPI?.cleanSystem) {
        // Appeler l'API Electron pour nettoyer
        const result = await window.electronAPI.cleanSystem('all');
        
        if (result && result.success) {
          setSpaceFreed(result.spaceFreed || 0);
          setLastCleanResult({
            success: true,
            spaceFreed: result.spaceFreed || 0
          });

          if (addToast) {
            addToast(
              t('clean.notifications.cleanComplete').replace('{{space}}', formatBytes(result.spaceFreed)),
              'success'
            );
          }
        } else {
          throw new Error(result.error || 'Unknown error');
        }
      } else {
        // Mode web/démo - Simuler le nettoyage avec progression
        for (let i = 0; i <= 100; i += 10) {
          setCleaningProgress(i);
          await new Promise(resolve => setTimeout(resolve, 200));
        }
        
        const mockSpaceFreed = Math.floor(Math.random() * 5000000000) + 500000000; // 500MB - 5GB
        setSpaceFreed(mockSpaceFreed);
        setLastCleanResult({
          success: true,
          spaceFreed: mockSpaceFreed
        });
        
        if (addToast) {
          addToast(
            t('clean.notifications.cleanComplete').replace('{{space}}', formatBytes(mockSpaceFreed)),
            'success'
          );
        }
      }
    } catch (error) {
      console.error('Clean error:', error);
      if (addToast) {
        const errorMsg = error.message || 'Unknown error';
        addToast(`${t('clean.notifications.cleanError')}: ${errorMsg}`, 'error');
      }
      setLastCleanResult({
        success: false,
        error: error.message
      });
    } finally {
      setIsCleaning(false);
      setCleaningProgress(0);
    }
  };

  // Formater les bytes
  const formatBytes = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <span className="text-3xl">🧹</span>
            {t('clean.title')}
          </h1>
          <p className="text-[#888] mt-2">{t('clean.subtitle')}</p>
        </div>
        
        {/* Stats */}
        {lastCleanResult && lastCleanResult.success && (
          <div className="bg-gradient-to-r from-green-500/10 to-green-500/5 border border-green-500/20 rounded-xl p-4">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-8 h-8 text-green-400" />
              <div>
                <p className="text-xs text-green-400 font-medium">{t('clean.spaceFreed')}</p>
                <p className="text-2xl font-bold text-white">{formatBytes(spaceFreed)}</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Clean All Card */}
      <div className="bg-gradient-to-br from-[#1a1a1a] to-[#0d0d0d] rounded-2xl p-8 border border-white/10">
        <div className="flex flex-col items-center text-center space-y-6">
          {/* Icon */}
          <div className="relative">
            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-[#ff3333] to-[#cc0000] flex items-center justify-center shadow-2xl shadow-red-500/30">
              <span className="text-6xl">🧹</span>
            </div>
            {!isCleaning && (
              <div className="absolute -top-2 -right-2 w-12 h-12 rounded-full bg-gradient-to-br from-yellow-400 to-orange-400 flex items-center justify-center animate-pulse">
                <CheckCircle2 className="w-6 h-6 text-white" />
              </div>
            )}
          </div>
          
          {/* Title */}
          <h2 className="text-2xl font-bold text-white">{t('clean.cleanAll')}</h2>
          
          {/* Clean Button */}
          <button
            onClick={handleCleanAll}
            disabled={isCleaning}
            data-testid="clean-all-btn"
            className="px-12 py-4 bg-gradient-to-r from-[#ff3333] to-[#cc0000] hover:from-[#ff4444] hover:to-[#dd1111] text-white text-lg font-semibold rounded-xl shadow-lg shadow-red-500/30 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-3 hover:scale-105 active:scale-95"
          >
            {isCleaning ? (
              <>
                <Loader2 className="w-6 h-6 animate-spin" />
                {t('clean.cleaning')}
              </>
            ) : (
              <>
                <span className="text-xl">🧹</span>
                {t('clean.cleanAll')}
              </>
            )}
          </button>
          
          {/* Progress Bar */}
          {isCleaning && (
            <div className="w-full max-w-md">
              <div className="flex justify-between text-sm text-[#888] mb-2">
                <span>{cleaningStatus || 'Nettoyage en cours...'}</span>
                <span>{cleaningProgress}%</span>
              </div>
              <div className="w-full bg-[#0d0d0d] rounded-full h-3 overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-[#ff3333] to-[#cc0000] transition-all duration-300 rounded-full"
                  style={{ width: `${cleaningProgress}%` }}
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Info Banner */}
      {!isElectron && (
        <div className="bg-gradient-to-r from-amber-500/10 to-amber-500/5 border border-amber-500/20 rounded-2xl p-4 flex items-center gap-4">
          <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0" />
          <div>
            <p className="text-amber-400 text-sm font-medium">Mode Web - Fonctionnalité limitée</p>
            <p className="text-[#666] text-xs mt-1">
              Cette fonctionnalité nécessite l'application Electron pour fonctionner pleinement. En mode web, seule une démonstration est disponible.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default CleanPage;
