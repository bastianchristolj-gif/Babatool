import React, { useState } from "react";
import "./App.css";
import { BrowserRouter, HashRouter, Routes, Route, Navigate } from "react-router-dom";
import Sidebar from "./components/Sidebar";
import TitleBar from "./components/TitleBar";
import HomePage from "./components/pages/HomePage";
import PerformancePage from "./components/pages/PerformancePage";
import PrivacyPage from "./components/pages/PrivacyPage";
import InterfacePage from "./components/pages/InterfacePage";
import BloatwarePage from "./components/pages/BloatwarePage";
import CleanPage from "./components/pages/CleanPage";
import DriversPage from "./components/pages/DriversPage";
import UpdatesPage from "./components/pages/UpdatesPage";
import SoftwarePage from "./components/pages/SoftwarePage";
import AdminLoginPage from "./components/pages/AdminLoginPage";
import AdminDashboardPage from "./components/pages/AdminDashboardPage";
import LicenseValidationModal from "./components/LicenseValidationModal";
import ToastNotifications from "./components/ToastNotifications";
import UpdateChecker from "./components/UpdateChecker";
import { SettingsProvider, useSettings } from "./context/SettingsContext";

// Import i18n configuration
import './i18n';

// Detect if running in Electron or Web browser
const isElectron = () => {
  return typeof window !== 'undefined' && 
         (window.navigator.userAgent.toLowerCase().includes('electron') ||
          typeof window.electron !== 'undefined');
};

const MainAppContent = () => {
  const [activeSection, setActiveSection] = useState('home');
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [licenseValidated, setLicenseValidated] = useState(false);
  const [currentLicense, setCurrentLicense] = useState(null);
  const { toasts, isLoading } = useSettings();

  const handleLicenseValidated = (license) => {
    setLicenseValidated(true);
    setCurrentLicense(license);
    
    // Force sidebar to reload license info immediately
    setTimeout(() => {
      window.dispatchEvent(new Event('license-updated'));
    }, 100);
  };

  const renderContent = () => {
    switch (activeSection) {
      case 'home':
        return <HomePage setActiveSection={setActiveSection} />;
      case 'performance':
        return <PerformancePage />;
      case 'privacy':
        return <PrivacyPage />;
      case 'interface':
        return <InterfacePage />;
      case 'bloatware':
        return <BloatwarePage />;
      case 'clean':
        return <CleanPage />;
      case 'drivers':
        return <DriversPage />;
      case 'updates':
        return <UpdatesPage />;
      case 'software':
        return <SoftwarePage />;
      default:
        return <HomePage setActiveSection={setActiveSection} />;
    }
  };

  return (
    <div className="h-screen w-screen bg-[#0a0a0a] flex flex-col overflow-hidden">
      {/* License Validation Modal */}
      {!licenseValidated && <LicenseValidationModal onValidated={handleLicenseValidated} />}
      
      {/* Title Bar */}
      <TitleBar />

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <Sidebar 
          activeSection={activeSection}
          setActiveSection={setActiveSection}
          isCollapsed={isCollapsed}
          setIsCollapsed={setIsCollapsed}
        />

        {/* Content */}
        <main className="flex-1 overflow-y-auto exm-content p-8 lg:p-10 relative">
          {/* Loading overlay */}
          {isLoading && (
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
              <div className="flex items-center gap-3 exm-card px-6 py-4">
                <div className="w-5 h-5 border-2 border-[#ff2d8a] border-t-transparent rounded-full animate-spin"></div>
                <span className="text-white text-sm font-medium">Exécution en cours...</span>
              </div>
            </div>
          )}
          
          <div className="max-w-6xl">
            {renderContent()}
          </div>
        </main>
      </div>

      {/* Toast Notifications */}
      <ToastNotifications toasts={toasts} />
      
      {/* Update Checker - vérifie automatiquement les mises à jour (seulement après validation de licence) */}
      {licenseValidated && <UpdateChecker />}
    </div>
  );
};

function App() {
  // Use BrowserRouter for web (admin panel), HashRouter for Electron
  const Router = isElectron() ? HashRouter : BrowserRouter;

  return (
    <div className="App">
      <SettingsProvider>
        <Router>
          <Routes>
            {/* Admin routes */}
            <Route path="/admin/login" element={<AdminLoginPage />} />
            <Route path="/admin/dashboard" element={<AdminDashboardPage />} />
            <Route path="/admin" element={<Navigate to="/admin/login" replace />} />
            
            {/* Main App route - accessible via /app */}
            <Route path="/app" element={<MainAppContent />} />
            <Route path="/app/*" element={<MainAppContent />} />
            
            {/* Root redirect */}
            <Route path="/" element={<Navigate to="/app" replace />} />
            
            {/* Catch-all */}
            <Route path="/*" element={<Navigate to="/app" replace />} />
          </Routes>
        </Router>
      </SettingsProvider>
    </div>
  );
}

export default App;
