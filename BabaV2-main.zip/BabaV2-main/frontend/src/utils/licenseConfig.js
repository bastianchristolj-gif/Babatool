// Configuration des fonctionnalités par type de licence

export const LICENSE_TYPES = {
  TRIAL: 'trial',
  PREMIUM: 'premium',
  LIFETIME: 'lifetime'
};

export const FEATURE_CATEGORIES = {
  PERFORMANCE_GAMING: 'performance_gaming',
  PERFORMANCE_POWER: 'performance_power',
  PERFORMANCE_FORTNITE: 'performance_fortnite',
  PERFORMANCE_OBS: 'performance_obs',
  DRIVERS: 'drivers',
  PRIVACY: 'privacy',
  INTERFACE: 'interface',
  INTERFACE_WALLPAPERS: 'interface_wallpapers',
  BLOATWARE: 'bloatware',
  ADVANCED: 'advanced',
  UPDATES: 'updates',
  CLEAN: 'clean'
};

// Configuration des accès par licence
export const LICENSE_FEATURES = {
  [LICENSE_TYPES.TRIAL]: {
    name: 'Trial',
    color: '#666666',
    features: [
      FEATURE_CATEGORIES.PERFORMANCE_GAMING,
      FEATURE_CATEGORIES.PERFORMANCE_POWER,
      FEATURE_CATEGORIES.CLEAN,
      FEATURE_CATEGORIES.INTERFACE
    ]
  },
  [LICENSE_TYPES.PREMIUM]: {
    name: 'Premium',
    color: '#ff3333',
    features: [
      FEATURE_CATEGORIES.PERFORMANCE_GAMING,
      FEATURE_CATEGORIES.PERFORMANCE_POWER,
      FEATURE_CATEGORIES.PERFORMANCE_FORTNITE,
      FEATURE_CATEGORIES.PERFORMANCE_OBS,
      FEATURE_CATEGORIES.PRIVACY,
      FEATURE_CATEGORIES.INTERFACE,
      FEATURE_CATEGORIES.INTERFACE_WALLPAPERS,
      FEATURE_CATEGORIES.BLOATWARE,
      FEATURE_CATEGORIES.ADVANCED,
      FEATURE_CATEGORIES.UPDATES,
      FEATURE_CATEGORIES.CLEAN
    ]
  },
  [LICENSE_TYPES.LIFETIME]: {
    name: 'Lifetime',
    color: '#76b900',
    features: [
      FEATURE_CATEGORIES.PERFORMANCE_GAMING,
      FEATURE_CATEGORIES.PERFORMANCE_POWER,
      FEATURE_CATEGORIES.PERFORMANCE_FORTNITE,
      FEATURE_CATEGORIES.PERFORMANCE_OBS,
      FEATURE_CATEGORIES.DRIVERS,
      FEATURE_CATEGORIES.PRIVACY,
      FEATURE_CATEGORIES.INTERFACE,
      FEATURE_CATEGORIES.INTERFACE_WALLPAPERS,
      FEATURE_CATEGORIES.BLOATWARE,
      FEATURE_CATEGORIES.ADVANCED,
      FEATURE_CATEGORIES.UPDATES,
      FEATURE_CATEGORIES.CLEAN
    ]
  }
};

// Messages de licence requise
export const LICENSE_UPGRADE_MESSAGES = {
  [LICENSE_TYPES.PREMIUM]: {
    title: '🔒 Premium Requis',
    description: 'Cette fonctionnalité nécessite une licence Premium ou supérieure.',
    badge: 'Premium',
    badgeColor: '#ff3333'
  },
  [LICENSE_TYPES.LIFETIME]: {
    title: '🔒 Lifetime Requis',
    description: 'Cette fonctionnalité est réservée aux licences Lifetime.',
    badge: 'Lifetime',
    badgeColor: '#76b900'
  }
};

// Helper functions
export const hasFeatureAccess = (userLicense, feature) => {
  if (!userLicense || !LICENSE_FEATURES[userLicense]) {
    return false;
  }
  return LICENSE_FEATURES[userLicense].features.includes(feature);
};

export const getRequiredLicenseForFeature = (feature) => {
  // Trouve la licence minimum requise pour une fonctionnalité
  if (LICENSE_FEATURES[LICENSE_TYPES.TRIAL].features.includes(feature)) {
    return LICENSE_TYPES.TRIAL;
  }
  if (LICENSE_FEATURES[LICENSE_TYPES.PREMIUM].features.includes(feature)) {
    return LICENSE_TYPES.PREMIUM;
  }
  if (LICENSE_FEATURES[LICENSE_TYPES.LIFETIME].features.includes(feature)) {
    return LICENSE_TYPES.LIFETIME;
  }
  return null;
};

export const getLicenseLevel = (licenseType) => {
  const levels = {
    [LICENSE_TYPES.TRIAL]: 1,
    [LICENSE_TYPES.PREMIUM]: 2,
    [LICENSE_TYPES.LIFETIME]: 3
  };
  return levels[licenseType] || 0;
};

export const canUpgradeTo = (currentLicense, targetLicense) => {
  return getLicenseLevel(currentLicense) < getLicenseLevel(targetLicense);
};
