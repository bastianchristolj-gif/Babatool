/**
 * Module de lecture des états réels des paramètres Windows
 * 
 * Ce module définit pour chaque paramètre (toggle) comment lire son état réel depuis Windows.
 * Pour ajouter une nouvelle option, il suffit d'ajouter sa définition dans la configuration ci-dessous.
 * 
 * Types de lecture supportés :
 * - 'registry': Lecture d'une clé de registre
 * - 'service': Lecture du statut d'un service Windows
 * - 'powercfg': Lecture de configuration d'alimentation
 * - 'custom': Fonction personnalisée pour les cas complexes
 */

// ============================================================================
// CONFIGURATION DES ÉTATS PAR PARAMÈTRE
// ============================================================================

export const stateDefinitions = {
  // ========== PRIVACY / CONFIDENTIALITÉ SETTINGS ==========
  'telemetry': {
    type: 'registry',
    path: 'HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection',
    key: 'AllowTelemetry',
    enabledValue: 0,  // 0 = télémétrie désactivée = notre toggle ON
    disabledValue: 1,
    defaultIfMissing: false
  },
  
  'diagnostic-data': {
    type: 'registry',
    path: 'HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\DataCollection',
    key: 'AllowTelemetry',
    enabledValue: 0,
    disabledValue: 1,
    defaultIfMissing: false
  },
  
  'activity-history': {
    type: 'registry',
    path: 'HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\System',
    key: 'EnableActivityFeed',
    enabledValue: 0,
    disabledValue: 1,
    defaultIfMissing: false
  },
  
  'location-tracking': {
    type: 'registry',
    path: 'HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\CapabilityAccessManager\\ConsentStore\\location',
    key: 'Value',
    enabledValue: 'Deny',
    disabledValue: 'Allow',
    defaultIfMissing: false
  },
  
  'advertising-id': {
    type: 'registry',
    path: 'HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\AdvertisingInfo',
    key: 'DisabledByGroupPolicy',
    enabledValue: 1,
    disabledValue: 0,
    defaultIfMissing: false
  },
  
  'cortana': {
    type: 'registry',
    path: 'HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search',
    key: 'AllowCortana',
    enabledValue: 0,
    disabledValue: 1,
    defaultIfMissing: false
  },
  
  'windows-tips': {
    type: 'registry',
    path: 'HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\CloudContent',
    key: 'DisableSoftLanding',
    enabledValue: 1,
    disabledValue: 0,
    defaultIfMissing: false
  },
  
  'suggested-content': {
    type: 'registry',
    path: 'HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager',
    key: 'SubscribedContent-338388Enabled',
    enabledValue: 0,
    disabledValue: 1,
    defaultIfMissing: false
  },

  // ========== INTERFACE SETTINGS ==========
  'animations': {
    type: 'registry',
    path: 'HKCU\\Control Panel\\Desktop\\WindowMetrics',
    key: 'MinAnimate',
    enabledValue: '1',
    disabledValue: '0',
    defaultIfMissing: true
  },
  
  'transparency': {
    type: 'registry',
    path: 'HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize',
    key: 'EnableTransparency',
    enabledValue: 1,
    disabledValue: 0,
    defaultIfMissing: true
  },
  
  'classic-context': {
    type: 'registry',
    path: 'HKCU\\Software\\Classes\\CLSID\\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\\InprocServer32',
    key: '(Default)',
    enabledValue: '',  // Clé vide = menu classique activé
    disabledValue: null,  // Clé absente = menu Win11
    defaultIfMissing: false
  },
  
  'taskbar-left': {
    type: 'registry',
    path: 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced',
    key: 'TaskbarAl',
    enabledValue: 0,  // 0 = gauche
    disabledValue: 1,  // 1 = centre
    defaultIfMissing: false
  },
  
  'dark-mode': {
    type: 'registry',
    path: 'HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize',
    key: 'AppsUseLightTheme',
    enabledValue: 0,  // 0 = mode sombre activé
    disabledValue: 1,  // 1 = mode clair
    defaultIfMissing: true
  },
  
  'legacy-alt-tab': {
    type: 'registry',
    path: 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer',
    key: 'AltTabSettings',
    enabledValue: 1,  // 1 = Alt-Tab classique
    disabledValue: 0,  // 0 = Alt-Tab moderne
    defaultIfMissing: false
  },

  // ========== PERFORMANCE SETTINGS - Plans d'Alimentation ==========
  'power-plan': {
    type: 'powercfg',
    checkType: 'activePlan',
    enabledValue: '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c', // High Performance GUID
    defaultIfMissing: false
  },
  
  'fast-startup': {
    type: 'registry',
    path: 'HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Power',
    key: 'HiberbootEnabled',
    enabledValue: 1,
    disabledValue: 0,
    defaultIfMissing: true
  },
  
  'core-parking': {
    type: 'custom',
    customReader: 'readCoreParkingSetting',
    defaultIfMissing: false
  },

  // ========== PERFORMANCE SETTINGS - Gaming ==========
  'game-mode': {
    type: 'registry',
    path: 'HKCU\\Software\\Microsoft\\GameBar',
    key: 'AutoGameModeEnabled',
    enabledValue: 1,
    disabledValue: 0,
    defaultIfMissing: true
  },
  
  'fsync': {
    type: 'registry',
    path: 'HKCU\\System\\GameConfigStore',
    key: 'GameDVR_FSEBehaviorMode',
    enabledValue: null,  // Clé absente = FSO activé
    disabledValue: 2,  // 2 = FSO désactivé
    defaultIfMissing: false
  },
  
  'hpet': {
    type: 'custom',
    customReader: 'readHPETSetting',
    defaultIfMissing: false
  },
  
  // ========== PERFORMANCE SETTINGS - Services ==========
  'superfetch': {
    type: 'service',
    serviceName: 'SysMain',
    enabledValue: 'Stopped',  // Arrêté = notre "enabled" (désactiver superfetch)
    disabledValue: 'Running',
    defaultIfMissing: false
  },

  // ========== ADVANCED SETTINGS ==========
  'windows-defender': {
    type: 'service',
    serviceName: 'WinDefend',
    enabledValue: 'Running',
    disabledValue: 'Stopped',
    defaultIfMissing: true
  },
  
  'defender': {
    type: 'service',
    serviceName: 'WinDefend',
    enabledValue: 'Running',
    disabledValue: 'Stopped',
    defaultIfMissing: true
  },
  
  'windows-update': {
    type: 'service',
    serviceName: 'wuauserv',
    enabledValue: 'Running',
    disabledValue: 'Stopped',
    defaultIfMissing: true
  },
  
  'firewall': {
    type: 'registry',
    path: 'HKLM\\SYSTEM\\CurrentControlSet\\Services\\SharedAccess\\Parameters\\FirewallPolicy\\StandardProfile',
    key: 'EnableFirewall',
    enabledValue: 1,
    disabledValue: 0,
    defaultIfMissing: true
  },
  
  'uac': {
    type: 'registry',
    path: 'HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System',
    key: 'EnableLUA',
    enabledValue: 1,
    disabledValue: 0,
    defaultIfMissing: true
  },
  
  'smartscreen': {
    type: 'registry',
    path: 'HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer',
    key: 'SmartScreenEnabled',
    enabledValue: 'On',
    disabledValue: 'Off',
    defaultIfMissing: true
  },
  
  'mitigations': {
    type: 'custom',
    customReader: 'readMitigationsSetting',
    defaultIfMissing: true
  }
};

// ============================================================================
// FONCTIONS DE LECTURE CUSTOM
// ============================================================================

/**
 * Fonctions custom pour les cas complexes qui ne peuvent pas être lus simplement
 */
export const customReaders = {
  /**
   * Lecture du mode core parking (arrêt des cœurs CPU)
   */
  readCoreParkingSetting: async (electronAPI) => {
    if (!electronAPI?.readRegistry) return false;
    
    try {
      // Lire la valeur CPMINCORES du plan actif
      // On utilise powercfg pour récupérer la valeur
      const result = await electronAPI.executePowerShell([{
        script: 'powercfg /qh scheme_current sub_processor CPMINCORES'
      }]);
      
      if (result && result[0] && result[0].success) {
        const output = result[0].output;
        // Si CPMINCORES = 100 (100%), core parking est désactivé = notre "enabled"
        if (output.includes('0x00000064') || output.includes('100')) {
          return true;
        }
      }
      return false;
    } catch (error) {
      console.error('Error reading core parking:', error);
      return false;
    }
  },
  
  /**
   * Lecture de l'état HPET (High Precision Event Timer)
   */
  readHPETSetting: async (electronAPI) => {
    if (!electronAPI?.executePowerShell) return false;
    
    try {
      // Vérifier si useplatformclock est à false
      const result = await electronAPI.executePowerShell([{
        script: 'bcdedit /enum | Select-String "useplatformclock"'
      }]);
      
      if (result && result[0] && result[0].success) {
        const output = result[0].output.toLowerCase();
        // Si useplatformclock est "no" ou "false", HPET est désactivé = notre "enabled"
        if (output.includes('no') || output.includes('false')) {
          return true;
        }
      }
      return false;
    } catch (error) {
      console.error('Error reading HPET:', error);
      return false;
    }
  },
  
  /**
   * Lecture des mitigations Spectre/Meltdown
   */
  readMitigationsSetting: async (electronAPI) => {
    if (!electronAPI?.readRegistry) return true;  // Par défaut activé
    
    try {
      // Vérifier FeatureSettingsOverride dans le registre
      const result = await electronAPI.readRegistry(
        'HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management',
        'FeatureSettingsOverride'
      );
      
      if (result.success && result.value !== null) {
        // Si la valeur existe et vaut 3, les mitigations sont désactivées
        return result.value !== 3;
      }
      
      // Par défaut, les mitigations sont activées
      return true;
    } catch (error) {
      console.error('Error reading mitigations:', error);
      return true;
    }
  }
};

// ============================================================================
// FONCTION PRINCIPALE DE LECTURE D'ÉTAT
// ============================================================================

/**
 * Lit l'état réel d'un paramètre Windows
 * @param {string} settingId - L'ID du paramètre
 * @param {object} electronAPI - L'API Electron pour communiquer avec le main process
 * @returns {Promise<boolean>} - true si le paramètre est activé, false sinon
 */
export async function readSettingState(settingId, electronAPI) {
  const definition = stateDefinitions[settingId];
  
  // Si pas de définition, retourner la valeur par défaut
  if (!definition) {
    console.warn(`No state definition found for setting: ${settingId}`);
    return false;
  }

  try {
    switch (definition.type) {
      case 'registry':
        return await readRegistryState(definition, electronAPI);
      
      case 'service':
        return await readServiceState(definition, electronAPI);
      
      case 'powercfg':
        return await readPowercfgState(definition, electronAPI);
      
      case 'custom':
        if (customReaders[definition.customReader]) {
          return await customReaders[definition.customReader](electronAPI);
        }
        return definition.defaultIfMissing ?? false;
      
      default:
        console.warn(`Unknown state type: ${definition.type}`);
        return definition.defaultIfMissing ?? false;
    }
  } catch (error) {
    console.error(`Error reading state for ${settingId}:`, error);
    return definition.defaultIfMissing ?? false;
  }
}

/**
 * Lit une valeur du registre Windows
 */
async function readRegistryState(definition, electronAPI) {
  if (!electronAPI?.readRegistry) {
    return definition.defaultIfMissing ?? false;
  }

  const result = await electronAPI.readRegistry(definition.path, definition.key);
  
  if (result.success && result.value !== null && result.value !== undefined) {
    // Comparer la valeur lue avec la valeur "enabled"
    return result.value === definition.enabledValue;
  }
  
  return definition.defaultIfMissing ?? false;
}

/**
 * Lit le statut d'un service Windows
 */
async function readServiceState(definition, electronAPI) {
  if (!electronAPI?.readServiceStatus) {
    return definition.defaultIfMissing ?? false;
  }

  const result = await electronAPI.readServiceStatus(definition.serviceName);
  
  if (result.success && result.status) {
    return result.status === definition.enabledValue;
  }
  
  return definition.defaultIfMissing ?? false;
}

/**
 * Lit une configuration d'alimentation (powercfg)
 */
async function readPowercfgState(definition, electronAPI) {
  if (!electronAPI?.readPowercfg) {
    return definition.defaultIfMissing ?? false;
  }

  const result = await electronAPI.readPowercfg(definition.checkType);
  
  if (result.success && result.value) {
    if (definition.checkType === 'activePlan') {
      // Vérifier si le GUID actif correspond au GUID attendu
      return result.value.toLowerCase() === definition.enabledValue.toLowerCase();
    } else if (definition.checkType === 'hibernateAvailable') {
      return result.value === true;
    }
  }
  
  return definition.defaultIfMissing ?? false;
}

/**
 * Lit les états de tous les paramètres d'une catégorie
 * @param {string[]} settingIds - Liste des IDs des paramètres à lire
 * @param {object} electronAPI - L'API Electron
 * @returns {Promise<Object>} - Objet { settingId: boolean }
 */
export async function readMultipleSettings(settingIds, electronAPI) {
  const results = {};
  
  // Lire tous les états en parallèle pour améliorer les performances
  await Promise.all(
    settingIds.map(async (id) => {
      results[id] = await readSettingState(id, electronAPI);
    })
  );
  
  return results;
}

/**
 * Lit tous les états définis dans stateDefinitions
 * @param {object} electronAPI - L'API Electron
 * @returns {Promise<Object>} - Objet { settingId: boolean }
 */
export async function readAllSettings(electronAPI) {
  const allIds = Object.keys(stateDefinitions);
  return await readMultipleSettings(allIds, electronAPI);
}
