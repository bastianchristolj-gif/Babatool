# 🚀 Configuration Supabase pour le Système de Mise à Jour

## Étape 1 : Créer un compte Supabase

1. Va sur https://supabase.com et crée un compte gratuit
2. Crée un nouveau projet (note le mot de passe de la base de données)
3. Attends que le projet soit prêt (~2 minutes)
4. Va dans **Project Settings → API** et note :
   - `Project URL` (ex: `https://xxxxx.supabase.co`)
   - `anon public key` (commence par `eyJ...`)
   - `service_role key` (GARDE-LE SECRET !)

## Étape 2 : Créer les tables

Va dans **SQL Editor** sur Supabase et exécute ce SQL :

```sql
-- ============================================================================
-- TABLE DES VERSIONS
-- ============================================================================
CREATE TABLE public.app_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  app_type TEXT NOT NULL DEFAULT 'babatoolo',
  version TEXT NOT NULL,
  download_url TEXT NOT NULL,
  patch_notes TEXT,
  is_latest BOOLEAN NOT NULL DEFAULT false,
  release_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Activer RLS (Row Level Security)
ALTER TABLE public.app_versions ENABLE ROW LEVEL SECURITY;

-- Bloquer l'accès public direct (seulement via Edge Functions)
CREATE POLICY "No public access" ON public.app_versions 
  FOR ALL USING (false) WITH CHECK (false);

-- ============================================================================
-- TABLE DES ADMINS (optionnel pour authentification)
-- ============================================================================
CREATE TABLE public.admin_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;
CREATE POLICY "No public access" ON public.admin_users 
  FOR ALL USING (false) WITH CHECK (false);
```

## Étape 3 : Créer les Edge Functions

### Option A : Via le Dashboard Supabase

1. Va dans **Edge Functions** dans ton projet Supabase
2. Clique sur **Create a new function**
3. Crée deux fonctions avec les noms et codes ci-dessous

### Option B : Via CLI Supabase

```bash
# Installer Supabase CLI
npm install -g supabase

# Login
supabase login

# Depuis le dossier du projet
supabase init
supabase functions deploy get-update-info
supabase functions deploy admin-operations
```

---

### Fonction 1 : `get-update-info`

```typescript
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { app_type } = await req.json();

    if (!app_type) {
      return new Response(
        JSON.stringify({ success: false, error: 'app_type requis' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { data, error } = await supabase
      .from('app_versions')
      .select('id, version, patch_notes, release_date, download_url')
      .eq('app_type', app_type)
      .eq('is_latest', true)
      .maybeSingle();

    if (error) {
      return new Response(
        JSON.stringify({ success: false, error: 'Erreur base de données' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!data) {
      return new Response(
        JSON.stringify({ success: true, update_available: false }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ success: true, update_available: true, version: data }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: 'Erreur serveur' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
```

---

### Fonction 2 : `admin-operations`

```typescript
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-admin-token',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { action, ...data } = await req.json();

    // === LISTER LES VERSIONS ===
    if (action === 'get_versions') {
      const { data: versions, error } = await supabase
        .from('app_versions')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return new Response(
        JSON.stringify({ success: true, versions }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // === CRÉER UNE VERSION ===
    if (action === 'create_version') {
      const { version, download_url, patch_notes, app_type } = data;
      
      // Retirer is_latest des autres versions
      await supabase
        .from('app_versions')
        .update({ is_latest: false })
        .eq('app_type', app_type || 'babatoolo');
      
      // Créer la nouvelle version
      const { data: newVersion, error } = await supabase
        .from('app_versions')
        .insert({
          version,
          download_url,
          patch_notes,
          app_type: app_type || 'babatoolo',
          is_latest: true
        })
        .select()
        .single();
      
      if (error) throw error;
      return new Response(
        JSON.stringify({ success: true, version: newVersion }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // === DÉFINIR VERSION ACTUELLE ===
    if (action === 'set_latest_version') {
      const { version_id, app_type } = data;
      
      await supabase
        .from('app_versions')
        .update({ is_latest: false })
        .eq('app_type', app_type || 'babatoolo');
      
      const { error } = await supabase
        .from('app_versions')
        .update({ is_latest: true })
        .eq('id', version_id);
      
      if (error) throw error;
      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // === SUPPRIMER UNE VERSION ===
    if (action === 'delete_version') {
      const { version_id } = data;
      
      const { error } = await supabase
        .from('app_versions')
        .delete()
        .eq('id', version_id);
      
      if (error) throw error;
      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ success: false, error: 'Action inconnue' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
    
  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
```

## Étape 4 : Configurer les variables d'environnement

Modifie `/app/frontend/.env` :

```env
REACT_APP_SUPABASE_URL=https://TONPROJET.supabase.co
REACT_APP_SUPABASE_ANON_KEY=eyJ...
```

## Étape 5 : Tester

1. Connecte-toi au panel admin : `http://localhost:3000/#/admin/login`
2. Va dans l'onglet **Versions**
3. Crée une nouvelle version avec une URL GitHub Release
4. L'app vérifiera automatiquement les mises à jour au démarrage

## 📦 Processus de Release

1. **Modifie la version** dans `/app/frontend/src/lib/version.js` :
   ```js
   export const APP_VERSION = '1.1.0';
   ```

2. **Modifie la version** dans `/app/frontend/package.json` :
   ```json
   "version": "1.1.0"
   ```

3. **Build l'app** :
   ```bash
   yarn electron:build
   ```

4. **Upload sur GitHub Releases** le fichier `.exe`

5. **Ajoute la version** dans le panel admin avec l'URL de téléchargement

## ⚠️ Notes de Sécurité

- **NE JAMAIS** exposer la `service_role key` côté client
- Les Edge Functions utilisent automatiquement la clé service_role
- La clé `anon` est sécuritaire à exposer (accès limité par RLS)
