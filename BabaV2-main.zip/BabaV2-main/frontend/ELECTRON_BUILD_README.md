# AqmOpti - Guide de Build Electron

## 📋 Prérequis

- Node.js 18+ (recommandé: 20.x)
- Yarn (package manager)
- Windows (pour builder le .exe), macOS (pour .dmg), ou Linux (pour AppImage/deb)

## 🚀 Installation

### 1. Cloner le projet et installer les dépendances

```bash
cd frontend
yarn install
```

## 🔨 Commandes de Build

### Build Windows (.exe)

```bash
yarn electron:build
```

Crée `AqmOpti-Setup-1.0.0.exe` dans le dossier `dist/`

### Build Windows (dossier unpacked)

```bash
yarn electron:build:dir
```

Crée un dossier `dist/win-unpacked/` avec l'application portable.

### Build macOS (.dmg)

```bash
yarn electron:build:mac
```

### Build Linux (AppImage, .deb)

```bash
yarn electron:build:linux
```

### Mode Développement Electron

```bash
yarn electron:dev
```

Lance l'application en mode développement avec hot-reload.

## 📁 Structure du Projet

```
frontend/
├── electron/
│   ├── main.js          # Point d'entrée Electron
│   └── preload.js       # Script de préchargement sécurisé
├── public/
│   ├── logo.png         # Icône de l'application
│   └── index.html       # Template HTML
├── src/
│   ├── App.js           # Application principale
│   ├── components/      # Composants React
│   │   ├── pages/       # Pages de l'application
│   │   ├── ui/          # Composants UI (shadcn)
│   │   └── ...
│   ├── context/         # Contexte React
│   └── ...
├── dist/                # Dossier de sortie (après build)
│   ├── AqmOpti-Setup-1.0.0.exe
│   └── win-unpacked/
└── package.json
```

## ⚙️ Configuration

### Personnaliser l'application

Modifiez `package.json` sous la section `"build"`:

```json
{
  "build": {
    "appId": "com.aqmopti.app",
    "productName": "AqmOpti",
    "nsis": {
      "shortcutName": "AqmOpti"
    }
  }
}
```

### Icône de l'application

Pour Windows (.exe), utilisez un fichier `.ico`:
1. Placez `icon.ico` dans le dossier `public/`
2. Modifiez `package.json`: `"icon": "public/icon.ico"`

Conversion PNG vers ICO:
- https://convertio.co/png-ico/
- ImageMagick: `convert logo.png -resize 256x256 icon.ico`

## 🔐 Configuration Backend

L'application utilise une URL backend configurable dans `.env`:

```env
REACT_APP_BACKEND_URL=https://votre-backend.com
```

### Déploiement du Backend

Le backend FastAPI doit être déployé séparément avec:
- MongoDB
- Les variables d'environnement:
  - `MONGO_URL`
  - `DB_NAME`
  - `JWT_SECRET_KEY` (à changer en production!)
  - `CORS_ORIGINS`

## 🧪 Test en Local

1. Démarrer le backend:
```bash
cd backend
pip install -r requirements.txt
uvicorn server:app --reload --port 8001
```

2. Démarrer le frontend en mode Electron:
```bash
cd frontend
yarn electron:dev
```

## 📌 Système de Licence

L'application inclut un système de licence HWID:

### Panel Admin
- URL: `http://localhost:3000/#/admin/login`
- Identifiants par défaut: `admin` / `admin123`

### Fonctionnalités
- ✅ Validation HWID - Chaque licence liée à un appareil
- ✅ Panel d'administration complet
- ✅ Création/modification/suppression de licences
- ✅ Statistiques en temps réel

## 🐛 Troubleshooting

### Erreur ERESOLVE (dependency conflict)
```bash
yarn install --ignore-engines
```

### Écran blanc au lancement
Vérifiez que `homepage` dans `package.json` est `"./"`.

### L'icône ne s'affiche pas
Assurez-vous que le fichier icône existe et est au bon format.

### Erreur "electron-builder" not found
```bash
yarn add electron-builder --dev
```

## 📄 License

Copyright © 2025 AqmOpti. All rights reserved.
