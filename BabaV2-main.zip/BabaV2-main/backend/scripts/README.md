# Scripts de nettoyage BaBaTool

## Fichiers

- **cleanall.ps1** : Script PowerShell principal de nettoyage
- **DeviceCleanupCmd.exe** : Outil pour nettoyer les pilotes fantômes

## Test manuel

Pour tester le script manuellement depuis PowerShell :

```powershell
# Naviguer vers le dossier
cd C:\chemin\vers\backend\scripts

# Exécuter le script
powershell -ExecutionPolicy Bypass -File .\cleanall.ps1
```

## Ce que fait cleanall.ps1

Le script effectue 4 étapes :

1. **Disk Cleanup (cleanmgr)** : Nettoie 21 catégories de fichiers système
2. **Clear Temp Folders** : Vide les dossiers temporaires et la corbeille
3. **Event Logs** : Nettoie les journaux d'événements Windows
4. **DeviceCleanupCmd** : Nettoie les pilotes fantômes

## Privilèges requis

⚠️ **Le script nécessite des privilèges administrateur** pour fonctionner correctement.

Pour exécuter avec élévation :
```powershell
Start-Process powershell -Verb RunAs -ArgumentList "-ExecutionPolicy Bypass -File .\cleanall.ps1"
```

## Intégration Electron

Le script est appelé depuis `/app/frontend/electron/main.js` via le handler `clean-system`.

Le chemin est résolu automatiquement selon l'environnement :
- **Développement** : `__dirname/../../backend/scripts/cleanall.ps1`
- **Production** : `process.resourcesPath/backend/scripts/cleanall.ps1`
