# =========================
# Clean AqmOpti
# =========================

# Dossier du script
$LogDir = $PSScriptRoot

# Fonction pour envoyer la progression
function Send-Progress {
    param(
        [int]$Percentage,
        [string]$Status
    )
    Write-Output "PROGRESS:$Percentage`:$Status"
}

function Set-DiskCleanupSettings {
    param (
        [int]$sageSetNumber = 1
    )
    
    $categories = @{
        "Active Setup Temp Folders" = 2
        "BranchCache" = 2
        "Delivery Optimization Files" = 2
        "Device Driver Packages" = 2
        "Diagnostic Data Viewer database files" = 2
        "Downloaded Program Files" = 2
        "Internet Cache Files" = 2
        "Language Pack" = 2
        "Offline Pages Files" = 2
        "Old ChkDsk Files" = 2
        "Setup Log Files" = 2
        "System error memory dump files" = 2
        "System error minidump files" = 2
        "Temporary Setup Files" = 2
        "Temporary Sync Files" = 2
        "Update Cleanup" = 2
        "Upgrade Discarded Files" = 2
        "User file versions" = 2
        "Windows Defender" = 2
        "Windows Error Reporting Files" = 2
        "Windows Reset Log Files" = 2
        "Windows Upgrade Log Files" = 2
    }
    
    $registryPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches"
    
    foreach ($item in $categories.GetEnumerator()) {
        $keyPath = Join-Path -Path $registryPath -ChildPath $item.Key
        if (Test-Path $keyPath) {
            Set-ItemProperty -Path $keyPath -Name "StateFlags$sageSetNumber" -Value $item.Value -Type DWORD -Force
        } else {
            Write-Warning "Category '$($item.Key)' not found in the registry."
        }
    }
}

$ErrorActionPreference = 'SilentlyContinue'

Send-Progress -Percentage 0 -Status "Nettoyage en cours..."

function CustomFileCleanup {
    # Exclude the AME folder when deleting directories in the temporary user folder
    Get-ChildItem -Path "$env:TEMP" | Where-Object { $_.Name -ne 'AME' } | Remove-Item -Force -Recurse

    # List of paths to clean up
    $cleanupPaths = @(
        "$env:WinDir\Temp\*"
        "$env:WinDir\Temp"
        "$env:WinDir\ff*.tmp"
        "$env:WinDir\History\*"
        "$env:WinDir\Cookies\*"
        "$env:WinDir\Recent\*"
        "$env:WinDir\Spool\Printers\*"
        "$env:WinDir\Prefetch\*"
        "$env:LOCALAPPDATA\Microsoft\Windows\INetCache\IE\*"
        "$env:WinDir\Downloaded Program Files\*"
        "$env:SYSTEMDRIVE\$Recycle.Bin\*"
        "$env:SystemRoot\setupapi.log"
        "$env:SystemRoot\Panther\*"
        "$env:SystemRoot\INF\setupapi.app.log"
        "$env:SystemRoot\INF\setupapi.dev.log"
        "$env:SystemRoot\INF\setupapi.offline.log"
    )

    foreach ($path in $cleanupPaths) {
        if (Test-Path $path) {
            Write-Host "Cleaning up $path"
            Get-ChildItem -Path $path -Force -Recurse -ErrorAction SilentlyContinue -Verbose | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue -Verbose
        } else {
            Write-Host "Path $path not found"
        }
    }
}

# Set disk cleanup settings in the registry
Send-Progress -Percentage 5 -Status "Nettoyage en cours..."
Set-DiskCleanupSettings -sageSetNumber 1

# Start disk cleanup utility with configured settings
Send-Progress -Percentage 10 -Status "Nettoyage en cours..."
$cleanupProcess = Start-Process -FilePath "$env:SystemRoot\system32\cleanmgr.exe" -ArgumentList "/sagerun:1" -PassThru

# Wait for the process to complete or time out
$timeout = 60 # Timeout in seconds
$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

while (-not $cleanupProcess.HasExited -and $stopwatch.Elapsed.TotalSeconds -lt $timeout) {
    Start-Sleep -Seconds 5
}

if (-not $cleanupProcess.HasExited) {
    Write-Warning "Disk Cleanup did not complete in $timeout seconds. Terminating process."
    Stop-Process -Id $cleanupProcess.Id -Force
}

Send-Progress -Percentage 30 -Status "Nettoyage en cours..."

# Perform custom cleanup tasks
CustomFileCleanup

Send-Progress -Percentage 50 -Status "Nettoyage en cours..."

# Delete all system restore points
vssadmin delete shadows /all /quiet

Send-Progress -Percentage 60 -Status "Nettoyage en cours..."

# Clear Event Logs
wevtutil el | ForEach-Object {wevtutil cl "$_"} 2>&1 | Out-Null

# --- STEP 2: Clear temp folders ---
Send-Progress -Percentage 70 -Status "Nettoyage en cours..."

function Clear-Folder($Path) {
    if (Test-Path -LiteralPath $Path) {
        try {
            Get-ChildItem -LiteralPath $Path -Force | ForEach-Object {
                try {
                    if ($_.PSIsContainer) {
                        Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
                    } else {
                        Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue
                    }
                } catch {}
            }
        } catch {}
    }
}

Clear-Folder $env:TEMP
Clear-Folder "$env:LOCALAPPDATA\Temp"
Clear-Folder "$env:WINDIR\Temp"
Clear-Folder "$env:LOCALAPPDATA\Microsoft\Windows\INetCache"

if (Test-Path "$env:LOCALAPPDATA\Microsoft\Windows\Explorer") {
    Get-ChildItem "$env:LOCALAPPDATA\Microsoft\Windows\Explorer" -Filter "thumbcache_*.db" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
}

try {
    Clear-RecycleBin -Force -ErrorAction SilentlyContinue
} catch {}

Send-Progress -Percentage 85 -Status "Nettoyage en cours..."

# --- STEP 3: Event logs ---
try {
    wevtutil el | ForEach-Object {
        try { wevtutil cl $_ } catch {}
    }
} catch {}

Send-Progress -Percentage 95 -Status "Nettoyage en cours..."

# --- STEP 4: DeviceCleanupCmd.exe ---
$devCleanup = Join-Path $LogDir "DeviceCleanupCmd.exe"
if (Test-Path $devCleanup) {
    try {
        Start-Process -FilePath $devCleanup -ArgumentList "* -s -n" -WindowStyle Hidden -Wait
    } catch {}
}

Send-Progress -Percentage 100 -Status "Nettoyage terminé"
