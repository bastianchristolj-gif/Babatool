# Script OOSU10 Silent - Chemin personnalisé Desktop
$ErrorActionPreference='SilentlyContinue'
$ProgressPreference='SilentlyContinue'

# Chemin du fichier cfg sur le Desktop
$desktopPath = [Environment]::GetFolderPath('Desktop')
$cfgPath = Join-Path $desktopPath "O&OSU10\ooshutup10.cfg"

# Vérifier si le fichier existe
if (-not (Test-Path $cfgPath)) {
    # Essayer avec un chemin alternatif (sans &)
    $cfgPathAlt = Join-Path $desktopPath "OOSU10\ooshutup10.cfg"
    if (Test-Path $cfgPathAlt) {
        $cfgPath = $cfgPathAlt
    } else {
        exit 1
    }
}

# Télécharger OOSU10
$exePath = "$env:TEMP\OOSU10.exe"
if (-not (Test-Path $exePath)) {
    try {
        Invoke-WebRequest -Uri "https://dl5.oo-software.com/files/ooshutup10/OOSU10.exe" `
            -OutFile $exePath -UseBasicParsing
    } catch {
        # Essayer avec une autre méthode
        try {
            $webClient = New-Object System.Net.WebClient
            $webClient.DownloadFile("https://dl5.oo-software.com/files/ooshutup10/OOSU10.exe", $exePath)
        } catch {
            exit 2
        }
    }
}

# Fermer OOSU10 si déjà ouvert
Get-Process "OOSU10" -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 300

# Appliquer la configuration
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $exePath
$psi.Arguments = "`"$cfgPath`" /quiet"
$psi.CreateNoWindow = $true
$psi.WindowStyle = 'Hidden'
$psi.UseShellExecute = $false

$process = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Seconds 15

# Fermer OOSU10
if ($process -and (-not $process.HasExited)) {
    $process.Kill()
}

# Nettoyer
Get-Process "OOSU10" -ErrorAction SilentlyContinue | Stop-Process -Force
Remove-Item $exePath -ErrorAction SilentlyContinue

exit 0