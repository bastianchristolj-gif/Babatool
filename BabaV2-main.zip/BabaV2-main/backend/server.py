from fastapi import FastAPI, APIRouter, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
import subprocess
import tempfile
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional
import uuid
from datetime import datetime, timezone, timedelta
import hashlib
import secrets
import jwt
from passlib.context import CryptContext


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# Security
SECRET_KEY = os.environ.get('JWT_SECRET_KEY', secrets.token_urlsafe(32))
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 24 hours
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI(title="Atlas Toolbox License System")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")


# ============================================================================
# MODELS
# ============================================================================

class StatusCheck(BaseModel):
    model_config = ConfigDict(extra="ignore")
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    client_name: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class StatusCheckCreate(BaseModel):
    client_name: str

# License Models
class License(BaseModel):
    model_config = ConfigDict(extra="ignore")
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    license_key: str
    pseudo: Optional[str] = None
    hwid_hash: Optional[str] = None
    status: str = "active"  # active, suspended, expired
    plan: str = "lifetime"  # lifetime, standard, trial
    max_devices: int = 1
    expires_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    last_used: Optional[datetime] = None
    notes: Optional[str] = None

class LicenseCreate(BaseModel):
    pseudo: Optional[str] = None
    duration_days: int = 0  # 0 = lifetime
    max_devices: int = 1
    notes: Optional[str] = None
    plan: str = "lifetime"  # lifetime, standard, trial

class LicenseUpdate(BaseModel):
    pseudo: Optional[str] = None
    status: Optional[str] = None
    plan: Optional[str] = None
    expires_at: Optional[datetime] = None
    max_devices: Optional[int] = None
    notes: Optional[str] = None
    hwid_hash: Optional[str] = None

class LicenseValidateRequest(BaseModel):
    license_key: str
    hwid: str

class LicenseValidateResponse(BaseModel):
    valid: bool
    message: str
    license: Optional[License] = None

# Admin Models
class Admin(BaseModel):
    model_config = ConfigDict(extra="ignore")
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    username: str
    password_hash: str
    role: str = "admin"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class AdminLogin(BaseModel):
    username: str
    password: str

class AdminLoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    username: str

class DashboardStats(BaseModel):
    total_licenses: int
    active_licenses: int
    expired_licenses: int
    suspended_licenses: int
    activated_licenses: int


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def generate_license_key() -> str:
    """Generate a unique license key"""
    return '-'.join([
        secrets.token_hex(4).upper(),
        secrets.token_hex(4).upper(),
        secrets.token_hex(4).upper(),
        secrets.token_hex(4).upper()
    ])

def hash_hwid(hwid: str) -> str:
    """Hash HWID for security"""
    return hashlib.sha256(hwid.encode()).hexdigest()

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify password"""
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password: str) -> str:
    """Hash password"""
    return pwd_context.hash(password)

def create_access_token(data: dict) -> str:
    """Create JWT token"""
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_admin(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Verify JWT token and get current admin"""
    try:
        token = credentials.credentials
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=401, detail="Invalid authentication credentials")
        
        admin = await db.admins.find_one({"username": username}, {"_id": 0})
        if admin is None:
            raise HTTPException(status_code=401, detail="Admin not found")
        return Admin(**admin)
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid token")


# ============================================================================
# ADMIN ROUTES
# ============================================================================

@api_router.post("/admin/login", response_model=AdminLoginResponse)
async def admin_login(credentials: AdminLogin):
    """Admin login endpoint"""
    admin = await db.admins.find_one({"username": credentials.username}, {"_id": 0})
    
    if not admin or not verify_password(credentials.password, admin["password_hash"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password"
        )
    
    access_token = create_access_token(data={"sub": admin["username"]})
    return AdminLoginResponse(
        access_token=access_token,
        username=admin["username"]
    )

@api_router.get("/admin/stats", response_model=DashboardStats)
async def get_dashboard_stats(admin: Admin = Depends(get_current_admin)):
    """Get dashboard statistics"""
    total = await db.licenses.count_documents({})
    active = await db.licenses.count_documents({"status": "active"})
    expired = await db.licenses.count_documents({"status": "expired"})
    suspended = await db.licenses.count_documents({"status": "suspended"})
    activated = await db.licenses.count_documents({"hwid_hash": {"$ne": None}})
    
    return DashboardStats(
        total_licenses=total,
        active_licenses=active,
        expired_licenses=expired,
        suspended_licenses=suspended,
        activated_licenses=activated
    )

@api_router.get("/admin/licenses", response_model=List[License])
async def get_all_licenses(admin: Admin = Depends(get_current_admin)):
    """Get all licenses"""
    licenses = await db.licenses.find({}, {"_id": 0}).to_list(1000)
    
    # Convert ISO strings back to datetime
    for lic in licenses:
        if isinstance(lic.get('created_at'), str):
            lic['created_at'] = datetime.fromisoformat(lic['created_at'])
        if lic.get('expires_at') and isinstance(lic['expires_at'], str):
            lic['expires_at'] = datetime.fromisoformat(lic['expires_at'])
        if lic.get('last_used') and isinstance(lic['last_used'], str):
            lic['last_used'] = datetime.fromisoformat(lic['last_used'])
    
    return licenses

@api_router.post("/admin/licenses", response_model=License)
async def create_license(license_data: LicenseCreate, admin: Admin = Depends(get_current_admin)):
    """Create a new license"""
    license_key = generate_license_key()
    
    expires_at = None
    if license_data.duration_days != 0:
        expires_at = datetime.now(timezone.utc) + timedelta(days=license_data.duration_days)
    
    license_obj = License(
        license_key=license_key,
        pseudo=license_data.pseudo,
        max_devices=license_data.max_devices,
        expires_at=expires_at,
        notes=license_data.notes,
        plan=license_data.plan
    )
    
    # Convert to dict and serialize datetime to ISO string
    doc = license_obj.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    if doc.get('expires_at'):
        doc['expires_at'] = doc['expires_at'].isoformat()
    
    await db.licenses.insert_one(doc)
    return license_obj

@api_router.put("/admin/licenses/{license_id}", response_model=License)
async def update_license(license_id: str, license_data: LicenseUpdate, admin: Admin = Depends(get_current_admin)):
    """Update a license"""
    existing = await db.licenses.find_one({"id": license_id}, {"_id": 0})
    if not existing:
        raise HTTPException(status_code=404, detail="License not found")
    
    update_data = license_data.model_dump(exclude_unset=True)
    
    # Convert datetime to ISO string
    if 'expires_at' in update_data and update_data['expires_at']:
        update_data['expires_at'] = update_data['expires_at'].isoformat()
    
    # Handle hwid_hash reset (None value)
    if 'hwid_hash' in update_data:
        # Explicitly set to None for HWID reset
        pass
    
    await db.licenses.update_one({"id": license_id}, {"$set": update_data})
    
    updated = await db.licenses.find_one({"id": license_id}, {"_id": 0})
    
    # Convert back to datetime
    if isinstance(updated.get('created_at'), str):
        updated['created_at'] = datetime.fromisoformat(updated['created_at'])
    if updated.get('expires_at') and isinstance(updated['expires_at'], str):
        updated['expires_at'] = datetime.fromisoformat(updated['expires_at'])
    if updated.get('last_used') and isinstance(updated['last_used'], str):
        updated['last_used'] = datetime.fromisoformat(updated['last_used'])
    
    return License(**updated)

@api_router.delete("/admin/licenses/{license_id}")
async def delete_license(license_id: str, admin: Admin = Depends(get_current_admin)):
    """Delete a license"""
    result = await db.licenses.delete_one({"id": license_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="License not found")
    return {"message": "License deleted successfully"}


# ============================================================================
# LICENSE VALIDATION ROUTES (PUBLIC)
# ============================================================================

@api_router.post("/license/validate", response_model=LicenseValidateResponse)
async def validate_license(request: LicenseValidateRequest):
    """Validate license with HWID"""
    hwid_hash = hash_hwid(request.hwid)
    
    # Find license
    license_doc = await db.licenses.find_one({"license_key": request.license_key}, {"_id": 0})
    
    if not license_doc:
        return LicenseValidateResponse(
            valid=False,
            message="Clé de licence invalide"
        )
    
    # Convert strings back to datetime
    if isinstance(license_doc.get('created_at'), str):
        license_doc['created_at'] = datetime.fromisoformat(license_doc['created_at'])
    if license_doc.get('expires_at') and isinstance(license_doc['expires_at'], str):
        license_doc['expires_at'] = datetime.fromisoformat(license_doc['expires_at'])
    if license_doc.get('last_used') and isinstance(license_doc['last_used'], str):
        license_doc['last_used'] = datetime.fromisoformat(license_doc['last_used'])
    
    license_obj = License(**license_doc)
    
    # Check if license is suspended
    if license_obj.status == "suspended":
        return LicenseValidateResponse(
            valid=False,
            message="Cette licence a été suspendue",
            license=license_obj
        )
    
    # Check if license is expired
    if license_obj.expires_at and license_obj.expires_at < datetime.now(timezone.utc):
        # Update status to expired
        await db.licenses.update_one(
            {"license_key": request.license_key},
            {"$set": {"status": "expired"}}
        )
        return LicenseValidateResponse(
            valid=False,
            message="Cette licence a expiré",
            license=license_obj
        )
    
    # Check HWID
    if license_obj.hwid_hash is None:
        # First activation - bind to this HWID
        await db.licenses.update_one(
            {"license_key": request.license_key},
            {
                "$set": {
                    "hwid_hash": hwid_hash,
                    "last_used": datetime.now(timezone.utc).isoformat()
                }
            }
        )
        license_obj.hwid_hash = hwid_hash
        license_obj.last_used = datetime.now(timezone.utc)
        
        return LicenseValidateResponse(
            valid=True,
            message="Licence activée avec succès !",
            license=license_obj
        )
    
    # Check if HWID matches
    if license_obj.hwid_hash != hwid_hash:
        return LicenseValidateResponse(
            valid=False,
            message="Cette licence est liée à un autre appareil",
            license=license_obj
        )
    
    # Update last used
    await db.licenses.update_one(
        {"license_key": request.license_key},
        {"$set": {"last_used": datetime.now(timezone.utc).isoformat()}}
    )
    
    return LicenseValidateResponse(
        valid=True,
        message="Licence valide",
        license=license_obj
    )


# ============================================================================
# BASIC ROUTES
# ============================================================================

@api_router.get("/")
async def root():
    return {"message": "Atlas Toolbox License System API"}

@api_router.post("/status", response_model=StatusCheck)
async def create_status_check(input: StatusCheckCreate):
    status_dict = input.model_dump()
    status_obj = StatusCheck(**status_dict)
    
    doc = status_obj.model_dump()
    doc['timestamp'] = doc['timestamp'].isoformat()
    
    _ = await db.status_checks.insert_one(doc)
    return status_obj

@api_router.get("/status", response_model=List[StatusCheck])
async def get_status_checks():
    status_checks = await db.status_checks.find({}, {"_id": 0}).to_list(1000)
    
    for check in status_checks:
        if isinstance(check['timestamp'], str):
            check['timestamp'] = datetime.fromisoformat(check['timestamp'])
    
    return status_checks


# ============================================================================
# SCRIPT EXECUTION API
# ============================================================================

class ScriptExecutionRequest(BaseModel):
    script: str
    script_type: str = "bat"  # bat or powershell

class ScriptExecutionResponse(BaseModel):
    success: bool
    output: str
    error: Optional[str] = None

@api_router.post("/execute-script", response_model=ScriptExecutionResponse)
async def execute_script(request: ScriptExecutionRequest):
    """Execute .bat or PowerShell scripts"""
    import subprocess
    import tempfile
    
    try:
        if request.script_type == "bat":
            # Create temporary .bat file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.bat', delete=False) as f:
                f.write(request.script)
                temp_file = f.name
            
            # Execute the .bat file
            result = subprocess.run(
                ['cmd', '/c', temp_file],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            # Clean up
            os.remove(temp_file)
            
        elif request.script_type == "powershell":
            # Execute PowerShell command
            result = subprocess.run(
                ['powershell', '-Command', request.script],
                capture_output=True,
                text=True,
                timeout=30
            )
        else:
            return ScriptExecutionResponse(
                success=False,
                output="",
                error="Type de script non supporté"
            )
        
        return ScriptExecutionResponse(
            success=result.returncode == 0,
            output=result.stdout,
            error=result.stderr if result.returncode != 0 else None
        )
        
    except subprocess.TimeoutExpired:
        return ScriptExecutionResponse(
            success=False,
            output="",
            error="Timeout: Script execution took too long"
        )
    except Exception as e:
        return ScriptExecutionResponse(
            success=False,
            output="",
            error=str(e)
        )


class FortniteConfigRequest(BaseModel):
    resolutionX: int = 1600
    resolutionY: int = 900
    windowMode: int = 0  # 0=Fullscreen, 1=Windowed, 2=WindowedFullscreen
    frameRateLimit: float = 360.0
    shadows: int = 0
    textures: int = 0
    effects: int = 0
    antiAliasing: int = 0
    viewDistance: int = 1
    postProcessing: int = 0

class FortniteConfigResponse(BaseModel):
    success: bool
    message: str
    file_path: Optional[str] = None

# Template for Fortnite GameUserSettings.ini - values will be replaced
FORTNITE_CONFIG_TEMPLATE = ''';METADATA=(Diff=true, UseCommands=true)
[/Script/FortniteGame.FortGameUserSettings]
FullscreenMode=0
AutoDownloadHighResTexturesBehavior=Disabled_Permanent
CosmeticStreamingEnabled=CodeSet_Enabled
FortniteReleaseVersion=13
UnlockConsoleFPS=False
SubGameSelectCount_Athena=3
SubGameLastSelectedTime_Athena=2026.01.16-17.12.51
SubGameSelectCount_Campaign=0
SubGameLastSelectedTime_Campaign=0001.01.01-00.00.00
LastTimeSettingsSnapshotUploaded=0001.01.01-00.00.00
LastTimeLockerPresetCountUploaded=2026.01.16-16.04.53
FirstLoginOnDevice=2026.01.16-17.04.49
SafeZone=1.000000
bIsSafeZoneSet=False
CachedPlayerLevel=0
bShowActorsWithSeasonItemTagMapIndicators=True
CachedBattleStars=0
CachedAlienStylePoints=0
CachedStylePoints=0
CachedClaimableRewards=()
CachedHighestBattlePassUnlockedPage=1
bShowCareerShowcaseTabBang=False
bArmASREnabled=False
CustomVoiceChatInputDevice=
CustomVoiceChatOutputDevice=
CustomVoiceChatInputDeviceId=
CustomVoiceChatOutputDeviceId=
bMotionBlur=False
bAllowUIParallax=True
bShowGrass=False
bShowFPS=True
bUseGPUCrashDebugging=False
bStopRenderingInBackground=False
bLatencyTweak1=False
LatencyTweak2=0
bLatencyFlash=False
FortAntiAliasingMethod=TSRMedium
bEnableDLSSFrameGeneration=False
TemporalSuperResolutionQuality=Recommended
DLSSQuality=0
XeSSQuality=2
PotentiallyUpscaledResolutionQuality=100.000000
NeverUpscaledResolutionQuality=100.000000
bUseNanite=False
DesiredGlobalIlluminationQuality=0
DesiredReflectionQuality=0
PreNaniteGlobalIlluminationQuality=0
PreNaniteReflectionQuality=0
bRayTracing=False
b120FpsMode=False
FrontendFrameRateLimit=120
bIsEnergySavingEnabledIdle=True
bIsEnergySavingEnabledFocusLoss=True
EnergySavingLevelFocusLoss=1
DisplayGamma=2.200000
UserInterfaceContrast=1.000000
NamedTimes=(("RankedStartTime_User_7201048d304146488ce66b02aaa70e4c_Track_S4B3R5", 2026.01.16-17.39.06))
NamedCounts=(("lastfrontendflow_Fortnite", 39),("lastfrontendflow_Fortnite_HotfixVer", 0),("UEnableMultiFactorModal::ShouldShowMFASplashScreen", 39),("UEnableMultiFactorModal::ShouldShowMFASplashScreen_HotfixVer", 0))
BattlePassOverrideTracker=0
NewestProgressiveCosmeticSetSeen=
CurrentLockerSortsByTag=()
CurrentLockerFiltersByTag=()
ArchetypeShuffleSelectionBias=()
bLockerHideUnsupportedItems=False
bLockerSortItemsByRelevance=True
bHasUsedBattlePassCrewUpsellNavButton=False
LastExpectedShopRefreshTime=2026.01.17-00.00.00
bHasSeenItemShop=True
AboutShopModalVersionSeen=-1
HasSeenAboutItemModalTypes=()
bHasSeenJunoOutfitsFTUE=False
JunoFTUEQuestTrackingDisabledVersion=0
bHasSeenDonutShopSequence=False
DonutIdleGameHighScore=0.000000
RowIdToOfferSeenLevel=(("BestSellers.1", Unseen),("AdventTime21.99", Unseen),("AdventTime21.98", Unseen),("AdventTime21.97", Unseen),("AdventTime21.96", Unseen),("AdventTime21.95", Unseen),("VV01161.99", Unseen),("VV01161.98", Unseen),("Kaiju.99", Unseen),("Kaiju.98", Unseen),("SouthPark.99", Unseen),("SouthPark.98", Unseen),("SouthPark.97", Unseen),("SouthPark.96", Unseen),("SouthPark.95", Unseen),("SouthPark.94", Unseen),("FND0116.99", Unseen),("FND0116.98", Unseen),("FND0116.97", Unseen),("FND0116.96", Unseen),("FND0116.95", Unseen),("FND0116.94", Unseen),("WinterSki.99", Unseen),("WinterSki.98", Unseen),("WinterSki.97", Unseen),("WinterSki.96", Unseen),("WinterSki.95", Unseen),("WinterSki.94", Unseen),("BR0116.99", Unseen),("BR0116.98", Unseen),("BR0116.97", Unseen),("BR0116.96", Unseen),("BR0116.95", Unseen),("BR0116.94", Unseen),("28Years1.99", Unseen),("SuperOG.99", Unseen),("JT0116.99", Unseen),("JT0116.98", Unseen),("JT0116.97", Unseen),("JT0116.96", Unseen),("OffWhiteNimbusCar.99", Unseen),("DiestroCar.99", Unseen),("LandRoverDefenderSUV.99", Unseen),("FastenDark.99", Unseen),("BrunoMars.99", Unseen),("BrunoMars.98", Unseen),("BrunoMars.97", Unseen),("BrunoMars.96", Unseen),("BlackPinkLisa.99", Unseen),("BlackPinkLisa.98", Unseen),("BattlePassCrew.1", Unseen),("BattlePassCrew.3", Unseen),("BattlePassCrew.4", Unseen),("BattlePassCrew.5", Unseen),("LimitedTime.1", Unseen),("LimitedTime.3", Unseen),("LimitedTime.4", Unseen))
LastSelectedIsland="{\\\"LinkId\\\":\\\"\\\",\\\"Session\\\":{\\\"iD\\\":\\\"\\\",\\\"joinInfo\\\":{\\\"joinability\\\":\\\"CanNotBeJoinedOrWatched\\\",\\\"sessionKey\\\":\\\"\\\"}},\\\"MatchmakingSettingsV2\\\":{\\\"/Fortnite.com/Matchmaking:Region\\\":\\\"NONE\\\"}}"
LastPlayedIsland="{\\\"LinkId\\\":\\\"tournament_epicgames_s39_reloadeliteseries1opens_eu\\\",\\\"Session\\\":{\\\"iD\\\":\\\"\\\",\\\"joinInfo\\\":{\\\"joinability\\\":\\\"CanNotBeJoinedOrWatched\\\",\\\"sessionKey\\\":\\\"\\\"}},\\\"MatchmakingSettingsV1\\\":{\\\"world\\\":{\\\"iD\\\":\\\"\\\",\\\"ownerId\\\":\\\"INVALID\\\",\\\"name\\\":\\\"\\\",\\\"bIsJoinable\\\":false},\\\"productModes\\\":[],\\\"privacy\\\":\\\"NoFill\\\",\\\"regionId\\\":\\\"EU\\\"}}"
LastSelectedPlaylist=(PlaylistName="",TournamentID="",EventWindowId="",LinkId=(Mnemonic="",Version=-1),ProductModes=)
LastSelectedFillOption=True
bLastSelectedPrivateMatchOption=False
CustomMatchOptions=()
CreativeOptions=(("CreativeOption_EditorCamera", 0))
bHasSeenCreativePhoneTutorial=False
bHasSeenCreativeHeatmapTutorial=False
CreativeOptionLastUsedCategory=0
CreativeOptionLastUsedIndexInCategory=0
LastSelectedChildActivityMap=()
ClamOneDMVersion=1
ClamOneDMPreviousVersion=1
ClamOneDMMaxEvents=200
LastNewsVersionViewedBR=
LastNewsVersionViewedCreative=
LastNewsVersionViewedSTW=
LastPRMEtag=
LastFrontEndBackPlateStageUsed[0]=season3920
LastFrontEndBackPlateStageUsed[1]=default
bEulaAccepted=True
EulaAcceptedUserId=7201048d304146488ce66b02aaa70e4c
LastEulaCheckTime=2026.01.16-16.04.53
EulaCacheVersion=1
HUDLayoutData[0]=(LayoutEntries=)
HUDLayoutData[1]=(LayoutEntries=)
HUDLayoutData[2]=(LayoutEntries=)
bHasBeenNotifiedAboutLegacyLayoutDeprecation=False
ActiveHUDProfileIdentifier=(HUDProfileType=(TagName=""),Guid=00000000000000000000000000000000)
bTimesSeenBacchusLoadTutorial=0
bHasSeenTapToShoot=False
NumTimesSeeingPanningTip=0
FireModeData=(bAutoFireIsEnabled=True,b3DTouchEnabled=False,bTapToShootEnabled=False,bAlwaysShowDedicatedButton=True,FireModeType=Unset)
SimpleMobileStats=(GamesPlayed=21,SecondsPlayed=8987,KillCount=55,BestResult=1,LastReviewPromptDay=0001.01.01-00.00.00,CampaignGamesPlayed=0)
AudioOutputDeviceId=
bUseHeadphoneMode=False
InitialBenchmarkState=1
bDisableMouseAcceleration=False
ChosenLoginType=None
SocialImportOptedOutVersion=0
VKImportOptedOutVersion=0
bHasSeenErebusSocialImport=False
bHasSeenFriendImportToast=False
LastSocialImportPromptTime=0001.01.01-00.00.00
bAutoImportFriendEnabled=False
bSeenLetoSellModal=False
SocialImportPromptCountCurrentVersion=0
SocialImportPromptCountAllVersions=0
VKImportPromptCountCurrentVersion=0
VKImportPromptCountAllVersions=0
LastAccountItemWarningTime=0001.01.01-00.00.00
bMultiFactorAuthModalOpOut=False
LastEnableMFAModalPromptTime=0001.01.01-00.00.00
LastVKImportPromptTime=0001.01.01-00.00.00
LastAffiliateToastTime=0001.01.01-00.00.00
FailedInviteMap=()
MobileRecommendationDismissedVersion=0
ShowLiveStreamPictureInPictureInMatchV2=Default
CurrentLivePiPStreamOverrideCounter=0
SelectedFrontEnd=
bNeverShowMobileLink=False
bHasMigratedDownloadSettings=False
bSendAppsFlyerEventOnInstallation=True
bAllowFullGameDownload=False
ReducedDataUsage=UnSet
bAllowCellularDownload=False
LastAutoDownloadHighResTextureReminder=639041913603840000
bOverrideMobileScalabilityForNewUser=False
bShouldTryShowMobileDefaultSettingsChanged=False
bAutoLaunchFullGame=False
bAllowDownloadHighResMips=False
ContentQualityLevelSelected=Unset
TextureQualityLevel=UnSet
bAllowLowPowerMode=False
bAllowVideoPlayback=True
MobileFPSMode=Mode_30Fps
MobileQualitySettingsResetDefaultsGUID=
bHasSeenSamsungPressureSensorWarning=False
bNeverDisplaySamsungPressureSensorWarning=False
bHasRecentlySeenBadMatchPopup=False
MatchesSinceLastBadMatchPopup=0
bHasAlreadyRatedOnGooglePlay=False
DaysToSnoozeBeforeNextGooglePlayRating=0
GooglePlayRatingDelayedOccurences=0
ParsleyIdleTime=Minutes_15
bShowTemperature=False
LastGameStartNotificationSentTime=0001.01.01-00.00.00
LastYearForcedDisplayWinterfestInfoButton=0
LastYearWinterfestWasSeen=0
bHasSeenSidekickWelcomePopup=False
bHasSeenLobbyModeSetNotification=False
bHasSeenLobbyModeChangedNotification=False
bHasSeenDiscoveryDetailsModeSetNotification=False
bHasSeenDiscoveryCCUModal=False
bHasSeenCreatorPageFirstTimeTooltip=False
LowInputLatencyModeIsEnabled=True
bNeedsToSeeFireModeSelectionReminder=False
MatchesSinceInitialFireModeSelection=0
bIsChatNotificationSettingInitialized=False
LastLaunchPushNotificationState=NotSet
bIsPushNotificationConsentValid=False
GlobalConfigData=()
SavedVariantOverridesMap=()
bUseVSync=False
bUseDynamicResolution=False
ResolutionSizeX=1600
ResolutionSizeY=900
LastUserConfirmedResolutionSizeX=1600
LastUserConfirmedResolutionSizeY=900
LastConfirmedFullscreenMode=0
PreferredFullscreenMode=0
AudioQualityLevel=1
LastConfirmedAudioQualityLevel=1
FrameRateLimit=360.000000
DesiredScreenWidth=1280
DesiredScreenHeight=720
LastUserConfirmedDesiredScreenWidth=1280
LastUserConfirmedDesiredScreenHeight=720
LastRecommendedScreenWidth=-1.000000
LastRecommendedScreenHeight=-1.000000
LastCPUBenchmarkResult=158.025162
LastGPUBenchmarkResult=494.159302
LastGPUBenchmarkMultiplier=1.000000
bUseHDRDisplayOutput=False
HDRDisplayOutputNits=1000
RecentSelections="(Island={\\"LinkId\\":\\"tournament_epicgames_s39_reloadeliteseries1opens_eu\\",\\"Session\\":{\\"iD\\":\\"\\",\\"joinInfo\\":{\\"joinability\\":\\"CanNotBeJoinedOrWatched\\",\\"sessionKey\\":\\"\\"}},\\"MatchmakingSettingsV1\\":{\\"world\\":{\\"iD\\":\\"\\",\\"ownerId\\":\\"INVALID\\",\\"name\\":\\"\\",\\"bIsJoinable\\":false},\\"productModes\\":[],\\"privacy\\":\\"Fill\\",\\"regionId\\":\\"EU\\"}},Timestamp=1768594579,bUsingGracefulUpgrade=True,MatchmakingId=\\"4AEA7EFA458576EAE2E8448CAB7A932B\\")"
RecentSelections="(Island={\\"LinkId\\":\\"7835-3901-1999\\",\\"Session\\":{\\"iD\\":\\"\\",\\"joinInfo\\":{\\"joinability\\":\\"CanNotBeJoinedOrWatched\\",\\"sessionKey\\":\\"\\"}},\\"MatchmakingSettingsV1\\":{\\"world\\":{\\"iD\\":\\"\\",\\"ownerId\\":\\"INVALID\\",\\"name\\":\\"\\",\\"bIsJoinable\\":false},\\"productModes\\":[],\\"privacy\\":\\"Fill\\",\\"regionId\\":\\"EU\\"}},Timestamp=1768586424,bUsingGracefulUpgrade=True,MatchmakingId=\\"395BA4E94CCB2114465C01B16F6B2A2D\\")"
RecentSelections="(Island={\\"LinkId\\":\\"6570-5231-1418\\",\\"Session\\":{\\"iD\\":\\"\\",\\"joinInfo\\":{\\"joinability\\":\\"CanNotBeJoinedOrWatched\\",\\"sessionKey\\":\\"\\"}},\\"MatchmakingSettingsV1\\":{\\"world\\":{\\"iD\\":\\"\\",\\"ownerId\\":\\"INVALID\\",\\"name\\":\\"\\",\\"bIsJoinable\\":false},\\"productModes\\":[],\\"privacy\\":\\"Fill\\",\\"regionId\\":\\"EU\\"}},Timestamp=1768586117,bUsingGracefulUpgrade=True,MatchmakingId=\\"D66DFD074D73B0883150B7A1A1F9ED83\\")"
RecentSelections="(Island={\\"LinkId\\":\\"playlist_habanero_sunflower_duos\\",\\"Session\\":{\\"iD\\":\\"\\",\\"joinInfo\\":{\\"joinability\\":\\"CanNotBeJoinedOrWatched\\",\\"sessionKey\\":\\"\\"}},\\"MatchmakingSettingsV1\\":{\\"world\\":{\\"iD\\":\\"\\",\\"ownerId\\":\\"INVALID\\",\\"name\\":\\"\\",\\"bIsJoinable\\":false},\\"productModes\\":[],\\"privacy\\":\\"NoFill\\",\\"regionId\\":\\"EU\\"}},Timestamp=1768585311,bUsingGracefulUpgrade=True,MatchmakingId=\\"5991D87944A8B42F03CD679317628483\\")"
RecentSelections="(Island={\\"LinkId\\":\\"playlist_sunflowerduo\\",\\"Session\\":{\\"iD\\":\\"\\",\\"joinInfo\\":{\\"joinability\\":\\"CanNotBeJoinedOrWatched\\",\\"sessionKey\\":\\"\\"}},\\"MatchmakingSettingsV1\\":{\\"world\\":{\\"iD\\":\\"\\",\\"ownerId\\":\\"INVALID\\",\\"name\\":\\"\\",\\"bIsJoinable\\":false},\\"productModes\\":[],\\"privacy\\":\\"NoFill\\",\\"regionId\\":\\"EU\\"}},Timestamp=1768585110,bUsingGracefulUpgrade=True,MatchmakingId=\\"04141FFE4D6DB5F85BF0168F0E98C44C\\")"
RecentSelections="(Island={\\"LinkId\\":\\"playlist_habanero_sunflower_solo\\",\\"Session\\":{\\"iD\\":\\"\\",\\"joinInfo\\":{\\"joinability\\":\\"CanNotBeJoinedOrWatched\\",\\"sessionKey\\":\\"\\"}},\\"MatchmakingSettingsV1\\":{\\"world\\":{\\"iD\\":\\"\\",\\"ownerId\\":\\"INVALID\\",\\"name\\":\\"\\",\\"bIsJoinable\\":false},\\"productModes\\":[],\\"privacy\\":\\"NoFill\\",\\"regionId\\":\\"EU\\"}},Timestamp=1768584060,bUsingGracefulUpgrade=True,MatchmakingId=\\"D0AD18DB43D166336ED214B9C430A4F2\\")"
RecentSelections="(Island={\\"LinkId\\":\\"6016-0463-0988\\",\\"Session\\":{\\"iD\\":\\"\\",\\"joinInfo\\":{\\"joinability\\":\\"CanNotBeJoinedOrWatched\\",\\"sessionKey\\":\\"\\"}},\\"MatchmakingSettingsV1\\":{\\"world\\":{\\"iD\\":\\"\\",\\"ownerId\\":\\"INVALID\\",\\"name\\":\\"\\",\\"bIsJoinable\\":false},\\"productModes\\":[],\\"privacy\\":\\"Private\\",\\"regionId\\":\\"EU\\"}},Timestamp=1768579686,bUsingGracefulUpgrade=True,MatchmakingId=\\"9E1B667944A9ACDB75369586CFB25907\\")"
RecentSelections="(Island={\\"LinkId\\":\\"playlist_defaultsolo\\",\\"Session\\":{\\"iD\\":\\"\\",\\"joinInfo\\":{\\"joinability\\":\\"CanNotBeJoinedOrWatched\\",\\"sessionKey\\":\\"\\"}},\\"MatchmakingSettingsV1\\":{\\"world\\":{\\"iD\\":\\"\\",\\"ownerId\\":\\"INVALID\\",\\"name\\":\\"\\",\\"bIsJoinable\\":false},\\"productModes\\":[],\\"privacy\\":\\"NoFill\\",\\"regionId\\":\\"EU\\"}},Timestamp=0,bUsingGracefulUpgrade=True,MatchmakingId=\\"65F2ED6745E05F02C4673B86BB59453A\\")"
RecentSelections="(Island={\\"LinkId\\":\\"playlist_defaultsquad\\",\\"Session\\":{\\"iD\\":\\"\\",\\"joinInfo\\":{\\"joinability\\":\\"CanNotBeJoinedOrWatched\\",\\"sessionKey\\":\\"\\"}},\\"MatchmakingSettingsV1\\":{\\"world\\":{\\"iD\\":\\"\\",\\"ownerId\\":\\"INVALID\\",\\"name\\":\\"\\",\\"bIsJoinable\\":false},\\"productModes\\":[],\\"privacy\\":\\"Fill\\",\\"regionId\\":\\"NONE\\"}},Timestamp=0,bUsingGracefulUpgrade=True,MatchmakingId=\\"0720766B43E2191B6C8BE6BD59565AE6\\")"
LastCPUBenchmarkSteps=139.403656
LastCPUBenchmarkSteps=170.439484
LastGPUBenchmarkSteps=898.544006
LastGPUBenchmarkSteps=608.228760
LastGPUBenchmarkSteps=1131.702637
LastGPUBenchmarkSteps=441.219757
LastGPUBenchmarkSteps=173.431900
LastGPUBenchmarkSteps=242.465164
LastGPUBenchmarkSteps=1318.786377
ConsumedLinkTokens=Token:fnbraddon

[DriverCache]
LastSeasonClearV2=39

[ScalabilityGroups]
sg.ResolutionQuality=100
sg.ViewDistanceQuality=1
sg.AntiAliasingQuality=0
sg.ShadowQuality=0
sg.GlobalIlluminationQuality=0
sg.ReflectionQuality=0
sg.PostProcessQuality=0
sg.TextureQuality=0
sg.EffectsQuality=0
sg.FoliageQuality=0
sg.ShadingQuality=0
sg.LandscapeQuality=0

[/Script/FortniteUIAudio.FortAudioUserMixSubsystem]
UserMixCurrentValues=(BusName="CB_Slider_Main",Volume=0.650000)
UserMixCurrentValues=(BusName="CB_Slider_Chat",Volume=1.000000)
UserMixCurrentValues=(BusName="CB_Slider_Cinematics",Volume=0.000000)
UserMixCurrentValues=(BusName="CB_Slider_Dialogue",Volume=0.000000)
UserMixCurrentValues=(BusName="CB_Slider_Music",Volume=0.650000)
UserMixCurrentValues=(BusName="CB_Slider_PIP",Volume=0.000000)
UserMixCurrentValues=(BusName="CB_Slider_SFX",Volume=0.540000)
UserMixCurrentValues=(BusName="CB_IsInFrontend",Volume=1.000000)
UserMixCurrentValues=(BusName="CB_Slider_LobbyMusic",Volume=0.200000)

[ChatSettings]
HideSocialName=False
AutoImportFriends=False
ShowNotifications=True
NeverFadeMessages=False
ShowTimeStamps=True
ShowWhispersInAllTabs=False
ShowCustomTab=True
ShowWhispersTab=False
ShowGlobalTab=True
ShowCombatAndEventsTab=True
ShowClanTabs=True
HideOffline=False
FilterMatureLanguage=True
DisplayCharacterNames=False
FriendInviteReceivedCueEnabled=True
MessageReceivedCueEnabled=False
SoundEnabled=False
ShowTextChat=False
WindowHeight=0
WindowOpacity=0.5

[D3DRHIPreference]
PreferredRHI=dx11
PreferredFeatureLevel=es31
'''

# Path to the config file in the app
FORTNITE_CONFIG_FILE_PATH = Path(__file__).parent.parent / 'frontend' / 'src' / 'configs' / 'fortnite' / 'GameUserSettings.ini'

def generate_fortnite_config(settings: FortniteConfigRequest) -> str:
    """Generate Fortnite config content with custom settings"""
    # Read the template and replace values
    config = FORTNITE_CONFIG_TEMPLATE
    
    # Replace resolution values
    config = config.replace('ResolutionSizeX=1600', f'ResolutionSizeX={settings.resolutionX}')
    config = config.replace('ResolutionSizeY=900', f'ResolutionSizeY={settings.resolutionY}')
    config = config.replace('LastUserConfirmedResolutionSizeX=1600', f'LastUserConfirmedResolutionSizeX={settings.resolutionX}')
    config = config.replace('LastUserConfirmedResolutionSizeY=900', f'LastUserConfirmedResolutionSizeY={settings.resolutionY}')
    
    # Replace window mode
    config = config.replace('FullscreenMode=0', f'FullscreenMode={settings.windowMode}')
    config = config.replace('LastConfirmedFullscreenMode=0', f'LastConfirmedFullscreenMode={settings.windowMode}')
    config = config.replace('PreferredFullscreenMode=0', f'PreferredFullscreenMode={settings.windowMode}')
    
    # Replace frame rate limit
    config = config.replace('FrameRateLimit=360.000000', f'FrameRateLimit={settings.frameRateLimit:.6f}')
    
    # Replace scalability settings
    config = config.replace('sg.ViewDistanceQuality=1', f'sg.ViewDistanceQuality={settings.viewDistance}')
    config = config.replace('sg.AntiAliasingQuality=0', f'sg.AntiAliasingQuality={settings.antiAliasing}')
    config = config.replace('sg.ShadowQuality=0', f'sg.ShadowQuality={settings.shadows}')
    config = config.replace('sg.PostProcessQuality=0', f'sg.PostProcessQuality={settings.postProcessing}')
    config = config.replace('sg.TextureQuality=0', f'sg.TextureQuality={settings.textures}')
    config = config.replace('sg.EffectsQuality=0', f'sg.EffectsQuality={settings.effects}')
    
    return config

@api_router.post("/apply-fortnite-config", response_model=FortniteConfigResponse)
async def apply_fortnite_config(request: FortniteConfigRequest):
    """Apply Fortnite configuration by copying to the Fortnite folder"""
    from pathlib import Path
    import shutil
    import os
    import tempfile
    
    try:
        # Generate config with custom settings
        config_content = generate_fortnite_config(request)
        
        # Determine the Fortnite config path
        if os.name == 'nt':  # Windows
            local_appdata = os.environ.get('LOCALAPPDATA')
            if not local_appdata:
                return FortniteConfigResponse(
                    success=False,
                    message="Impossible de trouver LOCALAPPDATA",
                    file_path=None
                )
            
            fortnite_config_path = Path(local_appdata) / 'FortniteGame' / 'Saved' / 'Config' / 'WindowsClient' / 'GameUserSettings.ini'
        else:  # Linux/Mac for testing
            fortnite_config_path = Path('/tmp/fortnite_test/GameUserSettings.ini')
        
        logger.info(f"Fortnite config path: {fortnite_config_path}")
        
        # Create directories if they don't exist
        try:
            fortnite_config_path.parent.mkdir(parents=True, exist_ok=True)
            logger.info(f"Directories created: {fortnite_config_path.parent}")
        except PermissionError as e:
            logger.error(f"Permission denied creating directories: {str(e)}")
            return FortniteConfigResponse(
                success=False,
                message=f"Permission refusée: Lancez l'application en tant qu'administrateur",
                file_path=None
            )
        
        # Create backup of existing file
        if fortnite_config_path.exists():
            try:
                backup_path = fortnite_config_path.parent / f'GameUserSettings_backup_{int(time.time())}.ini'
                shutil.copy2(fortnite_config_path, backup_path)
                logger.info(f"Backup created: {backup_path}")
            except PermissionError:
                logger.warning("Could not create backup (permission denied)")
        
        # Write the new config
        try:
            with open(fortnite_config_path, 'w', encoding='utf-8') as f:
                f.write(config_content)
            logger.info(f"Fortnite config written successfully to {fortnite_config_path}")
        except PermissionError as e:
            logger.error(f"Permission denied writing file: {str(e)}")
            # Try writing to temp first then copy (requires admin)
            temp_file = Path(tempfile.gettempdir()) / 'GameUserSettings_temp.ini'
            with open(temp_file, 'w', encoding='utf-8') as f:
                f.write(config_content)
            
            return FortniteConfigResponse(
                success=False,
                message=f"Permission refusée pour écrire dans le dossier Fortnite. Fichier créé dans: {temp_file}. Lancez l'application en tant qu'administrateur ou copiez manuellement ce fichier.",
                file_path=str(temp_file)
            )
        
        return FortniteConfigResponse(
            success=True,
            message=f"Configuration Fortnite appliquée: {request.resolutionX}x{request.resolutionY} @ {request.frameRateLimit} FPS",
            file_path=str(fortnite_config_path)
        )
        
    except Exception as e:
        logger.error(f"Error applying Fortnite config: {str(e)}")
        return FortniteConfigResponse(
            success=False,
            message=f"Erreur: {str(e)}",
            file_path=None
        )

# Endpoint to get current Fortnite config
@api_router.get("/fortnite-config")
async def get_fortnite_config():
    """Get current Fortnite configuration from the app's config file"""
    try:
        if FORTNITE_CONFIG_FILE_PATH.exists():
            with open(FORTNITE_CONFIG_FILE_PATH, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Parse key values from the config
            import re
            
            def get_value(pattern, default):
                match = re.search(pattern, content)
                return match.group(1) if match else default
            
            return {
                "success": True,
                "config": {
                    "resolutionX": int(get_value(r'ResolutionSizeX=(\d+)', '1600')),
                    "resolutionY": int(get_value(r'ResolutionSizeY=(\d+)', '900')),
                    "windowMode": int(get_value(r'FullscreenMode=(\d+)', '0')),
                    "frameRateLimit": float(get_value(r'FrameRateLimit=([\d.]+)', '360.0')),
                    "shadows": int(get_value(r'sg\.ShadowQuality=(\d+)', '0')),
                    "textures": int(get_value(r'sg\.TextureQuality=(\d+)', '0')),
                    "effects": int(get_value(r'sg\.EffectsQuality=(\d+)', '0')),
                    "antiAliasing": int(get_value(r'sg\.AntiAliasingQuality=(\d+)', '0')),
                    "viewDistance": int(get_value(r'sg\.ViewDistanceQuality=(\d+)', '1')),
                    "postProcessing": int(get_value(r'sg\.PostProcessQuality=(\d+)', '0'))
                }
            }
        else:
            return {
                "success": True,
                "config": {
                    "resolutionX": 1600,
                    "resolutionY": 900,
                    "windowMode": 0,
                    "frameRateLimit": 360.0,
                    "shadows": 0,
                    "textures": 0,
                    "effects": 0,
                    "antiAliasing": 0,
                    "viewDistance": 1,
                    "postProcessing": 0
                }
            }
    except Exception as e:
        return {"success": False, "message": str(e)}

# ============================================================================
# OBS PROFILE APPLICATION
# ============================================================================

class ObsProfileRequest(BaseModel):
    gpuType: str  # "NVIDIA" or "AMD"
    
    class Config:
        populate_by_name = True
        alias_generator = lambda x: x

class ObsProfileResponse(BaseModel):
    success: bool
    message: str
    files_copied: Optional[list] = None

@api_router.post("/apply-obs-profile", response_model=ObsProfileResponse)
async def apply_obs_profile(request: ObsProfileRequest):
    """Apply OBS profile by copying files from GPU-specific folder to OBS profiles directory"""
    import os
    import shutil
    from pathlib import Path
    
    try:
        gpu_type = request.gpuType.upper()
        
        if gpu_type not in ["NVIDIA", "AMD"]:
            return ObsProfileResponse(
                success=False,
                message="Type de GPU invalide. Utilisez NVIDIA ou AMD."
            )
        
        # Chemins source (dans le projet)
        source_dir = Path(__file__).parent.parent / "frontend" / "src" / "configs" / "obs" / gpu_type
        
        logger.info(f"=== Application du profil OBS {gpu_type} ===")
        logger.info(f"Source dir path: {source_dir}")
        logger.info(f"Source dir exists: {source_dir.exists()}")
        
        # Vérifier que le dossier source existe
        if not source_dir.exists():
            logger.error(f"Dossier source introuvable: {source_dir}")
            return ObsProfileResponse(
                success=False,
                message=f"Dossier source introuvable: {source_dir}"
            )
        
        # Lister les fichiers sources
        source_files = list(source_dir.glob("*"))
        logger.info(f"Fichiers sources trouvés: {[f.name for f in source_files if f.is_file()]}")
        
        # Chemin de destination OBS (%USERPROFILE%\AppData\Roaming\obs-studio\basic\profiles)
        if os.name == 'nt':  # Windows
            userprofile = os.environ.get('USERPROFILE')
            if not userprofile:
                logger.error("Variable USERPROFILE non trouvée")
                return ObsProfileResponse(
                    success=False,
                    message="Impossible de trouver le profil utilisateur Windows (USERPROFILE)"
                )
            dest_dir = Path(userprofile) / "AppData" / "Roaming" / "obs-studio" / "basic" / "profiles" / "BabaTool"
        else:  # Linux/Mac pour les tests
            dest_dir = Path("/tmp/obs-studio/basic/profiles/BabaTool")
        
        logger.info(f"Destination dir: {dest_dir}")
        logger.info(f"OS: {os.name}")
        
        # Créer le dossier de destination s'il n'existe pas
        try:
            dest_dir.mkdir(parents=True, exist_ok=True)
            logger.info(f"Dossier de destination créé/vérifié: {dest_dir}")
        except Exception as e:
            logger.error(f"Erreur lors de la création du dossier destination: {str(e)}")
            return ObsProfileResponse(
                success=False,
                message=f"Impossible de créer le dossier: {str(e)}"
            )
        
        # Copier tous les fichiers
        files_copied = []
        errors = []
        
        for file_path in source_dir.glob("*"):
            if file_path.is_file():
                try:
                    dest_file = dest_dir / file_path.name
                    shutil.copy2(file_path, dest_file)
                    files_copied.append(file_path.name)
                    logger.info(f"✓ Fichier copié: {file_path.name} -> {dest_file}")
                except Exception as e:
                    error_msg = f"Erreur copie {file_path.name}: {str(e)}"
                    errors.append(error_msg)
                    logger.error(error_msg)
        
        if files_copied:
            message = f"Profil OBS {gpu_type} appliqué avec succès"
            if errors:
                message += f" (avec {len(errors)} erreur(s))"
            
            logger.info(f"=== Résultat: {len(files_copied)} fichiers copiés ===")
            return ObsProfileResponse(
                success=True,
                message=message,
                files_copied=files_copied
            )
        else:
            logger.error("Aucun fichier n'a pu être copié")
            return ObsProfileResponse(
                success=False,
                message=f"Aucun fichier copié. Erreurs: {'; '.join(errors) if errors else 'Aucun fichier trouvé'}"
            )
        
    except Exception as e:
        logger.error(f"Erreur générale lors de l'application du profil OBS: {str(e)}")
        logger.exception("Stack trace:")
        return ObsProfileResponse(
            success=False,
            message=f"Erreur: {str(e)}"
        )


# ============================================================================
# NVIDIA DRIVER INSTALLATION
# ============================================================================

class NvidiaInstallResponse(BaseModel):
    success: bool
    message: str
    file_path: Optional[str] = None

@api_router.get("/download-nvidia-driver")
async def download_nvidia_driver():
    """Download NVIDIA driver and return as streaming response"""
    import urllib.request
    from fastapi.responses import StreamingResponse
    import io
    
    try:
        nvidia_url = "https://github.com/Baba75020/NVIDIA/releases/download/V1/NVIDIA.exe"
        
        logger.info(f"Téléchargement du driver NVIDIA depuis {nvidia_url}")
        
        # Télécharger avec headers pour gérer les redirections GitHub
        req = urllib.request.Request(
            nvidia_url,
            headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        )
        
        with urllib.request.urlopen(req) as response:
            content = response.read()
        
        logger.info(f"Fichier téléchargé: {len(content)} bytes")
        
        # Retourner le fichier en streaming
        return StreamingResponse(
            io.BytesIO(content),
            media_type="application/octet-stream",
            headers={
                "Content-Disposition": "attachment; filename=NVIDIA_Setup.exe",
                "Content-Length": str(len(content))
            }
        )
        
    except Exception as e:
        logger.error(f"Erreur lors du téléchargement NVIDIA: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erreur: {str(e)}")


@api_router.post("/install-nvidia-driver", response_model=NvidiaInstallResponse)
async def install_nvidia_driver():
    """Provide download URL for NVIDIA driver installation"""
    try:
        # URL du fichier NVIDIA sur GitHub
        nvidia_url = "https://github.com/Baba75020/NVIDIA/releases/download/V1/NVIDIA.exe"
        
        logger.info(f"Fournir l'URL de téléchargement NVIDIA: {nvidia_url}")
        
        # Vérifier que l'URL est accessible
        import urllib.request
        try:
            req = urllib.request.Request(
                nvidia_url,
                headers={'User-Agent': 'Mozilla/5.0'},
                method='HEAD'
            )
            with urllib.request.urlopen(req, timeout=5) as response:
                if response.status == 200 or response.status == 302:
                    logger.info(f"URL NVIDIA accessible (status: {response.status})")
                else:
                    logger.warning(f"URL NVIDIA retourne status: {response.status}")
        except Exception as e:
            logger.warning(f"Impossible de vérifier l'URL: {str(e)}")
        
        return NvidiaInstallResponse(
            success=True,
            message="URL de téléchargement NVIDIA prête",
            file_path=nvidia_url
        )
        
    except Exception as e:
        logger.error(f"Erreur lors de la préparation du téléchargement NVIDIA: {str(e)}")
        return NvidiaInstallResponse(
            success=False,
            message=f"Erreur: {str(e)}"
        )


# ============================================================================
# OOSU10 PRIVACY PROFILE
# ============================================================================

class OOSU10Response(BaseModel):
    success: bool
    message: str
    output: Optional[str] = None

@api_router.post("/apply-oosu10", response_model=OOSU10Response)
async def apply_oosu10_profile():
    """Apply OOSU10 privacy profile using PowerShell script"""
    import subprocess
    
    try:
        # Path to the PowerShell script
        script_path = Path(__file__).parent / "scripts" / "OOSU10.ps1"
        
        if not script_path.exists():
            logger.error(f"OOSU10 script not found: {script_path}")
            return OOSU10Response(
                success=False,
                message="Script OOSU10 introuvable"
            )
        
        logger.info(f"Executing OOSU10 script: {script_path}")
        
        # Execute PowerShell script
        result = subprocess.run(
            ['powershell', '-ExecutionPolicy', 'Bypass', '-File', str(script_path)],
            capture_output=True,
            text=True,
            timeout=60  # 60 seconds timeout
        )
        
        logger.info(f"OOSU10 script exit code: {result.returncode}")
        logger.info(f"OOSU10 stdout: {result.stdout}")
        if result.stderr:
            logger.warning(f"OOSU10 stderr: {result.stderr}")
        
        if result.returncode == 0:
            return OOSU10Response(
                success=True,
                message="Profil OOSU10 appliqué avec succès",
                output=result.stdout
            )
        else:
            return OOSU10Response(
                success=False,
                message=f"Erreur lors de l'application du profil (code: {result.returncode})",
                output=result.stderr or result.stdout
            )
        
    except subprocess.TimeoutExpired:
        logger.error("OOSU10 script timeout")
        return OOSU10Response(
            success=False,
            message="Timeout: Le script a pris trop de temps (> 60s)"
        )
    except Exception as e:
        logger.error(f"OOSU10 script error: {str(e)}")
        return OOSU10Response(
            success=False,
            message=f"Erreur: {str(e)}"
        )


# ============================================================================
# INIT DEFAULT ADMIN
# ============================================================================

@app.on_event("startup")
async def startup_event():
    """Create default admin if not exists"""
    admin_exists = await db.admins.find_one({"username": "admin"})
    if not admin_exists:
        default_admin = Admin(
            username="admin",
            password_hash=get_password_hash("admin123"),
            role="admin"
        )
        doc = default_admin.model_dump()
        doc['created_at'] = doc['created_at'].isoformat()
        await db.admins.insert_one(doc)
        logger.info("Default admin created: username='admin', password='admin123'")


# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()