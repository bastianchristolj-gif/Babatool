# BaBaTool - Product Requirements Document

## Aperçu du Projet
BaBaTool est une application Electron/React pour l'optimisation de Windows. Elle permet aux utilisateurs de gérer les paramètres de performance, confidentialité, interface, et de supprimer les bloatwares préinstallés.

## Stack Technique
- **Frontend**: React + Tailwind CSS + Shadcn/UI + i18next
- **Backend**: FastAPI (Python) - validation de licence et admin panel
- **Desktop**: Electron (exécution de commandes PowerShell)
- **Base de données**: MongoDB (licences)

## Fonctionnalités Implémentées

### ✅ Page Interface - Améliorations (2026-01-28) - TERMINÉ
**Nouvelles fonctionnalités :**
- **Toggle "Couleur sur la barre des tâches"** : Contrôle séparé pour `ColorPrevalence` (afficher la couleur d'accentuation sur le menu Démarrer et la barre des tâches)
- **Détection des états Windows** : Bouton "Détecter" qui lit les paramètres actuels de Windows pour synchroniser les toggles avec l'état réel du système

**Corrections sans redémarrage d'explorer :**
- Les scripts pour thème sombre, transparence, effets et couleur d'accentuation ne redémarrent plus l'explorer Windows
- Seuls les changements de menu contextuel et Alt+Tab redémarrent l'explorer (nécessaire)

**Fichiers modifiés :**
- `/app/frontend/src/data/mockData.js` - Ajout `colorPrevalence`, suppression du restart explorer des autres scripts
- `/app/frontend/src/components/pages/InterfacePage.jsx` - Nouveau toggle et carte de détection des états
- `/app/frontend/electron/settingsReader.js` - Ajout de `readColorPrevalence()`
- Traductions FR/EN ajoutées

### ✅ Page Interface - Corrections (2026-01-28) - TERMINÉ
**Corrections du bug des toggles PowerShell :**
- Modification du handler `execute-powershell` dans `main.js` pour gérer les scripts multilignes
- Les scripts multilignes sont maintenant écrits dans un fichier temporaire `.ps1` et exécutés via `powershell -File`
- Les scripts sur une seule ligne continuent d'être exécutés via `-Command`

**Corrections du menu Personnaliser Windows :**
- **Option "Activer les effets"** : Script corrigé pour modifier les animations Windows et les barres de défilement
- **Couleur d'accentuation** : Script séparé du toggle ColorPrevalence

**Modifications du menu Barre des tâches :**
- **Supprimé** : Option "Position de la barre des tâches"
- **Ajouté** : Toggle "Vue des tâches" (ShowTaskViewButton)

### ✅ Page Interface - Wallpapers (2026-01-28) - TERMINÉ
**Fonctionnalité de sélection de fonds d'écran :**
- Scan automatique du dossier `Desktop/wallpapers` de l'utilisateur
- Affichage des images en grille de miniatures cliquables
- Application du fond d'écran sélectionné via PowerShell (SystemParametersInfo + registre + RUNDLL32 refresh)
- **Fonction d'importation** : Permet d'importer des fichiers images via une boîte de dialogue
- **Fonction de suppression** : Bouton corbeille sur chaque miniature au survol pour supprimer le wallpaper
- États de chargement, erreur et vide gérés avec boutons d'importation contextuels
- Bouton "Rafraîchir" pour rescanner le dossier
- Bouton "Appliquer la personnalisation" masqué sur cet onglet (les wallpapers s'appliquent au clic)
- Support des formats: JPG, PNG, BMP, GIF, WEBP

**Fichiers modifiés :**
- `/app/frontend/src/components/pages/InterfacePage.jsx` - UI des wallpapers avec import/delete
- `/app/frontend/electron/main.js` - IPC handlers `get-wallpapers`, `set-wallpaper`, `import-wallpaper`, `delete-wallpaper`
- `/app/frontend/electron/preload.js` - APIs exposées au renderer
- `/app/frontend/src/data/mockData.js` - Scripts PowerShell pour Interface

### ✅ Traduction Complète avec i18next (2026-01-26) - 100% TERMINÉ
**Tous les composants traduits :**
- `HomePage.jsx` ✓
- `PerformancePage.jsx` ✓
- `PrivacyPage.jsx` ✓
- `InterfacePage.jsx` ✓
- `AdvancedPage.jsx` ✓
- `BloatwarePage.jsx` ✓
- `UpdatesPage.jsx` ✓
- `DriversPage.jsx` (Hardware) ✓
- `LicenseValidationModal.jsx` ✓
- `Sidebar.jsx` ✓

**Fichiers de traduction:**
- `/app/frontend/src/i18n/locales/fr.json` - Français (300+ clés)
- `/app/frontend/src/i18n/locales/en.json` - Anglais (300+ clés)

### ✅ Lecture États Windows (30+ paramètres)
**settingsReader.js** supporte:
- Power: fast-startup, hibernate, usb-suspend
- Gaming: game-mode, hags, game-dvr, fullscreen-opt, gpu-timeout, mouse-accel, priority, nagle
- Interface: dark-mode, transparency, animations, classic-context, legacy-alt-tab, taskbar-align
- Privacy: telemetry, advertising-id, activity-history, location, cortana, diagnostic-data
- Advanced: defender, smartscreen, uac, windows-update, mitigations

### ✅ Système de Licence Multi-tiers
- Validation via backend FastAPI
- Feature-gating (Trial, Premium, Lifetime)
- Licence obligatoire

## Notes Techniques

### Licences de test
- `EA93435A-D4BBC3BC-C1DC838E-4970A977` (Test)
- `7BF2B63C-F823BDF3-3B589222-7A35A472` (Lifetime)
- Admin: admin / admin123

### Traductions - Comment ajouter une langue
1. Créer `/app/frontend/src/i18n/locales/[code].json` (copier fr.json comme base)
2. Ajouter la ressource dans `/app/frontend/src/i18n/index.js`
3. Ajouter le drapeau dans `/app/frontend/public/flags/[code].webp`
4. Ajouter l'option dans le tableau `languages` dans `Sidebar.jsx`

## Problèmes Connus / À Vérifier
- **OOSU10 Script**: L'exécution du script PowerShell OOSU10 a été problématique avec le packaging Electron. La dernière solution (scripts embarqués en modules JS) doit être testée dans l'app packagée.

### ✅ Page Interface - Old Menu (2026-01-28) - TERMINÉ
**Options de style des menus Windows :**
- **Menu contextuel** : Choix entre Classique (Windows 10) et Moderne (Windows 11)
  - Modifie la clé registre `HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}`
- **Alt + Tab** : Choix entre Classique (miniatures simples) et Moderne (aperçu complet)
  - Modifie la clé registre `HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\AltTabSettings`
- Interface avec boutons de sélection stylisés
- Info card expliquant les redémarrages nécessaires

## Tâches Restantes

### P1 - Priorité Haute
- Traduire les 43 messages toast codés en dur dans InterfacePage.jsx

### P2 - Priorité Moyenne  
- Vérifier le fonctionnement du script OOSU10 dans l'app Electron packagée
- Vérifier la propagation du changement de langue à chaud

### P3 - Priorité Basse
- Refactorisation de `InterfacePage.jsx` (+1000 lignes → décomposer en composants)
- Traduire les catégories de settings (actuellement hardcodées dans mockData.js)

---

## Historique des Migrations

### Migration 1er Février 2026
- ✅ Projet Baba207.zip extrait et migré avec succès
- ✅ Backend FastAPI fonctionnel (port 8001)
- ✅ Frontend React fonctionnel (port 3000)
- ✅ Panel Admin accessible et opérationnel
- ✅ MongoDB configuré
- ✅ URL: `https://file-copier-4.preview.emergentagent.com`
